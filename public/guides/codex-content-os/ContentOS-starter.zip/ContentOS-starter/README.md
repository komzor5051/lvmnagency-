# ContentOS-starter

A v0 reference implementation of the pipeline described in the guide **"Codex
как контент-операционная система"**: a job folder of photos/video/music
becomes a vertical Reel through `ingest -> analyze -> render -> qa`, driven
by an `edit_plan.json` timeline.

This is a **honest starter, not a finished production system**. Read "What's
real vs stub" below before you show it to a client.

## Setup

Requirements:

- Node.js 18+
- `ffmpeg` / `ffprobe` on your PATH

```bash
ffmpeg -version
ffprobe -version
node --version
```

macOS (Homebrew):

```bash
brew install ffmpeg node
```

Windows (WinGet):

```powershell
winget install Gyan.FFmpeg
winget install OpenJS.NodeJS.LTS
```

Then, inside `ContentOS-starter/`:

```bash
npm install
```

There is nothing to install — `package.json` has zero dependencies on
purpose. Everything is Node core (`fs`, `path`, `crypto`, `child_process`)
shelling out to `ffmpeg`/`ffprobe`. `npm install` just gives you a
`node_modules/` and a lockfile for future additions.

Copy `.env.example` to `.env` if/when you add API-driven steps (none of the
scripts read environment variables yet).

## Commands

```bash
node scripts/ingest.js  <job-dir>
node scripts/analyze.js <job-dir>
node scripts/render.js  <edit_plan.json> <output.mp4>
node scripts/render.js  --auto-cut-to-beats <job-dir> <output.mp4> [beatsPerCut]
node scripts/qa.js      <output.mp4> [edit_plan.json]
```

Or via npm (note the `--` npm needs before script arguments):

```bash
npm run ingest  -- <job-dir>
npm run analyze -- <job-dir>
npm run render  -- <edit_plan.json> <output.mp4>
npm run qa      -- <output.mp4>
```

One-shot demo on the bundled sample job:

```bash
npm run demo
```

This runs all four steps against `examples/sample-job/` and ends with a
PASS/FAIL QA report. It has been run and verified working as part of
building this package — see "Verified run" below.

Beat-synced photo montage demo (`studio-clean` preset, no stubs):

```bash
npm run demo:studio-clean
```

Runs `ingest -> analyze -> render --auto-cut-to-beats -> qa` against
`examples/studio-clean-demo/` — see "Verified run" below for the actual
numbers from the last run.

### Job folder layout

```
your-job/
├── request.md        (optional, free-form brief — see schemas/request.schema.json)
├── video/             *.mp4, .mov, .m4v, .webm, .avi, .mkv
├── photo/             *.jpg, .jpeg, .png, .webp, .heic
├── music/             *.mp3, .wav, .m4a, .aac, .flac, .ogg
├── manifest.json       <- written by ingest
├── analyze/
│   ├── frames/          <- keyframes + photo thumbnails, written by analyze
│   └── contact-sheet.jpg
├── transcript.json     <- written by analyze (STUB, see below)
├── beats.json          <- written by analyze (REAL bpm/beat detection, see below)
├── edit_plan.json      <- you write this (schema: schemas/edit_plan.schema.json)
│                          (skip this file if using render --auto-cut-to-beats)
├── auto_edit_plan.json <- written by `render.js --auto-cut-to-beats` instead,
│                          generated from beats.json + photo/
└── output/
    ├── reel.mp4         <- written by render
    ├── render.json
    └── qa.md            <- written by qa
```

## What's real vs stub

This matches the guide's promise in sections 2, 8 and 27: `ingest`,
`render` and `qa` are real and load-bearing; `analyze` is now fully real for
the `studio-clean` (photos-to-music, no speech) path and partial for the
talking-head/speech path; the `talking-head-clean` preset and caption
rendering are not built at all in this v0.

**One fully-real path, no stubs**: the `studio-clean` preset — photos synced
to music beats, no speech, no transcription needed — is real end to end:
`ingest` → `analyze` (real beats.json) → `render --auto-cut-to-beats` (cuts
generated from those real beat timestamps) → `qa` (PASS). See
`examples/studio-clean-demo/` and "Beat-synced photo montage" below. The
talking-head path (speech → captions) is explicitly still a stub, see
`transcript.json` below.

| Piece | Status | Notes |
|---|---|---|
| `ingest` | **Real** | Scans `video/`, `photo/`, `music/`, runs `ffprobe` on every file, computes SHA-256 to flag duplicates, writes `manifest.json` with duration/resolution/fps/codec/orientation. |
| `analyze` — keyframes + contact sheet | **Real** | Extracts keyframes from every video with `ffmpeg` (`fps` filter, spread evenly across each clip's duration) and tiles them with photo thumbnails into one `contact-sheet.jpg` via `ffmpeg`'s `xstack` filter. |
| `analyze` — `beats.json` | **Real** | Energy-based onset/beat detection, no ML or DSP library — plain JS signal processing. Method: decode the track to mono PCM via `ffmpeg`, compute a short-time RMS envelope, take the half-wave-rectified frame-to-frame RMS increase as onset strength, smooth it, peak-pick with a local adaptive threshold (mean + 1.5·stddev over a ~1s window) and a minimum-distance constraint, estimate tempo from the median inter-onset interval, then generate a regular beat grid at that tempo anchored on the first detected onset. **Limits**: tuned for tracks with clear percussive hits (drums, clicks, claps, kick-forward EDM/hip-hop); not validated on ambient or classical music (expect a noisier/less reliable BPM estimate there); no downbeat/bar detection; no automatic tempo-doubling/halving correction. Validated against a self-generated 120 BPM click track (`ffmpeg -f lavfi aevalsrc`): detected 120.19 BPM (0.16% off) with beat timestamps within ~0.05s of the true click times, and against a 128 BPM kick+hi-hat loop: detected 129.2 BPM (0.9% off). See `scripts/analyze.js`'s beat-detection block for the full method. |
| `analyze` — `transcript.json` | **Stub** | No speech-to-text model runs. The file has the right shape (`segments: []` with a `stub: true` flag and a `note` explaining why) so downstream code/Codex can already consume it. **Bonus, best-effort**: if a `whisper` CLI (openai-whisper) or `whisper-cli`/`main` (whisper.cpp) is found on PATH, `analyze.js` logs that it's available — wiring it into the actual transcription call is a `TODO` left in `scripts/analyze.js` (search for `tryWhisperCli`). It is never a hard dependency: absence is not an error. The talking-head (speech) path stays explicitly out of scope for this pass — only `studio-clean` (no speech) claims "no stubs". |
| `render` | **Real** | Reads `edit_plan.json` and renders an actual vertical mp4 with plain `ffmpeg` — no Remotion, no headless browser (see "Why plain FFmpeg" below). Image sources get a Ken Burns slow-zoom (`zoompan`); video sources get trimmed/scaled/cropped to fill the frame; `drawtext` for on-screen text; clips are concatenated in timeline order; background music is mixed in starting at `music.startSec`. |
| `render --auto-cut-to-beats` | **Real** | New mode: generates the `edit_plan.json` timeline itself from a real `beats.json` + a `photo/` folder, instead of reading a hand-written one. See "Beat-synced photo montage" below. |
| `qa` | **Real** | Runs `ffprobe` on the rendered file and checks resolution, fps (±0.5), presence of an audio stream, and duration (±0.75s) against `edit_plan.json`. Writes `qa.md` with a pass/fail line per check and exits non-zero on any failure. |
| presets — `studio-clean` | **Real (this pass)** | `render.js --auto-cut-to-beats` is the `studio-clean` preset implementation: photos cut to real detected beats, no captions, no speech. |
| presets — `talking-head-clean` | **Not built** | `edit_plan.json`'s `captions.preset` field is accepted and stored but has no effect on the render in this v0 for the speech path. Brand-specific caption styling, safe zones, and typography are yours (or Codex's) to add — downstream of the `transcript.json` stub above. |
| Captions / subtitle burn-in | **Not built** | `render.js` does text overlays per-clip via `drawtext` (the `text` field on a timeline entry), but does not render word-level captions from `transcript.json`. That's downstream of the transcript stub above. |
| Transitions other than hard cuts | **Not built** | `edit_plan.json`'s `transition` field (e.g. `"beat-cut"`) is accepted in the schema — `--auto-cut-to-beats` even labels its generated segments with it — but `render.js` currently only does hard cuts between clips. Cross-fades are a `TODO`. |

### Beat-synced photo montage (`--auto-cut-to-beats`)

The task of proving `beats.json` is real could have gone two ways: (a) add a
`syncToBeats: true` flag that a hand-written `edit_plan.json` opts into, and
have `render.js` snap its `from`/`to` values to the nearest detected beat; or
(b) skip hand-written timelines for this preset entirely and have
`render.js` generate the whole timeline from `beats.json` + a photo folder.
This starter does **(b)** — `node scripts/render.js --auto-cut-to-beats
<job-dir> <output.mp4> [beatsPerCut]` — because it's the more honest and
demonstrable option: there's no hand-authored timeline left in the loop to
obscure whether the cuts actually came from the beat detector. Every cut
point in the rendered video is traceable straight back to a timestamp in
`beats.json`.

What it does: reads `<job-dir>/beats.json` (fails loudly if it's a stub or
has fewer than 2 detected beats), reads every photo in `<job-dir>/photo/`,
cuts every `beatsPerCut` beats (default 2), assigns photos round-robin, and
writes the generated plan to `<job-dir>/auto_edit_plan.json` *before*
rendering — so you can inspect exactly which beat timestamps produced which
cut points. It then renders through the same clip pipeline (`renderPlan()`)
as the manual `edit_plan.json` path, so `qa.js` works against it unchanged.

### Why plain FFmpeg, not Remotion

The guide's production design (section 33) uses Remotion for composition and
typography and FFmpeg for encoding. This starter deliberately renders with
FFmpeg alone, so it runs on any machine without a headless browser or the
Remotion/React toolchain. Moving to Remotion later is an upgrade for richer
graphics (animated price cards, before/after wipes, custom typography) — not
a requirement to get your first working Reel.

## Verified run

The bundled `examples/sample-job/` contains synthetic, non-client test
media (three flat-color JPEGs, a 4-second `testsrc2` pattern video, and a
20-second sine-wave "music" track — all generated locally with
`ffmpeg -f lavfi`, nothing scraped or copied from anywhere).

`npm run demo` was run against it while building this package:

- `ingest` found 1 video + 3 photos + 1 music file, 0 duplicates, 0 errors,
  and wrote `manifest.json` with per-file duration/resolution/fps/codec.
- `analyze` extracted 4 keyframes from the video, built 3 photo thumbnails,
  tiled all 7 into a 3x3 `contact-sheet.jpg`, and wrote stub
  `transcript.json` / `beats.json` (this sample job predates the real beat
  detector — see `examples/studio-clean-demo/` below for that).
- `render` produced an 11.5s, 1080x1920, 30fps H.264/AAC mp4 from a
  4-clip `edit_plan.json` (2 photos with Ken Burns zoom + on-screen text, 1
  trimmed video clip, 1 more photo), with background music mixed in
  starting at 3s.
- `qa` ran 5 checks against the rendered file (video stream, audio stream,
  resolution, fps, duration) — all **PASS** — and wrote `output/qa.md`.

Re-run it yourself any time with `npm run demo`.

### Verified run: `studio-clean` beat-sync (no stubs)

The bundled `examples/studio-clean-demo/` contains synthetic test media only
(five flat-color 1080x1920 JPEGs and a ~16s 128 BPM kick + hi-hat loop, both
generated locally with `ffmpeg -f lavfi`, nothing scraped or copied).

`npm run demo:studio-clean` was run against it while building this package:

- `ingest` found 5 photos + 1 music file, 0 duplicates, 0 errors.
- `analyze` ran the real beat detector on `music/beat-track.wav`: **34
  onsets detected, estimated 129.2 BPM** against a true tempo of 128 BPM
  (0.9% off) — `beats.json` written with `stub: false`.
- `render --auto-cut-to-beats` read that `beats.json`, cut every 2 beats
  (17 cuts), cycled through the 5 photos round-robin, wrote
  `auto_edit_plan.json`, and rendered a 15.3s 1080x1920 30fps H.264/AAC mp4
  with the beat-track mixed in.
- `qa` ran 5 checks — all **PASS**.

Separately, the beat detector was validated against a self-generated 120
BPM click track (pure `aevalsrc` impulses, no percussion): **23 onsets
detected, estimated 120.19 BPM** (0.16% off), with detected beat timestamps
landing within roughly 0.03-0.05s of the true click times.

Re-run the studio-clean demo yourself any time with `npm run demo:studio-clean`.

## Known limitations of this v0

- `render.js` re-encodes every clip individually before concatenating
  (robust, but not the fastest possible pipeline — fine for the short Reels
  this is meant for).
- Text overlays use FFmpeg's built-in fontconfig lookup (`Arial` by
  default in the `drawtext` filter) rather than a specific bundled font
  file. If your `ffmpeg` build lacks `libfontconfig`, `drawtext` may need a
  `fontfile=` path — see `scripts/render.js`'s `drawtextFilter()`.
- No scene detection, no automatic best-frame selection, no CFR
  normalization pass on ingest (all mentioned in the guide's section 8 as
  part of the full pipeline) — `ingest.js` reports what it measures, it
  doesn't rewrite your source files.
- Paths with Cyrillic characters and spaces were not specifically
  stress-tested beyond this package's own directory path (which does
  contain Cyrillic — `Бизнес` — and it rendered fine end-to-end).

## Beyond Reels

The kit covers three more parts of the guide. Each module has its own
README in Russian, matching the guide the kit ships with.

### Carousels — `carousel/`

Six styles rendered to PNG 1080×1350 by headless Chrome. No Canva, no
image generation: generative models still get logos and Cyrillic text
wrong.

```bash
npm run carousel:logos   # once, needs network
npm run carousel         # all six styles -> carousel/out/
npm run carousel -- b    # one style
```

Brand logos are **not** shipped with the archive — they are third-party
trademarks, so `fetch-logos.mjs` downloads them on first run. Fonts are
bundled: all four are SIL OFL, which permits redistribution, and a
bundled font is what makes the render reproducible.

Puppeteer is deliberately avoided — it would pull a few hundred MB of
Chromium and break the zero-dependency rule above.

### Posts — `posts/`

```bash
npm run post:lint -- drafts/post.md
```

`voice.template.md` is the artefact that matters: describe your voice
once and drafts become editable instead of disposable. `lint.mjs` catches
only the mechanical failures (hype, filler, emoji, "не X, а Y", dash
overuse) so the model's editing pass can stay on meaning.

Word boundaries in the linter use `\p{L}` rather than `\b`, because
JavaScript's `\b` and `\w` are ASCII-only and would silently pass every
Cyrillic violation.

### Sources — `sources/`

```bash
npm run notes:export -- --folder "Идеи" --out inbox/notes
npm run photos:export -- --videos --days 30 --limit 20 --out inbox/job/video
```

Apple Notes goes through `osascript` + `pandoc`. Apple Photos goes
through `osxphotos`, not AppleScript: on Sequoia the Photos AppleScript
dictionary fails to filter by date (`-1700`) or media kind (`-2741`) and
returns zero for albums addressed by name.

The photo script always prints an export summary. In a typical iCloud
library most originals are not on disk, `osxphotos` skips them silently,
and without the summary it looks like the command did nothing.

## Files

- `scripts/ingest.js` — job folder -> `manifest.json`
- `scripts/analyze.js` — keyframes + contact sheet (real) + beats.json (real) + transcript.json (stub)
- `scripts/render.js` — `edit_plan.json` -> vertical mp4 via FFmpeg, plus `--auto-cut-to-beats` mode
- `scripts/qa.js` — rendered mp4 -> `qa.md` pass/fail report
- `scripts/lib.js` — shared helpers (ffprobe wrapper, PCM decode, hashing, file listing)
- `schemas/edit_plan.schema.json` — the render input schema
- `schemas/request.schema.json` — documents the informal `request.md` fields
- `examples/sample-job/` — synthetic test job used by `npm run demo`
- `examples/studio-clean-demo/` — synthetic test job used by `npm run demo:studio-clean` (real beat-sync path)
- `carousel/` — six carousel styles, headless-Chrome renderer, logo fetcher, OFL fonts
- `posts/` — voice template, prompt chain, publication checklist, mechanical linter
- `sources/` — Apple Notes and Apple Photos export wrappers
