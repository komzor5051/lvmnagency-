import { writeFile, mkdir } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

// Пути привязаны к файлу, а не к текущей папке: скрипт запускается
// и напрямую, и через npm run из корня пакета.
const DIR = dirname(fileURLToPath(import.meta.url));
const out = (kind, slug) => join(DIR, 'logos', kind, `${slug}.svg`);
await mkdir(join(DIR, 'logos', 'color'), { recursive: true });
await mkdir(join(DIR, 'logos', 'mono'), { recursive: true });
const LOBE = 'https://cdn.jsdelivr.net/npm/@lobehub/icons-static-svg@1.94.0/icons';
const GB   = 'https://cdn.svglogos.dev/logos';
const SI   = 'https://cdn.simpleicons.org';
const M = {
  claude:     { color: `${LOBE}/claude-color.svg`,     mono: `${LOBE}/claude.svg` },
  openai:     { color: `${LOBE}/openai.svg`,           mono: `${LOBE}/openai.svg` },
  n8n:        { color: `${LOBE}/n8n-color.svg`,        mono: `${LOBE}/n8n.svg` },
  make:       { color: `${LOBE}/make-color.svg`,       mono: `${LOBE}/make.svg` },
  zapier:     { color: `${LOBE}/zapier-color.svg`,     mono: `${LOBE}/zapier.svg` },
  perplexity: { color: `${LOBE}/perplexity-color.svg`, mono: `${LOBE}/perplexity.svg` },
  cursor:     { color: `${LOBE}/cursor.svg`,           mono: `${LOBE}/cursor.svg` },
  gemini:     { color: `${LOBE}/gemini-color.svg`,     mono: `${LOBE}/gemini.svg` },
  elevenlabs: { color: `${LOBE}/elevenlabs.svg`,       mono: `${LOBE}/elevenlabs.svg` },
  railway:    { color: `${LOBE}/railway.svg`,          mono: `${LOBE}/railway.svg` },
  supabase:   { color: `${GB}/supabase-icon.svg`,      mono: `${SI}/supabase` },
  telegram:   { color: 'https://telegram.org/img/t_logo.svg', mono: `${SI}/telegram` },
  notion:     { color: `${GB}/notion-icon.svg`,        mono: `${SI}/notion` },
  figma:      { color: `${GB}/figma.svg`,              mono: `${SI}/figma` },
  vercel:     { color: `${GB}/vercel-icon.svg`,        mono: `${SI}/vercel` },
  airtable:   { color: `${GB}/airtable.svg`,           mono: `${SI}/airtable` },
  slack:      { color: `${GB}/slack-icon.svg`,         mono: `${GB}/slack-icon.svg` },
  stripe:     { color: `${GB}/stripe.svg`,             mono: `${SI}/stripe` },
  obsidian:   { color: `${GB}/obsidian-icon.svg`,      mono: `${SI}/obsidian` },
  'google-sheets': { color: 'https://svgl.app/library/google-sheets.svg', mono: `${SI}/googlesheets` },
};
for (const [slug, v] of Object.entries(M)) {
  for (const kind of ['color','mono']) {
    try {
      const r = await fetch(v[kind]);
      if (!r.ok) { console.log('FAIL', kind, slug, r.status); continue; }
      const t = await r.text();
      if (!t.includes('<svg')) { console.log('NOTSVG', kind, slug); continue; }
      await writeFile(out(kind, slug), t);
    } catch (e) { console.log('ERR', kind, slug, e.message); }
  }
}
console.log('done');
