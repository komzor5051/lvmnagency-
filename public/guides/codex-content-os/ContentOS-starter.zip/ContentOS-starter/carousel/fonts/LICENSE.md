# Шрифты

Все четыре распространяются по SIL Open Font License 1.1, которая прямо
разрешает включать их в состав продукта.

| Файл | Шрифт | Правообладатель |
|---|---|---|
| InterTight.ttf | Inter Tight | The Inter Project Authors |
| Onest.ttf | Onest | The Onest Project Authors |
| JetBrainsMono.ttf | JetBrains Mono | The JetBrains Mono Project Authors |
| Caveat.ttf | Caveat | The Caveat Project Authors |

Текст лицензии: https://openfontlicense.org

Шрифты положены в архив, а не берутся из системы, потому что рендер
должен давать одинаковый результат на любой машине.
