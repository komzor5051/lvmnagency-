import { readFileSync } from 'node:fs';

// ── логотипы: инлайн SVG с перепрефиксом id, чтобы не было коллизий на слайде
let uid = 0;
export function logo(slug, kind = 'color') {
  let svg = readFileSync(new URL(`./logos/${kind}/${slug}.svg`, import.meta.url), 'utf8');
  const p = `l${uid++}`;
  const ids = [...svg.matchAll(/id="([^"]+)"/g)].map(m => m[1]);
  for (const id of ids) {
    const esc = id.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    svg = svg.replace(new RegExp(`id="${esc}"`, 'g'), `id="${p}-${id}"`)
             .replace(new RegExp(`url\\(#${esc}\\)`, 'g'), `url(#${p}-${id})`)
             .replace(new RegExp(`href="#${esc}"`, 'g'), `href="#${p}-${id}"`);
  }
  return svg.replace(/<svg/, '<svg preserveAspectRatio="xMidYMid meet"')
            .replace(/\swidth="[^"]*"/, '').replace(/\sheight="[^"]*"/, '');
}


/* Кадры для стилей A и F. Слайды не знают конкретных файлов: они просят
   кадр нужного тона по индексу, поэтому набор можно менять, не трогая
   вёрстку. В архиве лежат три заглушки — замените их своими. */
let ALBUM = [];
try { ALBUM = JSON.parse(readFileSync(new URL('./photos/album/index.json', import.meta.url), 'utf8')); }
catch { ALBUM = []; }

export function shots(tone) {
  const list = tone ? ALBUM.filter(p => p.tone === tone) : ALBUM;
  // от самых тёмных к светлым: чем темнее кадр, тем меньше на нём мешающих деталей,
  // поэтому первые индексы достаются обложке и слайдам с длинным текстом
  return (list.length ? list : ALBUM)
    .slice().sort((a, b) => (a.mean ?? 128) - (b.mean ?? 128))
    .map(p => new URL(`./photos/${p.file}`, import.meta.url).href);
}

/* Кадр по порядковому номеру: слайды перебирают набор, а не держат имя файла. */
export function shot(i, tone) {
  const l = shots(tone);
  if (!l.length) throw new Error(
    'Нет кадров. Положите свои jpg в carousel/photos/album/ и опишите их\n' +
    'в photos/album/index.json: slug, file, tone (dark|mid|light), mean.'
  );
  return l[i % l.length];
}

export const photo = (name) => new URL(`./photos/${name}`, import.meta.url).href;

export const GRAIN = `url("data:image/svg+xml;utf8,${encodeURIComponent(
  `<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200"><filter id="n"><feTurbulence type="fractalNoise" baseFrequency="0.8" numOctaves="4"/></filter><rect width="200" height="200" filter="url(#n)" opacity="0.5"/></svg>`
)}")`;

// Шрифты подключаются из архива, а не из системы: у покупателя они не
// установлены, а рендер обязан быть воспроизводимым на любой машине.
// Все четыре распространяются по SIL Open Font License, см. fonts/LICENSE.md.
const font = (file) => new URL(`./fonts/${file}`, import.meta.url).href;

export const BASE = `
@font-face { font-family:'Caveat'; src:url('${font('Caveat.ttf')}') format('truetype'); font-weight:400 700; }
@font-face { font-family:'Inter Tight'; src:url('${font('InterTight.ttf')}') format('truetype'); font-weight:100 900; }
@font-face { font-family:'Onest'; src:url('${font('Onest.ttf')}') format('truetype'); font-weight:100 900; }
@font-face { font-family:'JetBrains Mono'; src:url('${font('JetBrainsMono.ttf')}') format('truetype'); font-weight:100 800; }
*{margin:0;padding:0;box-sizing:border-box}
html,body{width:1080px;height:1350px}
body{-webkit-font-smoothing:antialiased;text-rendering:geometricPrecision}
.slide{position:relative;width:1080px;height:1350px;overflow:hidden}
.grain{position:absolute;inset:0;background-image:${GRAIN};background-size:200px;pointer-events:none}
svg{display:block}
`;

export function page(css, body) {
  return `<!doctype html><html lang="ru"><head><meta charset="utf-8">
<style>${BASE}${css}</style></head><body>${body}</body></html>`;
}
