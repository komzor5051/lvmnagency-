// Заготовка нового поста из шаблона стиля.
//
//   node carousel/new-post.mjs <a…f> <слаг> ["Название карусели"]
//
// Стили — это шаблоны, их не правят под конкретную тему. Пост получает
// собственную копию вёрстки, поэтому эксперименты с одним постом не
// ломают остальные и не мешают следующему.
import { readFile, writeFile, mkdir, access } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const HERE = dirname(fileURLToPath(import.meta.url));
const [style, slug, title] = process.argv.slice(2);

if (!style || !slug) {
  console.error('node carousel/new-post.mjs <a|b|c|d|e|f> <слаг> ["Название"]');
  process.exit(1);
}
if (!/^[a-f]$/.test(style)) {
  console.error(`стиль указывается буквой от a до f, получено: ${style}`);
  process.exit(1);
}

const dir = join(HERE, 'posts', slug);
const dest = join(dir, 'slides.mjs');

// Перезапись затёрла бы уже написанные тексты слайдов.
try {
  await access(dest);
  console.error(`уже существует: carousel/posts/${slug}/slides.mjs`);
  process.exit(1);
} catch {}

let src = await readFile(join(HERE, 'styles', `style-${style}.mjs`), 'utf8');

// posts/<слаг>/ лежит на два уровня ниже lib.mjs, а не на один, как styles/
src = src.replace("from '../lib.mjs'", "from '../../lib.mjs'");
// Папка готовой карусели и префикс имён — по этому посту, а не по стилю.
src = src.replace(/folder\s*:\s*'[^']*'/g, `folder:'${title || slug}'`);
src = src.replace(/name\s*:\s*`[a-f]-\$\{file\.slice\(0,\s*2\)\}`/g,
                  `name:\`${slug}-\${file.slice(0,2)}\``);

await mkdir(dir, { recursive: true });
await writeFile(dest, src);

console.log(`готово: carousel/posts/${slug}/slides.mjs

Дальше:
  1. правите тексты в slides.mjs (разметку менять не нужно)
  2. node carousel/render.mjs carousel/posts/${slug}/slides.mjs
  3. node carousel/sheet.mjs ${slug}-
  4. смотрите carousel/out/_sheet.png и чините переполнения

Готовые слайды лягут в carousel/carousels/${title || slug}/`);
