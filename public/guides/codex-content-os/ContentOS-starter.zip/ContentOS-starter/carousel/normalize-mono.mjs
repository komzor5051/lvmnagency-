// simple-icons CDN отдаёт знак в фирменном цвете; для моно нужен currentColor
import { readdir, readFile, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const MONO = join(dirname(fileURLToPath(import.meta.url)), 'logos', 'mono');
for (const f of await readdir(MONO)) {
  let s = await readFile(join(MONO, f), 'utf8');
  s = s.replace(/\s(fill|stroke)="(?!none)[^"]*"/g, '')
       .replace(/<svg/, '<svg fill="currentColor"');
  await writeFile(join(MONO, f), s);
}
console.log('mono normalized');
