// Рендер слайдов в PNG 1080x1350 через системный Chrome.
//
// Исходная версия конвейера работала на puppeteer. Здесь он намеренно не
// используется: starter-kit не имеет ни одной npm-зависимости, а puppeteer
// тянет за собой отдельную сборку Chromium на несколько сотен мегабайт.
// Chrome уже стоит на машине, и его хватает — тем же способом собирается
// PDF самого гайда.
import { writeFile, mkdir, rm, copyFile } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { execFile } from 'node:child_process';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import { dirname, join } from 'node:path';

const run = promisify(execFile);
const HERE = dirname(fileURLToPath(import.meta.url));

const CHROME_CANDIDATES = [
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/Applications/Chromium.app/Contents/MacOS/Chromium',
  '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
  '/usr/bin/google-chrome',
  '/usr/bin/chromium',
  '/usr/bin/chromium-browser',
].filter(Boolean);

function findChrome() {
  // Явно заданный путь не подменяем автопоиском: молчаливый откат на
  // системный Chrome прячет опечатку в CHROME_PATH.
  if (process.env.CHROME_PATH) {
    if (existsSync(process.env.CHROME_PATH)) return process.env.CHROME_PATH;
    throw new Error(`CHROME_PATH указывает на несуществующий файл: ${process.env.CHROME_PATH}`);
  }
  const found = CHROME_CANDIDATES.find((p) => existsSync(p));
  if (found) return found;
  throw new Error(
    'Chrome не найден. Установите Google Chrome или укажите путь:\n' +
    '  CHROME_PATH="/путь/к/chrome" node carousel/render.mjs a'
  );
}

const WIDTH = 1080;
const HEIGHT = 1350;

// Аргументом может быть буква стиля (a…f) или путь к файлу поста,
// созданному через new-post.mjs.
const which = process.argv.slice(2).filter((a) => !a.startsWith('-'));
const targets = which.length ? which : ['a', 'b', 'c', 'd', 'e', 'f'];
// Множитель масштаба с последующим уменьшением заметно улучшает мелкий текст.
const scaleArg = process.argv.find((a) => a.startsWith('--scale='));
const scale = scaleArg ? Number(scaleArg.split('=')[1]) : 1;

const chrome = findChrome();
const outDir = join(HERE, 'out');
await mkdir(outDir, { recursive: true });

if (!existsSync(join(HERE, 'logos', 'color', 'claude.svg'))) {
  console.error(
    'Библиотека логотипов пуста. Логотипы не входят в архив: это чужие\n' +
    'товарные знаки. Скачайте их один раз:\n' +
    '  npm run carousel:logos\n'
  );
  process.exit(1);
}

const folders = new Set();
let count = 0;
for (const target of targets) {
  const modPath = target.endsWith('.mjs')
    ? (target.startsWith('/') ? target : join(process.cwd(), target))
    : join(HERE, 'styles', `style-${target}.mjs`);
  if (!existsSync(modPath)) {
    console.error(`не найден: ${modPath}`);
    process.exit(1);
  }
  const { slides } = await import(pathToFileURL(modPath).href);

  for (const slide of slides) {
    const htmlPath = join(outDir, `${slide.name}.html`);
    const pngPath = join(outDir, `${slide.name}.png`);
    await writeFile(htmlPath, slide.html);

    await run(chrome, [
      '--headless',
      '--disable-gpu',
      '--no-sandbox',
      '--hide-scrollbars',
      '--allow-file-access-from-files',
      '--font-render-hinting=none',
      // Даёт браузеру дорисовать шрифты и фоновые изображения до снимка.
      '--virtual-time-budget=6000',
      `--force-device-scale-factor=${scale}`,
      `--window-size=${WIDTH},${HEIGHT}`,
      `--screenshot=${pngPath}`,
      pathToFileURL(htmlPath).href,
    ]).catch((e) => {
      // Chrome пишет предупреждения в stderr и при успешном снимке,
      // поэтому ошибкой считаем только отсутствие файла.
      if (!existsSync(pngPath)) throw e;
    });

    if (!existsSync(pngPath)) {
      throw new Error(`снимок не создан: ${slide.name}`);
    }
    await rm(htmlPath);

    // Готовая карусель складывается отдельно и с читаемыми именами:
    // из этой папки слайды публикуются как есть, без переименования.
    if (slide.folder) {
      const dir = join(HERE, 'carousels', slide.folder);
      await mkdir(dir, { recursive: true });
      await copyFile(pngPath, join(dir, `${slide.file ?? slide.name}.png`));
      folders.add(slide.folder);
    }

    console.log('готов', `${slide.name}.png`);
    count++;
  }
}

console.log(`\n${count} слайдов в carousel/out/`);
for (const f of folders) {
  console.log(`готово к публикации: carousel/carousels/${f}/`);
}
if (scale !== 1) {
  console.log(`Сняты в масштабе ${scale}x: ${WIDTH * scale}x${HEIGHT * scale}.`);
}
