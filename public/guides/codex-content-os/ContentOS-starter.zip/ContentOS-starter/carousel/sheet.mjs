// Контактный лист: все слайды серии одной картинкой.
//
//   node carousel/sheet.mjs <префикс имён в out/> [колонок]
//
// Карусель оценивается целиком. Ритм, чередование плотных и свободных
// слайдов, работу акцента и провалы вёрстки видно только когда слайды
// лежат рядом. По одному они всегда выглядят приемлемо.
import { readdir, writeFile, rm, mkdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';

const run = promisify(execFile);
const HERE = dirname(fileURLToPath(import.meta.url));
const OUT = join(HERE, 'out');

const CHROME_CANDIDATES = [
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/Applications/Chromium.app/Contents/MacOS/Chromium',
  '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
  '/usr/bin/google-chrome',
  '/usr/bin/chromium',
  '/usr/bin/chromium-browser',
];

function findChrome() {
  if (process.env.CHROME_PATH) {
    if (existsSync(process.env.CHROME_PATH)) return process.env.CHROME_PATH;
    throw new Error(`CHROME_PATH указывает на несуществующий файл: ${process.env.CHROME_PATH}`);
  }
  const found = CHROME_CANDIDATES.find((p) => existsSync(p));
  if (found) return found;
  throw new Error('Chrome не найден. Укажите путь через CHROME_PATH.');
}

const prefix = process.argv[2] || '';
const cols = Number(process.argv[3] || 4);

if (!existsSync(OUT)) {
  console.error('Папки carousel/out/ нет. Сначала отрендерьте слайды.');
  process.exit(1);
}

const files = (await readdir(OUT))
  .filter((f) => f.startsWith(prefix) && f.endsWith('.png') && f !== '_sheet.png')
  .sort();

if (!files.length) {
  console.error(`нет файлов carousel/out/${prefix}*.png`);
  process.exit(1);
}

const cells = files
  .map((f) => {
    const href = pathToFileURL(resolve(OUT, f)).href;
    return `<div class="c"><img src="${href}"><span>${f.slice(0, -4)}</span></div>`;
  })
  .join('');

// Ширина листа фиксирована, высота считается по числу рядов: снимок
// делается по размеру окна, полностраничного режима у Chrome в CLI нет.
const CELL = Math.floor((1500 - 8 * (cols + 1)) / cols);
const rows = Math.ceil(files.length / cols);
const height = rows * (Math.round((CELL * 1350) / 1080) + 8) + 8;

const html = `<!doctype html><meta charset="utf-8"><style>
body{margin:0;background:#8a8a8a;font:13px -apple-system,system-ui,sans-serif;
     display:grid;grid-template-columns:repeat(${cols},1fr);gap:8px;padding:8px}
.c{position:relative}.c img{width:100%;display:block}
.c span{position:absolute;left:0;top:0;background:#000;color:#fff;padding:3px 7px}
</style>${cells}`;

await mkdir(OUT, { recursive: true });
const htmlPath = join(OUT, '_sheet.html');
const pngPath = join(OUT, '_sheet.png');
await writeFile(htmlPath, html);

await run(findChrome(), [
  '--headless',
  '--disable-gpu',
  '--no-sandbox',
  '--hide-scrollbars',
  '--allow-file-access-from-files',
  '--virtual-time-budget=8000',
  `--window-size=1500,${height}`,
  `--screenshot=${pngPath}`,
  pathToFileURL(htmlPath).href,
]).catch((e) => {
  if (!existsSync(pngPath)) throw e;
});

await rm(htmlPath);
console.log(`carousel/out/_sheet.png — ${files.length} слайдов, ${cols} в ряд`);
console.log('Откройте его и проверьте: переполнения, обрезанный текст,');
console.log('пустые нижние трети, повтор одинаковых слайдов подряд.');
