import { logo, page, shot } from '../lib.mjs';

/* Стиль A «Лайм-журнал» — карусель «Пять ошибок в постановке задачи агенту», 9 слайдов */

const CSS = `
.slide{background:#E9E7E0;color:#101010;font-family:'Onest',sans-serif}
.grain{opacity:.13;mix-blend-mode:multiply}
.pad{position:absolute;inset:0;padding:52px 68px}
.hd{display:flex;justify-content:space-between;align-items:baseline;
    font:600 19px/1 'Onest';letter-spacing:.18em;text-transform:uppercase}
.hd .n b{color:#7E9B1C;font-weight:700}
.hd .r{color:#7C7A72}
.rule{height:1px;background:#101010;opacity:.3;margin-top:14px}
.rule.thin{opacity:.18}
.plus{position:absolute;font:200 34px/1 'Onest';color:#101010;opacity:.5}
.vert{position:absolute;writing-mode:vertical-rl;font:600 16px/1 'Onest';
      letter-spacing:.34em;text-transform:uppercase;color:#8A887F}
.pgn{position:absolute;right:68px;bottom:44px;width:66px;height:66px;background:#101010;color:#C8F04C;
     display:grid;place-items:center;font:900 26px/1 'Inter Tight'}
h1{font-family:'Inter Tight';font-weight:900;text-transform:uppercase;
   font-size:98px;line-height:.92;letter-spacing:-.025em}
h2{font-family:'Inter Tight';font-weight:900;text-transform:uppercase;
   font-size:80px;line-height:.94;letter-spacing:-.025em}
h1 .lime,h2 .lime{background:#C8F04C;padding:0 .06em;box-decoration-break:clone}
.kicker{font:900 72px/1 'Inter Tight';color:#7E9B1C}
.lead{font:400 24px/1.45 'Onest';padding-left:20px;border-left:3px solid #C8F04C}
.txt{font:400 24px/1.5 'Onest'}
.mark{background:#C8F04C;padding:0 .1em;box-decoration-break:clone}
.small{font:600 17px/1 'Onest';letter-spacing:.18em;text-transform:uppercase;color:#7C7A72}
.tex{position:absolute;right:0;top:0;width:248px;height:100%}
.tex .ph{position:absolute;left:0;right:0;background-size:cover;background-position:58% 50%;
   filter:grayscale(1) contrast(1.45) brightness(.92)}
.tex .lm{position:absolute;left:0;right:0;background:#C8F04C}
.tab{display:inline-block;background:#C8F04C;font:700 16px/1 'Onest';letter-spacing:.16em;
     text-transform:uppercase;padding:9px 14px;margin-bottom:-1px}
.box{border:1px solid #101010;padding:22px 24px}
.cards{display:grid;grid-template-columns:1fr 1fr;gap:20px}
.card{padding:22px 24px 26px;display:flex;flex-direction:column}
.card.bad{background:#101010;color:#EDEBE4}
.card.good{background:#C8F04C;color:#101010}
.card.weak{background:#C9C6BE;color:#3A3A36}
.card .lbl{display:flex;justify-content:space-between;align-items:center;
   font:700 17px/1 'Onest';letter-spacing:.18em;text-transform:uppercase;
   padding-bottom:12px;border-bottom:1px solid currentColor}
.card .lbl .s{font-size:24px}
.card q{display:block;margin-top:20px;font:400 21px/1.45 'JetBrains Mono';quotes:none}
.card .why{margin-top:auto;padding-top:18px;font:400 19px/1.35 'Onest';opacity:.75}
.bar{background:#101010;color:#EDEBE4;display:flex;align-items:center;gap:20px;padding:22px 28px}
.bar .t{font:800 24px/1 'Inter Tight';letter-spacing:.06em;text-transform:uppercase;color:#C8F04C}
.bar .s{font:400 21px/1.3 'Onest'}
.strip{display:flex;gap:28px;align-items:center;color:#101010;opacity:.8}
.strip span{width:32px;height:32px}.strip svg{width:100%;height:100%}
.chk{display:flex;gap:20px;align-items:flex-start;padding:20px 0;border-bottom:1px solid rgba(16,16,16,.18)}
.chk .b{width:34px;height:34px;border:2px solid #101010;flex:none;margin-top:2px}
.chk .t{font:400 24px/1.35 'Onest'}
.flow{display:flex;align-items:stretch;gap:0}
.flow .st{flex:1;border:1px solid #101010;padding:18px 18px 20px}
.flow .st .n{font:900 22px/1 'Inter Tight';color:#7E9B1C}
.flow .st .t{font:700 22px/1.2 'Onest';margin-top:10px}
.flow .st .d{font:400 18px/1.3 'Onest';color:#5E5C55;margin-top:6px}
.flow .ar{width:40px;display:grid;place-items:center;font:700 26px 'Onest';color:#7E9B1C}
.inv{position:absolute;left:68px;right:236px;top:104px;bottom:150px;background:#101010;color:#EDEBE4;padding:56px 52px}
.inv h1{font-size:88px}
.inv .lime{background:none;color:#C8F04C}
.inv .cta{font:400 27px/1.5 'Onest';color:#C9C6BE;margin-top:30px}
.inv .cta b{color:#fff;font-weight:700}
`;

const RUB = 'Задачи для агента / Claude / Практика';
const head = (n) => `<div class="hd"><span class="n"><b>${n}</b> / 09</span><span class="r">${RUB}</span></div><div class="rule"></div>`;
const marks = `<span class="plus" style="left:22px;top:18px">+</span><span class="plus" style="right:22px;top:18px">+</span>
<span class="plus" style="left:22px;bottom:18px">+</span><span class="plus" style="right:22px;bottom:18px">+</span>`;
const tex = (blocks) => `<div class="tex">${blocks}</div>`;
let texN = 0;
const ph  = (top,h) => `<div class="ph" style="top:${top}px;height:${h}px;background-image:url('${shot(texN++)}')"></div>`;
const lm  = (top,h) => `<div class="lm" style="top:${top}px;height:${h}px"></div>`;

const S = [];
const add = (file, body) => S.push({ name:`a-${file.slice(0,2)}`, file, folder:'A — Лайм-журнал', html: page(CSS, body) });

/* 01 — обложка */
add('01 обложка', `<div class="slide"><div class="grain"></div>
  ${tex(ph(150,470) + lm(650,150) + ph(830,230))}
  ${marks}
  <div class="vert" style="right:266px;top:150px">выпуск 04 · август 2026</div>
  <div class="pad" style="padding-right:300px">
    ${head('01')}
    <h1 style="margin-top:96px">Агент<br>не тупой.<br>Задача<br><span class="lime">плохая.</span></h1>
    <div class="rule thin" style="margin-top:44px"></div>
    <p class="lead" style="margin-top:34px">Год я ставил задачи агентам так же, как ставил бы джуну.
    И год получал ответ джуна. Пять ошибок — каждую делал сам, каждую вижу в чужих промптах.</p>
    <div class="strip" style="margin-top:38px">
      <span>${logo('claude','mono')}</span><span>${logo('cursor','mono')}</span>
      <span>${logo('telegram','mono')}</span><span>${logo('supabase','mono')}</span>
      <span>${logo('obsidian','mono')}</span></div>
    <div style="position:absolute;left:68px;right:300px;bottom:150px">
      <div class="rule thin"></div>
      <div style="display:flex;gap:40px;margin-top:18px">
        ${[['01','Контекст'],['02','Формат ответа'],['03','Критерий'],['04','Право отказаться'],['05','Память']]
          .map(([n,t])=>`<div><div class="small" style="color:#7E9B1C">${n}</div>
            <div style="font:600 19px/1.2 'Onest';margin-top:6px">${t}</div></div>`).join('')}
      </div>
    </div>
    <div class="bar" style="position:absolute;left:68px;right:300px;bottom:52px">
      <span class="t">Листай дальше</span><span class="s">разбор на девять слайдов</span></div>
  </div>
  <div class="pgn">01</div></div>`);

/* 02 — боль */
add('02 боль', `<div class="slide"><div class="grain"></div>
  ${tex(lm(120,120) + ph(260,420))}
  ${marks}
  <div class="vert" style="right:266px;bottom:140px">почему ответы средние</div>
  <div class="pad" style="padding-right:300px">
    ${head('02')}
    <h2 style="margin-top:56px">Ты пишешь<br>просьбу.<br>Нужно —<br><span class="lime">техзадание.</span></h2>
    <p class="txt" style="margin-top:40px">Просьба звучит вежливо и не содержит ничего проверяемого.
    Агент делает <span class="mark">среднее по интернету</span> — потому что больше опереться не на что.</p>
    <div style="margin-top:34px">
      <span class="tab">Как это выглядит</span>
      <div class="box">
        <div style="font:400 22px/1.5 'JetBrains Mono';color:#3A3A36">
        «Помоги с постом»<br>«Сделай красиво»<br>«Напиши как эксперт»</div>
        <div class="rule thin" style="margin:20px 0"></div>
        <div class="txt" style="font-size:22px">Ни одна из трёх фраз не даёт агенту ни роли, ни входных данных,
        ни признака, по которому он поймёт, что закончил.</div>
      </div>
    </div>
    <div class="bar" style="position:absolute;left:68px;right:300px;bottom:52px">
      <span class="t">Дальше</span><span class="s">пять ошибок по порядку</span></div>
  </div>
  <div class="pgn">02</div></div>`);

/* 03 — ошибка 1 */
add('03 ошибка 1', `<div class="slide"><div class="grain"></div>
  ${tex(ph(120,300) + lm(450,110) + ph(590,330) + lm(950,60))}
  ${marks}
  <div class="vert" style="right:266px;bottom:150px">ошибка первая из пяти</div>
  <div class="pad" style="padding-right:300px">
    ${head('03')}
    <div style="display:flex;align-items:baseline;gap:16px;margin-top:40px">
      <span class="kicker">1.</span><h2>Контекст</h2></div>
    <div style="height:5px;background:#C8F04C;width:168px;margin-top:14px"></div>
    <p class="txt" style="margin-top:26px">
      Агент не знает, <span class="mark">кто ты и что уже пробовал</span>. Без этого он выдаёт
      среднее по интернету — и оно всегда мимо на полшага.</p>
    <div class="cards" style="margin-top:32px">
      <div class="card bad" style="min-height:326px"><div class="lbl"><span>Неправильно</span><span class="s">✕</span></div>
        <q>Напиши пост про автоматизацию</q>
        <div class="why">Нет роли, нет входа, нет формата. Агент угадывает — и не угадывает.</div></div>
      <div class="card good" style="min-height:326px"><div class="lbl"><span>Правильно</span><span class="s">✓</span></div>
        <q>Ты пишешь от лица соло-фаундера. Вход — расшифровка ниже. Дай 3 тезиса, каждый с цифрой из текста.</q>
        <div class="why">Роль, вход, формат, критерий. Четыре строки — ответ пригоден с первого раза.</div></div>
    </div>
    <div style="margin-top:26px">
      <span class="tab">Тест</span>
      <div class="box"><span class="txt" style="font-size:22px">Убери из промпта любую из четырёх частей.
        Если ответ поплыл — часть была нужна. Если нет — она была украшением.</span></div>
    </div>
  </div>
  <div class="pgn">03</div></div>`);

/* 04 — ошибка 2 */
add('04 ошибка 2', `<div class="slide"><div class="grain"></div>
  ${tex(lm(140,90) + ph(260,380) + lm(670,140))}
  ${marks}
  <div class="vert" style="right:266px;bottom:150px">ошибка вторая из пяти</div>
  <div class="pad" style="padding-right:300px">
    ${head('04')}
    <div style="display:flex;align-items:baseline;gap:16px;margin-top:40px">
      <span class="kicker">2.</span><h2>Формат<br>ответа</h2></div>
    <div style="height:5px;background:#C8F04C;width:168px;margin-top:14px"></div>
    <p class="txt" style="margin-top:26px">Если не сказать, в каком виде нужен ответ, придёт эссе.
    Эссе нельзя вставить в работу — его надо переписывать, и ты делаешь работу дважды.</p>
    <div style="margin-top:30px">
      <span class="tab">Формула</span>
      <div class="box">
        <div class="flow">
          <div class="st"><div class="n">01</div><div class="t">Роль</div><div class="d">чей голос и чья насмотренность</div></div>
          <div class="ar">→</div>
          <div class="st"><div class="n">02</div><div class="t">Вход</div><div class="d">что дано и где это лежит</div></div>
          <div class="ar">→</div>
          <div class="st"><div class="n">03</div><div class="t">Формат</div><div class="d">таблица, список, JSON, абзац</div></div>
          <div class="ar">→</div>
          <div class="st"><div class="n">04</div><div class="t">Критерий</div><div class="d">когда считается готовым</div></div>
        </div>
      </div>
    </div>
    <div style="margin-top:26px" class="cards">
      <div class="card weak"><div class="lbl"><span>Расплывчато</span><span class="s">✕</span></div>
        <q>Разбери эти отзывы</q></div>
      <div class="card good"><div class="lbl"><span>Проверяемо</span><span class="s">✓</span></div>
        <q>Таблица: боль · частота · цитата. Не больше 7 строк.</q></div>
    </div>
  </div>
  <div class="pgn">04</div></div>`);

/* 05 — ошибка 3 */
add('05 ошибка 3', `<div class="slide"><div class="grain"></div>
  ${tex(ph(130,340) + lm(500,160))}
  ${marks}
  <div class="vert" style="right:266px;bottom:150px">ошибка третья из пяти</div>
  <div class="pad" style="padding-right:300px">
    ${head('05')}
    <div style="display:flex;align-items:baseline;gap:16px;margin-top:40px">
      <span class="kicker">3.</span><h2>Критерий<br>готовности</h2></div>
    <div style="height:5px;background:#C8F04C;width:168px;margin-top:14px"></div>
    <p class="txt" style="margin-top:26px">«Сделай хорошо» — не критерий. Критерий это то,
    что <span class="mark">можно проверить, не читая весь текст</span>.</p>
    <div class="cards" style="margin-top:32px">
      <div class="card weak" style="min-height:300px"><div class="lbl"><span>Слабо</span><span class="s">✕</span></div>
        <q>Напиши убедительно и по делу</q>
        <div class="why">Убедительность оценивает автор, а не агент. Он не знает, попал или нет.</div></div>
      <div class="card bad" style="min-height:300px"><div class="lbl"><span>Сильно</span><span class="s">✓</span></div>
        <q>Каждый абзац — одно утверждение и одна цифра из исходника. Абзацев ровно пять.</q>
        <div class="why">Агент может сам себя проверить и переписать до того, как покажет тебе.</div></div>
    </div>
    <div class="bar" style="position:absolute;left:68px;right:300px;bottom:52px">
      <span class="t">Правило</span><span class="s">критерий — это то, что можно посчитать или найти глазами</span></div>
  </div>
  <div class="pgn">05</div></div>`);

/* 06 — ошибка 4 */
add('06 ошибка 4', `<div class="slide"><div class="grain"></div>
  ${tex(lm(130,140) + ph(300,400))}
  ${marks}
  <div class="vert" style="right:266px;bottom:150px">ошибка четвёртая из пяти</div>
  <div class="pad" style="padding-right:300px">
    ${head('06')}
    <div style="display:flex;align-items:baseline;gap:16px;margin-top:40px">
      <span class="kicker">4.</span><h2>Право<br>отказаться</h2></div>
    <div style="height:5px;background:#C8F04C;width:168px;margin-top:14px"></div>
    <p class="txt" style="margin-top:26px">Агент по умолчанию старается ответить всегда.
    Если данных не хватает — он <span class="mark">достроит их сам</span>, и ты об этом не узнаешь.</p>
    <div style="margin-top:30px">
      <span class="tab">Строка, которая это чинит</span>
      <div class="box"><div style="font:400 23px/1.6 'JetBrains Mono'">
        Если данных не хватает — не выдумывай.<br>Напиши, чего не хватает, и остановись.</div></div>
    </div>
    <div class="bar" style="margin-top:30px;align-items:flex-start">
      <span class="t" style="white-space:nowrap">Так не надо</span>
      <span class="s">«Примерно 30-40% пользователей» — цифра, которой не было ни в одном источнике.
      Это не ошибка модели, это отсутствие разрешения сказать «не знаю».</span></div>
  </div>
  <div class="pgn">06</div></div>`);

/* 07 — ошибка 5 */
add('07 ошибка 5', `<div class="slide"><div class="grain"></div>
  ${tex(ph(140,320) + lm(490,120) + ph(640,300))}
  ${marks}
  <div class="vert" style="right:266px;bottom:150px">ошибка пятая из пяти</div>
  <div class="pad" style="padding-right:300px">
    ${head('07')}
    <div style="display:flex;align-items:baseline;gap:16px;margin-top:40px">
      <span class="kicker">5.</span><h2>Память</h2></div>
    <div style="height:5px;background:#C8F04C;width:168px;margin-top:14px"></div>
    <p class="txt" style="margin-top:26px">Ты объясняешь одно и то же каждую сессию. Двенадцать минут в день,
    час в неделю. Всё это <span class="mark">пишется один раз в файл</span> и читается автоматически.</p>
    <div style="margin-top:30px">
      <span class="tab">CLAUDE.md в корне проекта</span>
      <div class="box">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px 30px">
          ${[['Кто я','роль, стек, как принимаю решения'],['Запреты','что не писать никогда'],
             ['Формат','как выглядит хороший ответ'],['История','что уже пробовал и отклонил']]
            .map(([t,d])=>`<div><div style="font:700 22px/1.2 'Onest'">${t}</div>
              <div style="font:400 19px/1.3 'Onest';color:#5E5C55;margin-top:5px">${d}</div></div>`).join('')}
        </div>
        <div class="rule thin" style="margin:22px 0 18px"></div>
        <div class="strip"><span>${logo('claude','mono')}</span><span>${logo('cursor','mono')}</span>
          <span style="width:auto;font:400 20px/1 'Onest';color:#5E5C55">— читают один и тот же файл</span></div>
      </div>
    </div>
    <div class="bar" style="position:absolute;left:68px;right:300px;bottom:52px">
      <span class="t">Итого</span><span class="s">двенадцать минут на сессию → ноль, файл пишется один раз</span></div>
  </div>
  <div class="pgn">07</div></div>`);

/* 08 — чек-лист */
add('08 чек-лист', `<div class="slide"><div class="grain"></div>
  ${tex(lm(120,100) + ph(250,430) + lm(710,120))}
  ${marks}
  <div class="vert" style="right:266px;bottom:150px">сохрани этот слайд</div>
  <div class="pad" style="padding-right:300px">
    ${head('08')}
    <h2 style="margin-top:44px">Чек-<span class="lime">лист</span></h2>
    <p class="txt" style="margin-top:20px;font-size:22px">Прогони свой последний промпт по пяти пунктам.
    Каждый непоставленный флажок — это одна переписка туда-обратно.</p>
    <div style="margin-top:24px">
      ${['Указана роль: от чьего лица и с какой насмотренностью',
         'Есть вход: что дано и где это лежит',
         'Задан формат ответа, который можно вставить в работу',
         'Есть критерий готовности, проверяемый без чтения целиком',
         'Разрешено сказать «данных не хватает» и остановиться']
        .map(t=>`<div class="chk"><div class="b"></div><div class="t">${t}</div></div>`).join('')}
    </div>
    <div class="bar" style="position:absolute;left:68px;right:300px;bottom:52px">
      <span class="t">Дальше</span><span class="s">заберёшь все пять промптов текстом</span></div>
  </div>
  <div class="pgn">08</div></div>`);

/* 09 — финал */
add('09 финал', `<div class="slide"><div class="grain"></div>
  ${marks}
  <div style="position:absolute;right:68px;top:104px;width:56px;height:56px;background:#C8F04C"></div>
  <div class="vert" style="right:82px;top:190px">промпт как техзадание, а не как просьба</div>
  <div class="inv">
    <div style="display:flex;justify-content:space-between;align-items:baseline;
                font:600 17px/1 'Onest';letter-spacing:.18em;text-transform:uppercase;color:#7C7A72">
      <span>09 / 09</span><span>Финал</span></div>
    <div style="height:1px;background:#2A2A26;margin-top:14px"></div>
    <h1 style="margin-top:64px">Напиши<br><span class="lime">«промпт»</span></h1>
    <p class="cta">Пришлю все пять переписанных промптов текстом — <b>копируй и подставляй свои задачи.</b>
      Плюс шаблон на четыре строки, которым пользуюсь сам каждый день.</p>
    <div style="height:1px;background:#2A2A26;margin:38px 0 26px"></div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:18px 34px">
      ${[['01','Роль и чей голос'],['02','Вход: что дано'],['03','Формат ответа'],
         ['04','Критерий готовности'],['05','Право сказать «не могу»']]
        .map(([n,t])=>`<div style="display:flex;gap:14px;align-items:baseline">
          <span style="font:900 20px 'Inter Tight';color:#C8F04C">${n}</span>
          <span style="font:400 22px/1.3 'Onest';color:#C9C6BE">${t}</span></div>`).join('')}
    </div>
    <div class="strip" style="position:absolute;left:52px;bottom:52px;color:#EDEBE4;opacity:.65">
      <span>${logo('claude','mono')}</span><span>${logo('openai','mono')}</span>
      <span>${logo('cursor','mono')}</span><span>${logo('railway','mono')}</span></div>
  </div>
  <div style="position:absolute;left:68px;bottom:88px;font:600 18px/1 'Onest';
              letter-spacing:.18em;text-transform:uppercase">Спасибо, что дошёл до конца</div>
  <div class="pgn">09</div></div>`);

export const slides = S;
