import { logo, page } from '../lib.mjs';

/* Стиль B «Блюпринт» — карусель «Контент-завод», 10 слайдов */

const CSS = `
.slide{background:#F4F5F7;color:#111;font-family:'Onest',sans-serif;
  background-image:linear-gradient(rgba(17,17,17,.045) 1px,transparent 1px),
                   linear-gradient(90deg,rgba(17,17,17,.045) 1px,transparent 1px);
  background-size:45px 45px}
.pad{position:absolute;inset:0;padding:62px 72px}
.lock{display:flex;align-items:center;gap:18px;height:40px}
.lock .i{width:38px;height:38px}.lock .i svg{width:100%;height:100%}
.lock .nm{font:800 30px/1 'Inter Tight';letter-spacing:-.01em}
.lock .sep{width:1px;height:32px;background:#C9CCD2}
.badge{display:inline-flex;align-items:center;background:#C8F04C;color:#111;
  font:700 20px/1 'Onest';letter-spacing:.16em;text-transform:uppercase;padding:13px 20px;margin-top:34px}
h1{font-family:'Inter Tight';font-weight:900;text-transform:uppercase;font-size:76px;line-height:.98;
   letter-spacing:-.02em;margin-top:22px}
h1 em{font-style:normal;background:#C8F04C;padding:0 .05em;box-decoration-break:clone}
p.body{font:400 26px/1.5 'Onest';margin-top:24px;max-width:760px;color:#26262A}
.hand{font-family:'Caveat';font-weight:700;font-size:38px;color:#4B5A16;transform:rotate(-3deg)}
.card{background:#fff;border:1px solid #E3E5E9;border-radius:14px;
      box-shadow:0 18px 40px rgba(20,25,40,.07)}
.win .tb{display:flex;align-items:center;gap:9px;padding:13px 16px;border-bottom:1px solid #EDEFF2;
   background:#FBFBFC;border-radius:14px 14px 0 0}
.win{overflow:hidden}
.win .tb i{width:11px;height:11px;border-radius:50%;display:block}
.win .tb .t{margin-left:12px;font:500 17px/1 'Onest';color:#8A8F99}
.chain{display:flex;align-items:stretch}
.node{flex:1;padding:18px 16px}
.node .ic{display:block;width:46px;height:46px}.node .ic svg{width:100%;height:100%}
.node .t{font:700 21px/1.25 'Onest';margin-top:14px}
.node .s{font:400 17px/1.3 'Onest';color:#7A7F88;margin-top:5px}
.arw{width:52px;flex:none;display:grid;place-items:center;color:#A8D030;font-size:30px;font-weight:700}
.result{background:#111;color:#fff;border-color:#111}
.result .t{color:#C8F04C}.result .s{color:#B9BCC2}
.rowlogo{display:flex;align-items:center;gap:14px}
.rowlogo .i{width:34px;height:34px}.rowlogo .i svg{width:100%;height:100%}
.foot{position:absolute;left:72px;right:72px;bottom:44px;display:flex;justify-content:space-between;
      font:500 19px/1 'Onest';color:#9AA0A9}
.metric{display:flex;align-items:baseline;gap:16px;font-family:'Inter Tight';font-weight:900}
.metric .a{font-size:64px;color:#9AA0A9;text-decoration:line-through}
.metric .b{font-size:96px;color:#111}
.metric .u{font:600 24px/1 'Onest';color:#7A7F88}
.pill{display:inline-flex;align-items:center;gap:14px;background:#111;color:#fff;
  font:800 26px/1 'Inter Tight';letter-spacing:.06em;text-transform:uppercase;padding:24px 34px;border-radius:999px}
.pill b{color:#C8F04C}
.kv{font:600 19px/1 'Onest';letter-spacing:.16em;text-transform:uppercase;color:#8A8F99}
.chip{display:inline-block;background:#C8F04C;font:700 14px/1 'Onest';letter-spacing:.14em;
  text-transform:uppercase;padding:6px 10px}
.rank{display:flex;align-items:center;gap:18px;padding:15px 18px;border:1px solid #E3E5E9;
  background:#fff;border-radius:12px}
.rank .n{width:38px;height:38px;background:#C8F04C;display:grid;place-items:center;
  font:900 19px 'Inter Tight';flex:none}
.rank .t{font:700 21px/1.2 'Onest';flex:1}
.rank .bars{display:flex;gap:3px}
.rank .bars i{width:13px;height:20px;background:#E3E5E9;display:block}
.rank .bars i.on{background:#A8D030}
.rank .p{font:900 24px 'Inter Tight';width:74px;text-align:right}
.rank.out{opacity:.38}
.deck{display:flex;gap:16px}
.deck .c{flex:1;background:#fff;border:1px solid #E3E5E9;border-radius:12px;padding:18px 16px;
  box-shadow:0 14px 30px rgba(20,25,40,.08)}
.deck .c .h{font:700 20px/1.25 'Onest';margin-top:12px}
.deck .c .d{font:400 16px/1.3 'Onest';color:#7A7F88;margin-top:6px}
.cal{display:grid;grid-template-columns:90px repeat(7,1fr);gap:8px;font:500 17px/1 'Onest'}
.cal .h{color:#8A8F99;text-align:center;padding-bottom:4px}
.cal .t{color:#8A8F99;display:flex;align-items:center}
.cal .cell{height:44px;border:1px solid #E9EBEF;border-radius:8px;display:grid;place-items:center;color:#A8D030;font-weight:700}
.cal .cell.on{background:rgba(200,240,76,.22);border-color:#C8F04C}
`;

const lock = (...s) => `<div class="lock">${s.map((x,i)=>
  `${i?'<span class="sep"></span>':''}<span class="i">${logo(x)}</span>`).join('')}
  <span class="nm">Контент-завод</span></div>`;
const node = (slug,t,d,cls='') => `<div class="node card ${cls}">
  <span class="ic">${logo(slug)}</span><div class="t">${t}</div><div class="s">${d}</div></div>`;
const win = (title, inner, style='') => `<div class="card win" style="${style}">
  <div class="tb"><i style="background:#F0655A"></i><i style="background:#F0BE4F"></i><i style="background:#8FC96A"></i>
    <span class="t">${title}</span></div>${inner}</div>`;

const S = [];
const add = (file, body) => S.push({ name:`b-${file.slice(0,2)}`, file, folder:'B — Блюпринт', html: page(CSS, body) });
const foot = n => `<div class="foot"><span>@vladlyamin</span><span>${n} / 10</span></div>`;

/* 01 */
add('01 обложка', `<div class="slide"><div class="pad">
  ${lock('claude','telegram','supabase')}
  <h1 style="margin-top:52px;font-size:88px">Одна голосовая.<br><em>Восемь постов.</em></h1>
  <p class="body">Записываю мысль на ходу — через двадцать минут в черновиках лежат восемь готовых
  текстов под три площадки. Разбираю конвейер по этапам: что делает Claude, что скрипт, где остаюсь я.</p>
  ${win('Telegram · голосовое 4:12', `<div style="padding:34px 30px">
      <div style="display:flex;align-items:center;gap:16px">
        <div style="width:52px;height:52px;border-radius:50%;background:#C8F04C;display:grid;place-items:center;font:900 24px 'Inter Tight'">▶</div>
        <div style="flex:1;height:34px;display:flex;align-items:center;gap:4px">
          ${Array.from({length:44},(_,i)=>`<span style="flex:1;height:${8+Math.abs(Math.sin(i*.9))*24}px;background:${i<18?'#111':'#CBD0D8'}"></span>`).join('')}
        </div><div style="font:500 19px 'Onest';color:#8A8F99">4:12</div></div>
      <div style="margin-top:28px;font:400 22px/1.5 'Onest';color:#4A4F58">
        «Сегодня понял, почему у клиентов автоматизация умирает на третьей неделе. Дело не в инструменте…»</div>
    </div>`, 'position:absolute;left:72px;right:400px;top:600px;height:470px')}
  <div class="hand" style="position:absolute;right:96px;top:600px;width:250px;text-align:center">сырьё — три минуты болтовни</div>
  <div style="position:absolute;right:72px;top:700px;width:300px;display:flex;flex-direction:column;gap:12px">
    ${['Пост в Telegram','Тред в Threads','Сценарий рилса','Письмо в рассылку'].map((t,i)=>
      `<div class="card" style="padding:16px 18px;transform:rotate(${i%2?1:-1}deg)">
         <div style="font:700 12px 'Onest';letter-spacing:.18em;text-transform:uppercase;color:#7A7F88">черновик 0${i+1}</div>
         <div style="font:600 20px/1.2 'Onest';margin-top:6px">${t}</div></div>`).join('')}
  </div>
  ${foot('01')}
</div></div>`);

/* 02 — узкое место */
add('02 узкое место', `<div class="slide"><div class="pad">
  ${lock('claude','telegram')}
  <span class="badge">Почему буксует</span>
  <h1>Узкое место —<br><em>не идеи. Ты.</em></h1>
  <p class="body">Идея рождается за три минуты. Дальше девяносто минут её оформления: переписать,
  сократить, придумать заголовок, нарезать под площадки. Именно здесь всё и умирает.</p>
  <div style="position:absolute;left:72px;right:72px;top:600px;display:flex;gap:26px;align-items:stretch">
    <div style="flex:1">
      <div class="kv">Было</div>
      <div class="card" style="margin-top:14px;padding:24px;height:390px;position:relative">
        ${[['Заметка в телефоне','12%',30,40],['Черновик в Obsidian','','58%',''],['Голосовое самому себе','',180,60],
           ['Скрин с идеей','',260,180],['Забытый тред','',90,250]].map((x,i)=>
          `<div style="position:absolute;left:${[24,150,40,190,70][i]}px;top:${[30,90,170,220,290][i]}px;
            background:#F7F8FA;border:1px solid #E3E5E9;border-radius:10px;padding:11px 14px;
            font:500 17px/1.2 'Onest';color:#5A5F68;transform:rotate(${[-3,2,-1,3,-2][i]}deg)">${x[0]}</div>`).join('')}
        <div style="position:absolute;left:24px;bottom:22px;font:400 19px/1.3 'Onest';color:#A0574A">
          перегруз · непостоянно · выгорание</div>
      </div>
    </div>
    <div style="width:60px;display:grid;place-items:center;font:900 44px 'Inter Tight';color:#A8D030">→</div>
    <div style="flex:1">
      <div class="kv">Стало</div>
      <div class="card" style="margin-top:14px;padding:24px;height:390px">
        ${['Наговорил','Расшифровка','Разбор на куски','Отбор','Сборка','Публикация'].map((t,i)=>
          `<div style="display:flex;align-items:center;gap:14px;padding:9px 0">
            <span style="width:30px;height:30px;background:#111;color:#C8F04C;display:grid;place-items:center;
              font:900 15px 'Inter Tight';flex:none">0${i+1}</span>
            <span style="font:500 21px/1.2 'Onest'">${t}</span></div>`).join('')}
        <div style="margin-top:10px;font:400 19px/1.3 'Onest';color:#4B5A16">одна линия · без решений на каждом шаге</div>
      </div>
    </div>
  </div>
  <div class="hand" style="position:absolute;left:72px;bottom:120px">вкус оставить, рутину убрать</div>
  ${foot('02')}
</div></div>`);

/* 03 — этап 1 */
add('03 этап 1', `<div class="slide"><div class="pad">
  ${lock('telegram','claude')}
  <span class="badge">Этап 1 · захват</span>
  <h1>Мысль ловится<br><em>там, где приходит</em></h1>
  <p class="body">Никаких «сяду вечером и запишу». Голосовое самому себе в Telegram — три минуты,
  без формулировок и без стыда за косноязычие. Дальше это уже не моя забота.</p>
  ${win('Избранное · сегодня', `<div style="padding:26px 28px;display:flex;flex-direction:column;gap:14px">
      ${[['09:12','2:04','в метро, про третью неделю'],['14:30','4:12','после звонка с клиентом'],
         ['23:41','1:38','перед сном, про формат ответа']].map(([t,d,c])=>
        `<div style="display:flex;align-items:center;gap:16px;padding:14px 16px;background:#F7F8FA;border-radius:12px">
          <span style="width:40px;height:40px;border-radius:50%;background:#C8F04C;display:grid;place-items:center;
            font:900 17px 'Inter Tight'">▶</span>
          <span style="flex:1;height:22px;display:flex;align-items:center;gap:3px">
            ${Array.from({length:34},(_,i)=>`<span style="flex:1;height:${5+Math.abs(Math.cos(i*1.3))*16}px;background:#C3C8D0"></span>`).join('')}
          </span>
          <span style="font:500 18px 'Onest';color:#8A8F99;width:56px;text-align:right">${d}</span>
          <span style="font:400 18px 'Onest';color:#5A5F68;width:280px">${c}</span></div>`).join('')}
    </div>`, 'position:absolute;left:72px;right:72px;top:640px')}
  <div class="hand" style="position:absolute;right:110px;bottom:150px">три штуки за день — норма →</div>
  ${foot('03')}
</div></div>`);

/* 04 — этап 2 */
add('04 этап 2', `<div class="slide"><div class="pad">
  ${lock('claude','supabase')}
  <span class="badge">Этап 2 · разбор</span>
  <h1>Claude режет расшифровку<br>на <em>смысловые куски</em></h1>
  <p class="body">Не «сделай саммари». Три отдельных прохода: вытащить тезисы, вытащить истории,
  вытащить цифры. Каждый проход — свой промпт и свой формат ответа. Смешивать
  нельзя: смешанный промпт всегда даёт average-текст.</p>
  <div class="hand" style="position:absolute;right:110px;top:600px">три прохода, не один →</div>
  <div style="position:absolute;left:72px;right:72px;top:648px;display:flex;gap:18px">
    ${[['Тезисы','3 шт','«Автоматизация умирает не из-за инструмента»'],
       ['Истории','1 шт','Клиент на третьей неделе вернулся к таблицам'],
       ['Цифры','2 шт','40 часов → 6 часов в месяц']].map(([t,n,q])=>
      `<div class="card" style="flex:1;padding:22px 22px 24px">
        <div style="display:flex;justify-content:space-between;align-items:center">
          <span class="chip">${t}</span><span style="font:600 16px 'Onest';color:#8A8F99">${n}</span></div>
        <div style="font:400 19px/1.4 'Onest';color:#4A4F58;margin-top:16px">${q}</div></div>`).join('')}
  </div>
  <div class="chain" style="position:absolute;left:72px;right:72px;bottom:120px">
    ${node('telegram','Расшифровка','4:12 → 620 слов')}
    <div class="arw">→</div>
    ${node('claude','Три прохода','тезисы · истории · цифры')}
    <div class="arw">→</div>
    ${node('railway','Сборка','8 черновиков')}
    <div class="arw">→</div>
    ${node('supabase','Хранилище','статус: на вычитку','result')}
  </div>
  ${foot('04')}
</div></div>`);

/* 05 — этап 3 отбор */
add('05 этап 3', `<div class="slide"><div class="pad">
  ${lock('claude','supabase')}
  <span class="badge">Этап 3 · отбор</span>
  <h1>Из восьми кусков<br>выживают <em>четыре</em></h1>
  <p class="body">Каждый кусок получает оценку по трём признакам: есть ли конкретика, есть ли цифра,
  есть ли неочевидный вывод. Ниже порога — в архив, без сожалений.</p>
  <div style="position:absolute;left:72px;right:72px;top:620px;display:flex;flex-direction:column;gap:11px">
    ${[['01','Почему автоматизация умирает на третьей неделе',9,'92%',1],
       ['02','40 часов в месяц на одну таблицу',8,'86%',1],
       ['03','Критерий готовности вместо «сделай хорошо»',7,'74%',1],
       ['04','Формат ответа задаётся, а не угадывается',6,'68%',1]].map(([n,t,f,p])=>
      `<div class="rank"><span class="n">${n}</span><span class="t">${t}</span>
        <span class="bars">${Array.from({length:10},(_,i)=>`<i class="${i<f?'on':''}"></i>`).join('')}</span>
        <span class="p">${p}</span></div>`).join('')}
    <div style="display:flex;align-items:center;gap:16px;margin:6px 0">
      <div style="flex:1;height:1px;background:repeating-linear-gradient(90deg,#C0522D 0 8px,transparent 8px 16px)"></div>
      <span style="font:700 16px 'Onest';letter-spacing:.2em;text-transform:uppercase;color:#C0522D">Отсечка</span>
      <div style="flex:1;height:1px;background:repeating-linear-gradient(90deg,#C0522D 0 8px,transparent 8px 16px)"></div>
    </div>
    ${[['05','Мысли про дисциплину',3,'31%'],['06','Общие слова про AI',2,'18%']].map(([n,t,f,p])=>
      `<div class="rank out"><span class="n">${n}</span><span class="t">${t}</span>
        <span class="bars">${Array.from({length:10},(_,i)=>`<i class="${i<f?'on':''}"></i>`).join('')}</span>
        <span class="p">${p}</span></div>`).join('')}
  </div>
  ${foot('05')}
</div></div>`);

/* 06 — этап 4 сборка */
add('06 этап 4', `<div class="slide"><div class="pad">
  ${lock('claude','railway')}
  <span class="badge">Этап 4 · сборка</span>
  <h1>Один кусок —<br><em>четыре формата</em></h1>
  <p class="body">Тезис, который прошёл отбор, разворачивается под каждую площадку отдельно.
  Не «адаптируй текст», а четыре разных промпта с разной длиной, ритмом и целью.</p>
  <div class="deck" style="position:absolute;left:72px;right:72px;top:640px">
    ${[['Хук','Reels','Первые три секунды. Одна фраза, дальше молчание'],
       ['Разбор','Telegram','800 знаков, один тезис, одна цифра'],
       ['Кейс','LinkedIn','Что было, что сделали, что получилось'],
       ['Ветка','Threads','Пять коротких сообщений подряд']].map(([t,p,d],i)=>
      `<div class="c" style="transform:rotate(${i%2?1.5:-1.5}deg)">
        <span class="chip">${t}</span>
        <div class="h">${p}</div><div class="d">${d}</div></div>`).join('')}
  </div>
  <div class="hand" style="position:absolute;left:72px;bottom:130px">одна мысль — четыре входа в неё</div>
  ${foot('06')}
</div></div>`);

/* 07 — этап 5 публикация */
add('07 этап 5', `<div class="slide"><div class="pad">
  ${lock('telegram','railway','supabase')}
  <span class="badge">Этап 5 · публикация</span>
  <h1>Выходит по расписанию,<br><em>без моего участия</em></h1>
  <p class="body">Готовые тексты лежат в очереди со статусом. Я захожу раз в день, вычитываю
  и ставлю галочку — дальше публикация идёт сама, в заранее выбранные слоты.</p>
  ${win('Очередь публикаций · неделя', `<div style="padding:26px 28px">
      <div class="cal">
        <div></div>${['ПН','ВТ','СР','ЧТ','ПТ','СБ','ВС'].map(d=>`<div class="h">${d}</div>`).join('')}
        ${[['09:00',[1,0,1,0,1,0,0]],['14:00',[0,1,0,1,0,0,0]],['19:00',[1,0,1,0,1,0,0]]].map(([t,row])=>
          `<div class="t">${t}</div>${row.map(v=>`<div class="cell ${v?'on':''}">${v?'✓':''}</div>`).join('')}`).join('')}
      </div>
      <div style="display:flex;align-items:center;gap:12px;margin-top:22px;font:400 20px 'Onest';color:#5A5F68">
        <span style="width:26px;height:26px;display:block">${logo('telegram')}</span>
        отправлено по расписанию · 8 из 8 за неделю</div>
    </div>`, 'position:absolute;left:72px;right:72px;top:640px')}
  ${foot('07')}
</div></div>`);

/* 08 — цифры */
add('08 цифры', `<div class="slide"><div class="pad">
  ${lock('claude','telegram','supabase','railway')}
  <h1 style="margin-top:52px;font-size:82px">Было четыре часа.<br><em>Стало двадцать пять минут.</em></h1>
  <div style="display:flex;gap:70px;margin-top:56px">
    <div><div class="kv">В неделю на контент</div>
      <div class="metric" style="margin-top:14px"><span class="a">4 ч</span><span class="b">25</span><span class="u">минут</span></div></div>
    <div><div class="kv">Постов из одной записи</div>
      <div class="metric" style="margin-top:14px"><span class="b">8</span><span class="u">черновиков</span></div></div>
  </div>
  <div class="card" style="position:absolute;left:72px;right:72px;top:640px;padding:38px 40px">
    <div class="kv">Что остаётся на мне</div>
    <div style="font:400 27px/1.5 'Onest';margin-top:16px">Наговорить мысль и вычитать финал. Всё между этим — конвейер.
      <span style="background:#C8F04C;padding:0 .1em">Вкус остаётся, рутина уходит.</span></div>
    <div class="rowlogo" style="margin-top:30px;opacity:.55;filter:grayscale(1)">
      <span class="i">${logo('claude')}</span><span class="i">${logo('railway')}</span><span class="i">${logo('telegram')}</span>
      <span class="i">${logo('supabase')}</span><span class="i">${logo('notion')}</span></div>
  </div>
  ${foot('08')}
</div></div>`);

/* 09 — свод */
add('09 свод', `<div class="slide"><div class="pad">
  ${lock('claude','telegram','supabase','railway')}
  <h1 style="margin-top:44px;font-size:70px">Весь завод<br><em>на одном экране</em></h1>
  <p class="body" style="font-size:23px">Пять этапов, четыре сервиса, одна точка входа и одна точка выхода.
  Всё, что между — не требует решений.</p>
  <div style="position:absolute;left:72px;right:72px;top:520px">
    ${[['telegram','Захват','голосовое самому себе','3 мин'],
       ['claude','Разбор','три прохода по расшифровке','авто'],
       ['claude','Отбор','оценка по трём признакам','авто'],
       ['railway','Сборка','четыре формата из куска','авто'],
       ['telegram','Публикация','очередь и расписание','вычитка 5 мин']].map(([s,t,d,time],i)=>
      `<div style="display:flex;align-items:center;gap:20px;padding:16px 20px;background:#fff;
        border:1px solid #E3E5E9;border-radius:12px;margin-bottom:11px">
        <span style="width:34px;height:34px;background:#111;color:#C8F04C;display:grid;place-items:center;
          font:900 16px 'Inter Tight';flex:none">0${i+1}</span>
        <span style="width:34px;height:34px;display:block;flex:none">${logo(s)}</span>
        <span style="font:700 22px/1.2 'Onest';width:170px">${t}</span>
        <span style="font:400 20px/1.3 'Onest';color:#7A7F88;flex:1">${d}</span>
        <span style="font:600 19px 'Onest';color:${time==='авто'?'#4B5A16':'#111'}">${time}</span></div>`).join('')}
  </div>
  <div class="hand" style="position:absolute;left:72px;bottom:120px">человек нужен на входе и на выходе</div>
  ${foot('09')}
</div></div>`);

/* 10 — CTA */
add('10 финал', `<div class="slide"><div class="pad">
  ${lock('claude','telegram','supabase','railway')}
  <h1 style="margin-top:80px;font-size:86px">Заберёшь схему<br><em>целиком?</em></h1>
  <p class="body">Пришлю разбор всех пяти этапов: какие промпты стоят на разборе и отборе,
  как устроена очередь и что делать, когда конвейер выдаёт мусор.</p>
  <div class="card" style="margin-top:44px;padding:34px 38px">
    ${[['Три промпта разбора','тезисы, истории, цифры — по отдельности'],
       ['Формула оценки','по каким признакам кусок проходит отбор'],
       ['Схема очереди','статусы, слоты, что делать с завалом']].map(([t,d])=>
      `<div style="display:flex;gap:18px;align-items:baseline;padding:10px 0">
        <span style="width:10px;height:10px;background:#C8F04C;display:block;flex:none"></span>
        <span><span style="font:700 24px/1.3 'Onest'">${t}</span>
        <span style="font:400 22px/1.3 'Onest';color:#7A7F88"> — ${d}</span></span></div>`).join('')}
  </div>
  <div style="position:absolute;left:72px;bottom:170px" class="pill">Напиши <b>«завод»</b></div>
  ${foot('10')}
</div></div>`);

export const slides = S;
