import { logo, page } from '../lib.mjs';

/* Стиль C «Док» — карусель «Мой стек 2026», 8 слайдов */

const CSS = `
.slide{background:#fff;color:#111;font-family:'Onest',sans-serif}
.pad{position:absolute;inset:0;padding:70px 76px;display:flex;flex-direction:column;align-items:center}
h1{font-family:'Inter Tight';font-weight:900;text-transform:uppercase;font-size:58px;line-height:1.22;
   letter-spacing:-.025em;text-align:center}
h1 .hl{background:#111;color:#fff;padding:.04em .1em}
.sub{font:400 25px/1.45 'Onest';color:#7C7C7C;text-align:center;margin-top:22px;max-width:660px}
.num{font-family:'Inter Tight';font-weight:900;font-size:52px;color:#C8F04C;line-height:1}
.cat{font-family:'Inter Tight';font-weight:900;font-size:62px;text-transform:uppercase;letter-spacing:-.02em}
.dock{background:#F2F1ED;border-radius:38px;padding:28px 30px;display:flex;gap:26px}
.tile{width:132px;height:132px;border-radius:29px;background:#fff;display:grid;place-items:center;
      border:1px solid #ECECEC}
.tile span{width:74px;height:74px;display:block}.tile svg{width:100%;height:100%}
.folder{background:#F2F1ED;border-radius:46px;padding:34px;display:grid;grid-template-columns:repeat(4,1fr);gap:26px}
.folder .tile{width:118px;height:118px;border-radius:26px}
.folder .tile span{width:64px;height:64px}
.link{position:relative;width:100%;height:300px}
.link svg{position:absolute;inset:0;width:100%;height:100%}
.lab{position:absolute;text-align:center;width:230px}
.lab .n{font:700 25px/1.2 'Onest'}
.lab .d{font:400 18px/1.35 'Onest';color:#8A8A8A;margin-top:6px}
.arrows{position:absolute;inset:0;pointer-events:none}
.foot{position:absolute;left:76px;right:76px;bottom:44px;display:flex;justify-content:space-between;
      font:500 19px/1 'Onest';color:#A5A5A5}
.panel{border:1px solid #E8E8E8;border-radius:34px;padding:38px;display:grid;
       grid-template-columns:repeat(4,1fr);gap:22px}
.panel .tile{width:auto;aspect-ratio:1;height:auto;border-radius:24px;background:#F7F7F5;border:none}
.panel .tile span{width:58px;height:58px}
.mute{filter:grayscale(1);opacity:.38}
.pill{display:inline-flex;align-items:center;gap:12px;background:#111;color:#fff;
  font:800 27px/1 'Inter Tight';letter-spacing:.05em;text-transform:uppercase;padding:26px 38px;border-radius:999px}
.pill b{color:#C8F04C}
.row{display:flex;align-items:center;gap:22px;padding:18px 22px;border:1px solid #EDEDED;border-radius:18px;width:100%}
.row .ic{width:52px;height:52px;display:block;flex:none}.row .ic svg{width:100%;height:100%}
.row .t{font:700 24px/1.2 'Onest';width:230px}
.row .d{font:400 21px/1.35 'Onest';color:#8A8A8A;flex:1}
.row .x{font:700 20px/1 'Onest';color:#C0522D}
`;

const tile = s => `<div class="tile"><span>${logo(s)}</span></div>`;
const arrow = (x1,y1,x2,y2,bend=60) => `<path d="M${x1},${y1} C${x1},${y1+bend} ${x2},${y2-bend} ${x2},${y2}"
  fill="none" stroke="#C4C4C4" stroke-width="2.5"/><circle cx="${x2}" cy="${y2}" r="4" fill="#C4C4C4"/>`;

/* Координаты внутри блока .link, у которого ноль — нижняя грань дока.
   Так стрелка выходит из контейнера при любой длине подзаголовка. */
const TILE_X = [227, 385, 543, 701];
const LAB = [{cx:92, top:200, bend:80}, {cx:328, top:160, bend:55},
             {cx:600, top:160, bend:55}, {cx:836, top:200, bend:80}];

const S = [];
const add = (file, body) => S.push({ name:`c-${file.slice(0,2)}`, file, folder:'C — Док', html: page(CSS, body) });
const foot = n => `<div class="foot"><span>@vladlyamin</span><span>${n} / 08</span></div>`;

const ALL = ['claude','obsidian','perplexity','figma','vercel','supabase','railway','cursor',
             'elevenlabs','telegram','notion','openai'];

/* слайд-категория: док из четырёх иконок + изогнутые стрелки к подписям */
const category = (n, title, sub, items, note) => `<div class="slide"><div class="pad">
  <div class="num" style="margin-top:130px">${n}</div>
  <div class="cat" style="margin-top:10px">${title}</div>
  <p class="sub">${sub}</p>
  <div class="dock" style="margin-top:96px">${items.map(i=>tile(i[0])).join('')}</div>
  <div class="link">
    <svg viewBox="0 0 928 300" preserveAspectRatio="none">
      ${TILE_X.map((x,i)=>arrow(x, 0, LAB[i].cx, LAB[i].top - 12, LAB[i].bend)).join('')}
    </svg>
    ${items.map((it,i)=>`<div class="lab" style="left:${LAB[i].cx - 115}px;top:${LAB[i].top}px">
      <div class="n">${it[1]}</div><div class="d">${it[2]}</div></div>`).join('')}
  </div>
  <div style="position:absolute;left:150px;right:150px;bottom:130px;text-align:center">
    <div style="height:1px;background:#EDEDED"></div>
    <div style="font:400 23px/1.45 'Onest';color:#7C7C7C;margin-top:22px">${note}</div>
  </div>
  ${foot(n === 1 ? '02' : n === 2 ? '03' : n === 3 ? '04' : '05')}
</div></div>`;

/* 01 */
add('01 обложка', `<div class="slide"><div class="pad">
  <h1 style="margin-top:86px">Двенадцать инструментов,<br>которыми я <span class="hl">реально</span><br>пользуюсь каждый день</h1>
  <p class="sub">Без «топ-50 нейросетей». Только то, что открыто прямо сейчас
  во второй вкладке. Разбито на четыре категории.</p>
  <div class="folder" style="margin-top:62px">${ALL.map(tile).join('')}</div>
  <div class="foot"><span>@vladlyamin</span><span>сохрани, чтобы не искать</span></div>
</div></div>`);

/* 02–05 категории */
add('02 мышление', category(1,'Мышление','Здесь идея становится понятной мне самому.<br>Дальше её уже можно кому-то показывать.',
  [['claude','Claude','спорит, когда я торможу'],
   ['obsidian','Obsidian','помнит то, что я забыл'],
   ['perplexity','Perplexity','проверяет факты за мной'],
   ['figma','Figma','быстрее нарисовать, чем сказать']],
  'Общее правило категории: инструмент должен отвечать быстрее, чем я успею передумать.'));

add('03 сборка', category(2,'Сборка','Здесь идея превращается в работающую штуку.<br>Четыре инструмента, дальше — только скучный деплой.',
  [['vercel','Vercel','фронт уезжает в прод сам по себе'],
   ['supabase','Supabase','данные, о которых не думаешь'],
   ['railway','Railway','деплой в одну команду'],
   ['cursor','Cursor','код пишется, пока ты формулируешь']],
  'Здесь я не даю писать то, что не смогу прочитать. Иначе через неделю проект становится чужим.'));

add('04 контент', category(3,'Контент','Здесь мысль превращается в то, что можно опубликовать.<br>Съёмка, голос, монтаж, выкладка.',
  [['elevenlabs','ElevenLabs','голос, когда лень записывать'],
   ['claude','Claude','одна запись → восемь текстов'],
   ['figma','Figma','обложки и карусели'],
   ['telegram','Telegram','и черновики, и публикация']],
  'Съёмка занимает час, всё остальное — двадцать минут. Так и должно быть.'));

add('05 учёт', category(4,'Учёт','Здесь видно, живой бизнес или только кажется.<br>Ничего сложного, но без этого не работает.',
  [['notion','Notion','клиенты, счета, сроки'],
   ['supabase','Supabase','цифры продукта в одном месте'],
   ['telegram','Telegram','отчёт сам приходит вечером'],
   ['openai','OpenAI','разбирает выписки в таблицу']],
  'Если цифру нельзя посмотреть за десять секунд — её не смотрят вообще.'));

/* 06 — отказы */
add('06 отказы', `<div class="slide"><div class="pad">
  <h1 style="margin-top:96px">Чем я <span class="hl">не</span> пользуюсь<br>и почему</h1>
  <p class="sub">Каждый из них я честно пробовал в работе. Ушёл не из вредности,
  а по конкретной причине — вот они.</p>
  <div style="width:100%;margin-top:56px;display:flex;flex-direction:column;gap:16px">
    ${[['zapier','Zapier','цена растёт быстрее пользы, как только задач становится больше двадцати'],
       ['make','Make','ветвления превращаются в макароны, через месяц никто не помнит, что где'],
       ['airtable','Airtable','упирается в лимиты ровно тогда, когда проект начинает жить'],
       ['google-sheets','Google Sheets','отличная таблица и очень плохая база данных']].map(([s,t,d])=>
      `<div class="row"><span class="ic mute">${logo(s)}</span>
        <span class="t">${t}</span><span class="d">${d}</span><span class="x">✕</span></div>`).join('')}
  </div>
  <p class="sub" style="margin-top:40px;max-width:720px">Это не «плохие инструменты».
  Это инструменты, которые перестали подходить <b style="color:#111">мне</b> на моём объёме.</p>
  ${foot('06')}
</div></div>`);

/* 07 — свод */
add('07 свод', `<div class="slide"><div class="pad">
  <h1 style="margin-top:72px">Весь стек<br>на одном экране</h1>
  <p class="sub">Четыре категории, двенадцать инструментов.</p>
  <div class="panel" style="margin-top:56px;width:100%">${ALL.map(tile).join('')}</div>
  <div style="position:absolute;left:76px;right:76px;bottom:110px;display:flex;align-items:center;gap:26px">
    <div style="font:600 18px/1.35 'Onest';letter-spacing:.14em;text-transform:uppercase;color:#A5A5A5;width:190px">
      От чего отказался</div>
    <div style="display:flex;gap:18px">
      ${['zapier','make','airtable','google-sheets'].map(x=>
        `<div class="tile mute" style="width:96px;height:96px;border-radius:22px"><span style="display:block;width:50px;height:50px">${logo(x)}</span></div>`).join('')}
    </div>
    <div style="font:400 19px/1.4 'Onest';color:#8A8A8A;flex:1">
      Причины — на предыдущем слайде. Ни один не выкинут из вредности.</div>
  </div>
  ${foot('07')}
</div></div>`);

/* 08 — CTA */
add('08 финал', `<div class="slide"><div class="pad">
  <h1 style="margin-top:150px">Список с ссылками<br>и <span class="hl">ценами</span> — в директ</h1>
  <p class="sub">Пришлю таблицей: что за инструмент, сколько стоит в месяц,
  что делает у меня и чем заменяется, если бюджета нет.</p>
  <div style="margin-top:64px;display:flex;gap:20px">
    ${['claude','cursor','supabase','railway','obsidian','telegram'].map(s=>
      `<div class="tile" style="width:104px;height:104px;border-radius:24px"><span style="display:block;width:56px;height:56px">${logo(s)}</span></div>`).join('')}
  </div>
  <div style="margin-top:70px" class="pill">Напиши <b>«стек»</b></div>
  <p class="sub" style="margin-top:44px;font-size:22px">И скажи, какой категории не хватает —
  добавлю в следующий разбор.</p>
  ${foot('08')}
</div></div>`);

export const slides = S;
