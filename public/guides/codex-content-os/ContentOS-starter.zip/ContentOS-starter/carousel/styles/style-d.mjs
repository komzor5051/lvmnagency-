import { logo, page } from '../lib.mjs';

/* Стиль D «Терминал» — карусель «CLAUDE.md, который экономит час в день», 9 слайдов */

const CSS = `
.slide{background:#0A0B0D;color:#E4E7EA;font-family:'Onest',sans-serif}
.pad{position:absolute;inset:0;padding:58px 64px}
.top{display:flex;align-items:center;justify-content:space-between;
  font:600 18px/1 'Onest';letter-spacing:.18em;text-transform:uppercase;color:#79828F}
.top .lg{display:flex;align-items:center;gap:14px;color:#E4E7EA}
.top .lg span{width:28px;height:28px}.top .lg svg{width:100%;height:100%}
h1{font-family:'Inter Tight';font-weight:900;text-transform:uppercase;font-size:82px;line-height:.98;
   letter-spacing:-.025em;margin-top:34px}
h1 .lime{color:#C8F04C}
p.body{font:400 24px/1.5 'Onest';color:#9AA3AF;margin-top:22px;max-width:800px}
p.body b{color:#E4E7EA;font-weight:500}
.tag{display:inline-flex;background:#C8F04C;color:#0A0B0D;font:700 18px/1 'Onest';
  letter-spacing:.16em;text-transform:uppercase;padding:11px 16px}
/* окно редактора */
.ide{border:1px solid #22262E;background:#101216;overflow:hidden;display:flex;flex-direction:column}
.ide .chrome{display:flex;align-items:center;gap:8px;padding:13px 16px;background:#14171C;border-bottom:1px solid #22262E}
.ide .chrome i{width:10px;height:10px;border-radius:50%;display:block;background:#2A2F38}
.ide .tabs{display:flex;border-bottom:1px solid #22262E;background:#0E1013}
.ide .tabs div{font:400 17px/1 'JetBrains Mono';color:#79828F;padding:14px 20px;border-right:1px solid #22262E}
.ide .tabs div.on{color:#E4E7EA;background:#101216;box-shadow:inset 0 2px 0 #C8F04C}
.ide .main{display:flex;flex:1;min-height:0}
.side{width:250px;flex:none;border-right:1px solid #22262E;padding:18px 0;background:#0E1013}
.side .h{font:600 14px/1 'Onest';letter-spacing:.2em;text-transform:uppercase;color:#5C6673;padding:0 18px 12px}
.side .f{font:400 18px/1 'JetBrains Mono';color:#79828F;padding:9px 18px;display:flex;gap:9px}
.side .f.on{color:#C8F04C;background:#141821}
.code{flex:1;font:400 22px/1.6 'JetBrains Mono';padding:20px 0;min-width:0}
.ln{display:flex}
.ln .g{width:64px;flex:none;text-align:right;padding-right:22px;color:#3C434E}
.ln .c{flex:1;padding-right:24px;white-space:pre-wrap;word-break:break-word}
.cm{color:#5C6673}.key{color:#7FB2E8}.str{color:#D9B06A}
.ln.hl{background:rgba(200,240,76,.06);box-shadow:inset 3px 0 0 #C8F04C}
.ln.add .c{color:#9BD44E}.ln.add{background:rgba(155,212,78,.07)}
.ln.del .c{color:#C4726A}.ln.del{background:rgba(196,114,106,.07)}
.status{display:flex;align-items:center;gap:26px;padding:12px 18px;background:#14171C;border-top:1px solid #22262E;
  font:400 16px/1 'JetBrains Mono';color:#79828F}
.status .b{color:#C8F04C}
.cursor{display:inline-block;width:12px;height:22px;background:#C8F04C;vertical-align:-4px}
.foot{position:absolute;left:64px;right:64px;bottom:38px;display:flex;justify-content:space-between;
  font:500 18px/1 'Onest';color:#4E5763}
.stat{border:1px solid #22262E;background:#101216;padding:26px 28px}
.stat .k{font:600 16px/1 'Onest';letter-spacing:.18em;text-transform:uppercase;color:#79828F}
.stat .v{font-family:'Inter Tight';font-weight:900;font-size:64px;line-height:1;margin-top:12px}
.stat .v.lime{color:#C8F04C}
.stat .s{font:400 18px/1.3 'Onest';color:#79828F;margin-top:8px}
.pill{display:inline-flex;align-items:center;gap:12px;background:#C8F04C;color:#0A0B0D;
  font:800 26px/1 'Inter Tight';letter-spacing:.05em;text-transform:uppercase;padding:24px 34px}
`;
const ln = (n,c,cls='') => `<div class="ln ${cls}"><span class="g">${n}</span><span class="c">${c}</span></div>`;
const top = t => `<div class="top"><span class="lg"><span>${logo('claude','mono')}</span>Claude Code</span><span>${t}</span></div>`;
const tree = (active='CLAUDE.md') => `<div class="side"><div class="h">Проект</div>
  ${['CLAUDE.md','README.md','src/','scripts/','.env']
    .map(f=>`<div class="f ${f===active?'on':''}"><span>${f===active?'▸':'·'}</span>${f}</div>`).join('')}</div>`;
const status = r => `<div class="status"><span class="b">⌥ main</span><span>UTF-8</span><span>Markdown</span>
  <span style="margin-left:auto">${r}</span></div>`;
const term = (title, rows, h, extra='') => `<div class="ide" style="margin-top:30px;height:${h}px">
  <div class="chrome"><i></i><i></i><i></i>
    <span style="margin-left:12px;font:400 17px 'JetBrains Mono';color:#79828F">${title}</span></div>
  <div class="main"><div class="code">${rows}</div></div>${extra}</div>`;
const editor = (tabs, rows, h, st, active) => `<div class="ide" style="margin-top:28px;height:${h}px">
  <div class="tabs">${tabs.map((t,i)=>`<div class="${i===0?'on':''}">${t}</div>`).join('')}<div>+</div></div>
  <div class="main">${tree(active)}<div class="code" style="font-size:21px">${rows}</div></div>${status(st)}</div>`;

const S = [];
const add = (file, b) => S.push({ name:`d-${file.slice(0,2)}`, file, folder:'D — Терминал', html: page(CSS, b) });
const foot = n => `<div class="foot"><span>@vladlyamin</span><span>${n} / 09</span></div>`;

/* 01 */
add('01 обложка', `<div class="slide"><div class="pad">
  ${top('файл · 01 / 09')}
  <h1>Один файл.<br><span class="lime">Час в день.</span></h1>
  <p class="body">CLAUDE.md — единственная причина, по которой агент не начинает каждую сессию
  с вопроса «а что мы вообще делаем». Показываю свой целиком, по блокам.</p>
  ${term('~/work/lvmn — zsh', `
      ${ln('1','<span class="cm">$</span> cat CLAUDE.md')}
      ${ln('2','<span class="cm"># Кто я и как со мной работать</span>')}
      ${ln('3','')}
      ${ln('4','Влад, соло-фаундер. Стек: <span class="str">Node, Claude API,</span>')}
      ${ln('5','<span class="str">Supabase</span>. Пишу код сам, ревью тоже.')}
      ${ln('6','')}
      ${ln('7','<span class="cm">## Запреты</span>')}
      ${ln('8','— без эмодзи, без «в эпоху AI»','hl')}
      ${ln('9','— не предлагать то, что уже отклонил','hl')}
      ${ln('10','<span class="cursor"></span>')}`, 470, status('46 строк · 1.4 KB'))}
  <div style="position:absolute;left:64px;right:64px;bottom:104px">
    <div style="font:600 16px/1 'Onest';letter-spacing:.2em;text-transform:uppercase;color:#4E5763">Что внутри файла</div>
    <div style="display:flex;gap:12px;margin-top:16px">
      ${['1 · Кто я','2 · Стек','3 · Запреты','4 · Формат ответа','5 · Чего не класть'].map((t,i)=>
        `<div style="flex:1;border:1px solid #22262E;background:#101216;
          padding:16px 18px;font:400 19px/1.2 'JetBrains Mono';color:#79828F">${t}</div>`).join('')}
    </div>
  </div>
  ${foot('01')}
</div></div>`);

/* 02 — боль */
add('02 боль', `<div class="slide"><div class="pad">
  ${top('почему так')}
  <h1 style="font-size:70px">Каждая сессия<br>начинается <span class="lime">с нуля</span></h1>
  <p class="body">Модель не помнит вчерашний разговор. Ты объясняешь стек, тон, ограничения
  и то, что уже отклонил. Двенадцать минут, каждый раз, вручную.</p>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:44px">
    <div class="stat"><div class="k">Как это выглядит</div>
      <div style="font:400 21px/1.7 'JetBrains Mono';color:#9AA3AF;margin-top:16px">
        — «я использую Node, не Python»<br>
        — «без эмодзи, я же говорил»<br>
        — «мы это уже пробовали»<br>
        — «короче, без вступлений»</div></div>
    <div class="stat"><div class="k">Во что обходится</div>
      <div class="v">12 мин</div><div class="s">на каждую новую сессию</div>
      <div style="height:1px;background:#22262E;margin:20px 0"></div>
      <div class="v lime">≈ 1 час</div><div class="s">в неделю, только на повторы</div></div>
  </div>
  <div style="position:absolute;left:64px;right:64px;bottom:110px;border-left:3px solid #C8F04C;padding:4px 0 4px 22px">
    <div style="font:400 25px/1.45 'Onest'">Всё это — статичная информация. Она не меняется от сессии к сессии,
    значит её вообще не должен произносить человек.</div>
  </div>
  ${foot('02')}
</div></div>`);

/* 03 — блок 1 */
add('03 блок 1', `<div class="slide"><div class="pad">
  ${top('блок 1 · кто я')}
  <div style="margin-top:26px"><span class="tag">Блок 1</span></div>
  <h1 style="font-size:70px;margin-top:20px">Кто я и <span class="lime">как со мной</span><br>разговаривать</h1>
  <p class="body" style="font-size:22px">Самый короткий блок и самый недооценённый. Без него агент
  пишет усреднённым голосом консультанта, а не твоим.</p>
  ${editor(['CLAUDE.md','README.md'], `
      ${ln('1','<span class="cm"># Кто я</span>')}
      ${ln('2','')}
      ${ln('3','Влад, соло-фаундер. Делаю AI-автоматизацию')}
      ${ln('4','для фаундеров. Работаю один, команды нет.')}
      ${ln('5','')}
      ${ln('6','<span class="cm">## Как принимаю решения</span>')}
      ${ln('7','Быстрее > идеальнее. MVP, потом правки.','hl')}
      ${ln('8','Если решение дороже проблемы — не берусь.','hl')}
      ${ln('9','')}
      ${ln('10','<span class="cm">## Тон</span>')}
      ${ln('11','Прямо. Без вступлений и без «конечно!».')}`, 520, '11 строк', 'CLAUDE.md')}
  ${foot('03')}
</div></div>`);

/* 04 — блок 2 */
add('04 блок 2', `<div class="slide"><div class="pad">
  ${top('блок 2 · стек')}
  <div style="margin-top:26px"><span class="tag">Блок 2</span></div>
  <h1 style="font-size:70px;margin-top:20px">Стек — чтобы не советовал<br><span class="lime">чужое</span></h1>
  <p class="body" style="font-size:22px">Без этого блока агент бодро предлагает переписать проект
  на том, чего у тебя нет. С ним — работает внутри твоих ограничений.</p>
  ${editor(['CLAUDE.md','README.md'], `
      ${ln('13','<span class="cm">## Стек</span>')}
      ${ln('14','<span class="key">runtime</span>: <span class="str">Node 22, TypeScript</span>')}
      ${ln('15','<span class="key">данные</span>:  <span class="str">Supabase (Postgres)</span>')}
      ${ln('16','<span class="key">хостинг</span>: <span class="str">Railway, Vercel</span>')}
      ${ln('17','<span class="key">интерфейс</span>: <span class="str">Telegram Bot API</span>')}
      ${ln('18','')}
      ${ln('19','<span class="cm">## Не предлагать</span>')}
      ${ln('20','— визуальные конструкторы воркфлоу','hl')}
      ${ln('21','— смену фреймворка ради стиля','hl')}`, 470, '+9 строк', 'CLAUDE.md')}
  <div style="position:absolute;left:64px;right:64px;bottom:104px;display:flex;align-items:center;gap:22px">
    <span style="display:block;width:34px;height:34px;color:#E4E7EA">${logo('supabase','mono')}</span>
    <span style="display:block;width:34px;height:34px;color:#E4E7EA">${logo('railway','mono')}</span>
    <span style="display:block;width:34px;height:34px;color:#E4E7EA">${logo('telegram','mono')}</span>
    <span style="font:400 21px/1.3 'Onest';color:#79828F">— перечисляй ровно то, что стоит в проекте, без «и вообще я знаю ещё»</span>
  </div>
  ${foot('04')}
</div></div>`);

/* 05 — блок 3 дифф */
add('05 блок 3', `<div class="slide"><div class="pad">
  ${top('блок 3 · запреты')}
  <div style="margin-top:26px"><span class="tag">Самый ценный блок</span></div>
  <h1 style="font-size:66px;margin-top:20px">Не «что делать».<br><span class="lime">Что не делать.</span></h1>
  <p class="body" style="font-size:22px">Инструкции «пиши хорошо» агент игнорирует — они ничего не запрещают.
  Работают жёсткие отрицания с примером. Вот дифф моего файла за три месяца.</p>
  ${editor(['CLAUDE.md','README.md'], `
      ${ln('12','- Пиши в деловом тоне, избегай воды','del')}
      ${ln('13','- Старайся быть кратким','del')}
      ${ln('14','')}
      ${ln('15','+ Запрещено: эмодзи в любом виде','add')}
      ${ln('16','+ Запрещено: «в эпоху AI», «революция»','add')}
      ${ln('17','+ Ответ &gt; 5 абзацев — сначала спроси','add')}
      ${ln('18','+ Не переписывай то, что я принял','add')}`, 450, '+4 −2', 'CLAUDE.md')}
  <div style="position:absolute;left:64px;right:64px;bottom:100px;border-left:3px solid #C8F04C;padding:4px 0 4px 22px">
    <div style="font:600 16px/1 'Onest';letter-spacing:.2em;text-transform:uppercase;color:#79828F">Правило</div>
    <div style="font:400 24px/1.45 'Onest';margin-top:10px">Запрет без примера не работает. Пиши, что именно
      считаешь ошибкой — фразой, которую агент уже написал тебе.</div>
  </div>
  ${foot('05')}
</div></div>`);

/* 06 — блок 4 */
add('06 блок 4', `<div class="slide"><div class="pad">
  ${top('блок 4 · формат')}
  <div style="margin-top:26px"><span class="tag">Блок 4</span></div>
  <h1 style="font-size:70px;margin-top:20px">Как выглядит<br><span class="lime">хороший ответ</span></h1>
  <p class="body" style="font-size:22px">Опиши форму ответа один раз — и перестанешь просить
  «покороче» в каждом сообщении.</p>
  ${editor(['CLAUDE.md','README.md'], `
      ${ln('23','<span class="cm">## Формат ответа</span>')}
      ${ln('24','Сначала вывод, потом обоснование.','hl')}
      ${ln('25','Код — целым файлом, не кусками.')}
      ${ln('26','Если правишь мой код — покажи дифф.')}
      ${ln('27','')}
      ${ln('28','<span class="cm">## Когда спрашивать</span>')}
      ${ln('29','Развилка дороже 30 минут работы —','hl')}
      ${ln('30','спроси, а не выбирай сам.','hl')}`, 430, '8 строк', 'CLAUDE.md')}
  <div style="position:absolute;left:64px;right:64px;bottom:104px;display:flex;gap:18px">
    <div class="stat" style="flex:1;padding:20px 22px"><div class="k">Было</div>
      <div style="font:400 20px/1.4 'Onest';color:#9AA3AF;margin-top:10px">«покороче», «без воды», «дай сразу код» — в каждом сообщении</div></div>
    <div class="stat" style="flex:1;padding:20px 22px;border-color:#C8F04C"><div class="k" style="color:#C8F04C">Стало</div>
      <div style="font:400 20px/1.4 'Onest';color:#E4E7EA;margin-top:10px">восемь строк в файле, написанных один раз</div></div>
  </div>
  ${foot('06')}
</div></div>`);

/* 07 — чего не класть */
add('07 чего не класть', `<div class="slide"><div class="pad">
  ${top('границы')}
  <h1 style="margin-top:40px;font-size:70px">Чего в файл<br><span class="lime">класть не надо</span></h1>
  <p class="body">Файл читается при каждом запуске. Всё лишнее в нём — это лишний контекст,
  за который ты платишь и который размывает главное.</p>
  <div style="display:flex;flex-direction:column;gap:16px;margin-top:44px">
    ${[['Секреты и ключи','файл лежит в репозитории и уезжает вместе с ним'],
       ['То, что меняется каждую неделю','статусы задач, текущие приоритеты, дедлайны'],
       ['Вежливость и мотивацию','«старайся», «будь внимателен» — ноль эффекта, только объём'],
       ['Историю переписки','для этого есть сама переписка, файл не дневник']].map(([t,d])=>
      `<div style="display:flex;align-items:flex-start;gap:20px;border:1px solid #22262E;background:#101216;padding:20px 24px">
        <span style="font:900 22px 'Inter Tight';color:#C4726A;flex:none">✕</span>
        <span><span style="font:700 24px/1.3 'Onest'">${t}</span><br>
        <span style="font:400 21px/1.4 'Onest';color:#79828F">${d}</span></span></div>`).join('')}
  </div>
  ${foot('07')}
</div></div>`);

/* 08 — итог */
add('08 итог', `<div class="slide"><div class="pad">
  ${top('итог')}
  <h1 style="margin-top:44px;font-size:74px">Двенадцать минут<br>объяснений <span class="lime">→ ноль.</span></h1>
  <p class="body">Файл лежит в корне проекта, агент читает его сам при каждом запуске.
  Пишется один раз, правится раз в месяц.</p>
  <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:18px;margin-top:40px">
    <div class="stat"><div class="k">Раньше на сессию</div><div class="v">12 мин</div>
      <div class="s">объяснял контекст заново</div></div>
    <div class="stat"><div class="k">Сейчас</div><div class="v lime">0</div>
      <div class="s">читает файл сам</div></div>
    <div class="stat"><div class="k">Правок в месяц</div><div class="v">1–2</div>
      <div class="s">когда меняются правила</div></div>
  </div>
  ${term('старт сессии', `
      ${ln('1','<span class="cm">✓</span> прочитан <span class="key">CLAUDE.md</span> — 46 строк')}
      ${ln('2','<span class="cm">✓</span> контекст проекта загружен')}
      ${ln('3','<span class="cm">›</span> готов. что делаем?<span class="cursor"></span>')}`, 210)}
  <div style="position:absolute;left:64px;right:64px;bottom:104px;display:flex;align-items:center;gap:22px">
    <span style="display:block;width:32px;height:32px;color:#E4E7EA">${logo('claude','mono')}</span>
    <span style="display:block;width:32px;height:32px;color:#E4E7EA">${logo('cursor','mono')}</span>
    <span style="font:400 21px/1.3 'Onest';color:#79828F">— читают один и тот же файл, писать дважды не нужно</span>
  </div>
  ${foot('08')}
</div></div>`);

/* 09 — CTA */
add('09 финал', `<div class="slide"><div class="pad">
  ${top('забрать')}
  <h1 style="margin-top:120px;font-size:82px">Пришлю свой файл<br><span class="lime">целиком</span></h1>
  <p class="body">46 строк с комментариями по каждому блоку: что зачем стоит и что будет,
  если строку убрать. Копируешь, меняешь под себя, кладёшь в корень проекта.</p>
  <div style="display:flex;flex-direction:column;gap:14px;margin-top:46px">
    ${[['01','Пять блоков файла с пояснениями'],
       ['02','Список запретов, который работает'],
       ['03','Что проверить, если агент игнорирует файл']].map(([n,t])=>
      `<div style="display:flex;gap:18px;align-items:baseline">
        <span style="font:900 22px 'Inter Tight';color:#C8F04C">${n}</span>
        <span style="font:400 25px/1.3 'Onest'">${t}</span></div>`).join('')}
  </div>
  ${term('что придёт в директ', `
      ${ln('1','<span class="cm">›</span> CLAUDE.md          <span class="str">46 строк, с комментариями</span>')}
      ${ln('2','<span class="cm">›</span> checklist.md       <span class="str">что проверить, если не читает</span>')}
      ${ln('3','<span class="cm">›</span> примеры до/после   <span class="str">как менялись формулировки</span>')}`, 210)}
  <div style="display:flex;align-items:center;gap:26px;position:absolute;left:64px;bottom:120px">
    <span class="pill">Напиши «файл»</span>
    <span style="font:400 21px/1.3 'Onest';color:#79828F">в директ — пришлю<br>текстом, без лендингов</span>
  </div>
  ${foot('09')}
</div></div>`);

export const slides = S;
