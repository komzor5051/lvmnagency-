import { logo, page } from '../lib.mjs';

/* Стиль E «Пруф» — карусель «40 часов в месяц → 6», 6 слайдов */

const CSS = `
.slide{background:#F5F1EA;color:#1A1A1A;font-family:'Onest',sans-serif}
.pad{position:absolute;inset:0;padding:70px 78px}
.cnt{font:400 22px/1 'JetBrains Mono';color:#8A8377;letter-spacing:.08em}
h1{font-family:'Inter Tight';font-weight:500;font-size:74px;line-height:1.08;letter-spacing:-.02em;margin-top:34px}
h1 i{font-style:italic;font-weight:500}
.lead{font:400 26px/1.5 'Onest';margin-top:26px;max-width:820px;color:#33302B}
.lead b{font-weight:700}
.shot{position:absolute;border-radius:14px;overflow:hidden;background:#fff;
       box-shadow:0 26px 60px rgba(60,50,35,.16)}
.br{display:flex;align-items:center;gap:10px;padding:13px 16px;background:#EFEDE9;border-bottom:1px solid #E2DFD9}
.br i{width:11px;height:11px;border-radius:50%;display:block}
.br .url{flex:1;margin-left:12px;background:#fff;border-radius:7px;padding:7px 14px;
   font:400 16px/1 'Onest';color:#8A8377;display:flex;align-items:center;gap:9px}
.br .url span{width:16px;height:16px}.br .url svg{width:100%;height:100%}
.plate{position:absolute;background:#fff;padding:14px 20px;font:500 20px/1.3 'Onest';
       box-shadow:0 8px 24px rgba(60,50,35,.12)}
.plate b{font-weight:700}
.bub{position:absolute;background:#D6E88A;padding:20px 24px;max-width:390px;
     font:400 22px/1.4 'JetBrains Mono';color:#26251F;border-radius:16px}
.bub:after{content:'';position:absolute;left:44px;bottom:-14px;border:15px solid transparent;
   border-top-color:#D6E88A;border-bottom:0}
.tbl{font:400 18px/1 'Onest';width:100%;border-collapse:collapse}
.tbl td,.tbl th{border-bottom:1px solid #EEEBE6;padding:13px 16px;text-align:left;color:#4A463F}
.tbl th{font-weight:700;color:#1A1A1A;background:#FAF8F5;font-size:16px;letter-spacing:.06em;text-transform:uppercase}
.metric{position:absolute;display:flex;align-items:center;gap:18px;
  font-family:'Inter Tight';font-weight:900;font-size:42px}
.metric .a{color:#8A8377;text-decoration:line-through}
.metric .arw{color:#8A8377;font-size:32px}
.foot{position:absolute;left:78px;right:78px;bottom:44px;display:flex;justify-content:space-between;
  font:400 19px/1 'JetBrains Mono';color:#A09889}
.mid{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;
     text-align:center;padding:0 130px}
.ava{width:190px;height:190px;border-radius:50%;margin:44px 0 40px;
     background:radial-gradient(120% 120% at 30% 25%,#C9C2B4,#8E877A 60%,#5E594F);
     display:grid;place-items:center;font:600 44px 'Inter Tight';color:#F5F1EA}
.btn{display:flex;align-items:center;justify-content:center;gap:18px;background:#D6E88A;
  border-radius:999px;padding:26px 46px;margin-top:44px;font:700 27px/1 'Onest'}
.btn .m{font:400 22px 'JetBrains Mono';color:#5B6330}
`;
const bar = (url, ic='google-sheets') => `<div class="br"><i style="background:#E8A0A0"></i><i style="background:#E8CE9A"></i><i style="background:#A9CE9A"></i>
  <div class="url"><span>${logo(ic)}</span>${url}</div></div>`;

const S = [];
const add = (file, b) => S.push({ name:`e-${file.slice(0,2)}`, file, folder:'E — Пруф', html: page(CSS, b) });
const foot = n => `<div class="foot"><span>@vladlyamin</span><span>${n} / 06</span></div>`;
const cnt = n => `<div class="cnt">( ${n} / 06 )</div>`;

/* 01 — обложка */
add('01 обложка', `<div class="slide"><div class="pad">
  ${cnt('01')}
  <h1>Сорок часов в месяц<br>уходило на <i>одну таблицу</i></h1>
  <p class="lead"><b>Задача:</b> клиент вручную сводил заявки из трёх источников в один документ.
  Каждый вечер, руками, по сорок минут. Показываю все шесть шагов — и что осталось от этих сорока часов.</p>
</div>
  <div class="shot" style="left:78px;right:78px;top:620px;height:400px">
    ${bar('docs.google.com/spreadsheets — сводка заявок (до)')}
    <table class="tbl">
      <tr><th>Дата</th><th>Источник</th><th>Клиент</th><th>Статус</th><th>Внесено</th></tr>
      ${[['12.06','Telegram','ООО «Север»','в работе','вручную'],
         ['12.06','Форма на сайте','Ильин А.','новая','вручную'],
         ['13.06','Telegram','—','дубль','вручную'],
         ['13.06','Почта','Рогова М.','новая','вручную'],
         ['14.06','Форма на сайте','—','потеряна','—']].map(r=>
        `<tr>${r.map((c,i)=>`<td${i===4?' style="color:#A0574A"':''}>${c}</td>`).join('')}</tr>`).join('')}
    </table>
  </div>
  <div class="plate" style="left:110px;top:960px">кадр из рабочего файла клиента · <b>14 июня 2026</b></div>
  ${foot('01')}
</div>`);

/* 02 — что болело */
add('02 задача', `<div class="slide"><div class="pad">
  ${cnt('02')}
  <h1>Он не жаловался<br>на <i>сорок часов</i></h1>
  <p class="lead"><b>Ситуация:</b> формулировка звучала иначе — «иногда теряем заявки».
  Сорок часов всплыли, когда мы вместе посчитали, сколько занимает один вечер.</p>
</div>
  <div class="shot" style="left:78px;right:78px;top:600px;height:430px">
    ${bar('переписка · 3 июля 2026','telegram')}
    <div style="padding:30px 34px;display:flex;flex-direction:column;gap:18px">
      ${[[0,'Иногда теряем заявки. Не критично, но неприятно'],
         [0,'Особенно если с сайта и из телеги приходит одно и то же'],
         [1,'Сколько времени в день уходит на сведение?'],
         [0,'Ну минут сорок. Каждый вечер, я привык уже']].map(([mine,t])=>
        `<div style="display:flex;${mine?'justify-content:flex-end':''}">
          <div style="max-width:660px;padding:16px 20px;border-radius:16px;
            background:${mine?'#D6E88A':'#FFFFFF'};border:1px solid ${mine?'#C8DC72':'#E6E1D8'};
            font:400 22px/1.4 'Onest'">${t}</div></div>`).join('')}
    </div>
  </div>
  <div class="plate" style="left:110px;top:1052px">эту цифру он назвал сам · <b>вопрос решил всё</b></div>
  ${foot('02')}
</div>`);

/* 03 — что переделали */
add('03 решение', `<div class="slide"><div class="pad">
  ${cnt('03')}
  <h1>Три источника,<br>одна <i>точка сборки</i></h1>
  <p class="lead"><b>Что поменяли:</b> ручное сведение заменили одной цепочкой. Заявка попадает
  в таблицу за секунды, дубли отсекаются по телефону, спорные случаи приходят в Telegram.</p>
  <div style="position:absolute;left:78px;right:78px;top:600px;display:flex;flex-direction:column;gap:18px">
    <div style="display:flex;gap:16px">
      ${[['Telegram','заявки из чата'],['Форма на сайте','вебхук'],['Почта','парсер писем']].map(([t,d])=>
        `<div style="flex:1;background:#fff;border:1px solid #E6E1D8;border-radius:12px;padding:18px 20px">
          <div style="font:700 21px/1.2 'Onest'">${t}</div>
          <div style="font:400 18px/1.3 'Onest';color:#8A8377;margin-top:5px">${d}</div></div>`).join('')}
    </div>
    <div style="text-align:center;font:400 30px 'Onest';color:#B4AC9C">↓</div>
    <div style="background:#111;color:#fff;border-radius:12px;padding:22px 26px;display:flex;align-items:center;gap:20px">
      <span style="display:block;width:36px;height:36px;flex:none">${logo('railway')}</span>
      <div><div style="font:700 23px/1.2 'Onest'">Сборщик</div>
        <div style="font:400 19px/1.3 'Onest';color:#B9BCC2;margin-top:4px">нормализует телефон, ищет дубль, ставит статус</div></div>
    </div>
    <div style="text-align:center;font:400 30px 'Onest';color:#B4AC9C">↓</div>
    <div style="display:flex;gap:16px">
      <div style="flex:2;background:#D6E88A;border-radius:12px;padding:20px 24px">
        <div style="font:700 21px/1.2 'Onest'">Таблица</div>
        <div style="font:400 18px/1.3 'Onest';color:#4B5230;margin-top:5px">одна строка, уже без дублей</div></div>
      <div style="flex:1;background:#fff;border:1px solid #E6E1D8;border-radius:12px;padding:20px 24px">
        <div style="font:700 21px/1.2 'Onest'">Telegram</div>
        <div style="font:400 18px/1.3 'Onest';color:#8A8377;margin-top:5px">только спорные</div></div>
    </div>
  </div>
  <div class="plate" style="left:110px;bottom:120px">семь нод · два вечера работы · <b>ни одной новой подписки</b></div>
  ${foot('03')}
</div>`);

/* 04 — доказательство */
add('04 доказательство', `<div class="slide"><div class="pad">
  ${cnt('04')}
  <h1>Семь нод и <i>два вечера</i></h1>
  <p class="lead"><b>Что сделали:</b> три источника собираются сами, дубли отсекаются по телефону,
  готовая строка падает в таблицу и в Telegram. Человек нужен только там, где заявку надо оценить.</p>
</div>
  <div class="shot" style="left:78px;right:78px;top:580px;height:400px">
    ${bar('app.lvmn.ru/flows/42 — сводка заявок','railway')}
    <div style="padding:0 40px;display:flex;align-items:center;gap:0;background:#FBFAF8;height:calc(100% - 45px)">
      ${[['telegram','Telegram','триггер'],['railway','Дедупликация','по телефону'],
         ['claude','Разметка','источник и статус'],['google-sheets','Таблица','строка готова']]
        .map(([s,t,d],i)=>`${i?'<div style="flex:1;height:2px;background:#D8D4CC;position:relative"><span style="position:absolute;right:-4px;top:-6px;color:#B4AEA2">▶</span></div>':''}
        <div style="width:190px;background:#fff;border:1px solid #E6E2DA;border-radius:12px;padding:18px 16px;text-align:center">
          <span style="width:42px;height:42px;display:inline-block">${logo(s)}</span>
          <div style="font:700 19px/1.2 'Onest';margin-top:10px">${t}</div>
          <div style="font:400 16px/1.3 'Onest';color:#8A8377;margin-top:4px">${d}</div></div>`).join('')}
    </div>
  </div>
  <div class="bub" style="left:110px;top:930px">«я вообще перестал открывать эту таблицу»</div>
  <div class="metric" style="right:78px;bottom:130px"><span class="a">40 ч</span><span class="arw">→</span><span>6 ч</span></div>
  ${foot('04')}
</div>`);

/* 05 — результат */
add('05 результат', `<div class="slide"><div class="pad">
  ${cnt('05')}
  <h1>Через месяц —<br><i>та же таблица</i></h1>
  <p class="lead"><b>Что изменилось:</b> столбец «внесено» стал автоматическим, потерянных заявок
  за месяц ноль, дубли отсекаются до того, как их кто-то увидит.</p>
</div>
  <div class="shot" style="left:78px;right:78px;top:600px;height:400px">
    ${bar('docs.google.com/spreadsheets — сводка заявок (после)')}
    <table class="tbl">
      <tr><th>Дата</th><th>Источник</th><th>Клиент</th><th>Статус</th><th>Внесено</th></tr>
      ${[['12.07','Telegram','ООО «Север»','в работе','авто'],
         ['12.07','Форма на сайте','Ильин А.','новая','авто'],
         ['13.07','Telegram','ООО «Север»','дубль снят','авто'],
         ['13.07','Почта','Рогова М.','новая','авто'],
         ['14.07','Форма на сайте','Крылов П.','новая','авто']].map(r=>
        `<tr>${r.map((c,i)=>`<td${i===4?' style="color:#4B5230;font-weight:700"':''}>${c}</td>`).join('')}</tr>`).join('')}
    </table>
  </div>
  <div class="plate" style="left:110px;top:940px">тот же файл через месяц · <b>14 июля 2026</b></div>
  <div class="metric" style="left:78px;bottom:120px;font-size:34px">
    <span class="a">40 ч/мес</span><span class="arw">→</span><span>6 ч/мес</span></div>
  ${foot('05')}
</div>`);

/* 06 — финал */
add('06 финал', `<div class="slide">
  <div class="mid">
    ${cnt('06')}
    <h1 style="margin-top:24px">Весь разбор —<br>в одном <i>видео с экрана</i></h1>
    <div class="ava">ВЛ</div>
    <p style="font:400 26px/1.5 'Onest';color:#33302B;max-width:640px">
      Хотите посмотреть, как это собрано изнутри? Напишите в директ слово
      <b style="font-weight:700">СВОДКА</b> — пришлю ссылку на разбор и схему сборщика.</p>
    <div class="btn"><span class="m">( 9 минут )</span> разбор без монтажа</div>
  </div>
  ${foot('06')}
</div>`);

export const slides = S;
