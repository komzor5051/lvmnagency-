import { logo, page, shot } from '../lib.mjs';

/* Формат F «Нативный» — карусель «Пять приложений», 6 слайдов.
   Настоящие кадры с рабочего места; фоны разные, типографический слой один. */

const CSS = `
.slide{background:#101010;color:#fff;font-family:-apple-system,'Onest',sans-serif}
.ph{position:absolute;inset:0;background-size:cover;background-position:center;filter:contrast(1.06) saturate(.92)}
.veil{position:absolute;inset:0}
.veil.top{background:linear-gradient(180deg,rgba(8,8,8,.30) 0%,rgba(8,8,8,.55) 34%,rgba(8,8,8,.80) 58%,rgba(8,8,8,.55) 100%)}
.veil.left{background:linear-gradient(105deg,rgba(6,6,6,.90) 0%,rgba(6,6,6,.74) 40%,rgba(6,6,6,.30) 100%)}
.scrim{position:absolute;left:0;right:0;bottom:0;height:58%;
  background:linear-gradient(180deg,transparent 0%,rgba(6,6,6,.55) 38%,rgba(6,6,6,.93) 72%)}
.scrim.up{top:0;bottom:auto;height:56%;
  background:linear-gradient(0deg,transparent 0%,rgba(6,6,6,.55) 38%,rgba(6,6,6,.93) 72%)}
.grain{opacity:.10}
.wrap{position:absolute;padding:0 76px}
.head{display:flex;align-items:center;gap:20px}
.tile{width:100px;height:100px;border-radius:23px;display:grid;place-items:center;flex:none;
      box-shadow:0 16px 40px rgba(0,0,0,.6)}
.tile span{width:56px;height:56px;display:block}.tile svg{width:100%;height:100%}
.nm{font:700 38px/1.1 'Onest';text-shadow:0 2px 16px rgba(0,0,0,.7)}
.nm .n{font-weight:400;opacity:.6}
.txt{font:400 26px/1.5 'Onest';margin-top:28px;text-shadow:0 2px 20px rgba(0,0,0,.75);max-width:690px}
.txt + .txt{margin-top:22px}
.hook{font:700 36px/1.4 'Onest';text-shadow:0 2px 22px rgba(0,0,0,.8)}
.hook em{font-style:normal;box-shadow:inset 0 -2px 0 rgba(255,255,255,.55)}
.cnt{position:absolute;left:76px;bottom:54px;font:500 20px/1 'Onest';opacity:.5}
.tag{position:absolute;right:76px;bottom:54px;font:500 20px/1 'Onest';opacity:.5}
`;

const S = [];
const add = (file, b) => S.push({ name:`f-${file.slice(0,2)}`, file, folder:'F — Нативный', html: page(CSS, b) });
const frame = (i, pos, tone = 'dark') =>
  `<div class="ph" style="background-image:url('${shot(i, tone)}');background-position:${pos}"></div>`;

/* карточка приложения поверх кадра */
const app = (file, n, img, pos, place, tileBg, slug, name, paras) => add(file, `<div class="slide">
  ${frame(img, pos)}
  <div class="veil left"></div><div class="scrim ${place === 'top' ? 'up' : ''}"></div><div class="grain"></div>
  <div class="wrap" style="left:0;${place === 'top' ? 'top:13%' : 'bottom:14%'}">
    <div class="head"><div class="tile" style="background:${tileBg}">${logo(slug)}</div>
      <div class="nm"><span class="n">${n}.</span> ${name}</div></div>
    ${paras.map(p => `<p class="txt">${p}</p>`).join('')}
  </div>
  <div class="cnt">@vladlyamin</div><div class="tag">${n + 1} / 6</div>
</div>`);

/* 01 — обложка */
add('01 обложка', `<div class="slide">
  ${frame(0, '50% 78%')}
  <div class="veil top"></div><div class="grain"></div>
  <div class="wrap" style="left:0;right:0;top:30%">
    <div class="hook">пять приложений,<br>которые открыты у меня<br>прямо сейчас, в 01:40<br><br><em>без единого «топ нейросетей»</em></div>
  </div>
  <div class="cnt">@vladlyamin</div><div class="tag">1 / 6</div>
</div>`);

/* 02–05 — приложения */
app('02 claude', 1, 1, '78% 46%', 'bottom', '#0B0B0B', 'claude', 'Claude', [
  'Открыт весь день. Не для «напиши текст», а как второй мозг: думаю вслух в чат, он держит контекст проекта и спорит, когда я торможу.',
  'Один файл в корне проекта — и он знает мой стек, мои запреты и то, что я уже пробовал. Экономит первые десять минут каждого разговора.']);

app('03 cursor', 2, 2, '40% 50%', 'bottom', '#0F0F12', 'cursor', 'Cursor', [
  'Работает там, где есть окно и розетка. Правки в коде проговариваю словами, он пишет — я читаю дифф и решаю, оставлять или нет.',
  'Главное правило: не даю писать то, что не смогу прочитать. Иначе через неделю проект превращается в чужой.']);

app('04 obsidian', 3, 3, '30% 60%', 'top', '#1A1030', 'obsidian', 'Obsidian', [
  'Всё, что я когда-либо решил, лежит здесь. Не заметки ради заметок — а ответы на вопросы, которые я уже задавал себе полгода назад.',
  'Раз в неделю перечитываю то, что записал, и половину выкидываю. Остальное превращается в посты и в чужие внедрения.']);

app('05 telegram', 4, 4, '20% 60%', 'top', '#1C2733', 'telegram', 'Telegram', [
  'Здесь и клиенты, и черновики, и голосовые самому себе. Мысль ловится там, где приходит, — в метро, после звонка, перед сном.',
  'Всё, что я наговорил за день, к вечеру превращается в тексты. Я к этому моменту уже сплю.']);

/* 06 — финал */
add('06 финал', `<div class="slide">
  ${frame(5, '70% 40%')}
  <div class="veil left"></div><div class="scrim"></div><div class="grain"></div>
  <div class="wrap" style="left:0;bottom:15%">
    <div style="display:flex;gap:16px;margin-bottom:34px">
      ${[['#0B0B0B','claude'],['#0F0F12','cursor'],['#1A1030','obsidian'],['#1C2733','telegram']].map(([bg,s])=>
        `<div class="tile" style="width:76px;height:76px;border-radius:18px;background:${bg}">
          <span style="width:42px;height:42px">${logo(s)}</span></div>`).join('')}
    </div>
    <div class="hook" style="font-size:34px">пятое — заметки на бумаге,<br>и я не шучу<br><br>
      <em>напиши «стек» — расскажу, зачем</em></div>
  </div>
  <div class="cnt">@vladlyamin</div><div class="tag">6 / 6</div>
</div>`);

export const slides = S;
