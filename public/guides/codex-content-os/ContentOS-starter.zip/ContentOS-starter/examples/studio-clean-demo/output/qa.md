# QA report

- file: `examples/studio-clean-demo/output/reel.mp4`
- generated: 2026-08-20T18:29:57.037Z
- plan: `examples/studio-clean-demo/auto_edit_plan.json`
- result: **PASS** (5/5 checks passed)

## Checks

- [x] PASS — file opens and has a video stream: codec=h264
- [x] PASS — has an audio stream: codec=aac
- [x] PASS — resolution matches edit_plan.format: expected 1080x1920, got 1080x1920
- [x] PASS — fps roughly matches edit_plan.format: expected ~30fps, got 30.00fps
- [x] PASS — duration within 0.75s of edit_plan.durationSec: expected ~15.325s, got 15.32s

## Raw ffprobe summary

```
format: mov,mp4,m4a,3gp,3g2,mj2
duration: 15.325s
size: 1222139 bytes
video: h264 1080x1920 @ 30.00fps
audio: aac 22050Hz 1ch
```
