# request: studio-clean beat-sync demo

**Brand preset:** `studio-clean` — photos synced to music beats, no speech,
no transcription needed.

**Goal:** prove the one fully-real path the guide promises: a folder of
photos + a music track becomes a beat-cut vertical Reel with zero manual
timeline authoring, driven entirely by `analyze.js`'s real beat detection.

**Media (all synthetic, generated locally with `ffmpeg -f lavfi` — nothing
scraped or copied from anywhere):**

- `music/beat-track.wav` — a ~16s kick + hi-hat loop at 128 BPM, built from
  two decaying sine bursts (`aevalsrc`) mixed together. It's not meant to
  sound good — it's meant to have a genuine, detectable percussive beat so
  `analyze.js`'s onset detector has something real to find.
- `photo/photo-01.jpg` … `photo-05.jpg` — five flat-color 1080x1920 stills.

**How this differs from `examples/sample-job/`:** that example uses a
hand-written `edit_plan.json` with manual `from`/`to` timecodes. This one has
no hand-written edit plan at all — run:

```bash
node scripts/ingest.js  examples/studio-clean-demo
node scripts/analyze.js examples/studio-clean-demo
node scripts/render.js  --auto-cut-to-beats examples/studio-clean-demo examples/studio-clean-demo/output/reel.mp4
node scripts/qa.js      examples/studio-clean-demo/output/reel.mp4
```

`render.js --auto-cut-to-beats` reads the `beats.json` that `analyze.js` just
computed (real BPM + beat grid, not a stub) and `photo/`, cuts every 2 beats,
and writes the timeline it decided on to `auto_edit_plan.json` before
rendering — so you can see exactly which cut points came from which beat
timestamps.
