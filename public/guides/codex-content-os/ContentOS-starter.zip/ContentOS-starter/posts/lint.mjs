// Проверка черновика поста по списку запретов.
//
// Смысл в разделении труда: то, что ловится подстрокой, не нужно
// поручать модели. Она тратит время, стоит денег и иногда пропускает
// очевидное. Здесь остаётся только механика, а содержательная
// редактура идёт отдельным промптом.
import { readFile } from 'node:fs/promises';
import { argv, exit } from 'node:process';

// Границы слова заданы через \p{L} и \p{N}, а не через \b и \w.
// В JavaScript \b и \w считают словом только ASCII, поэтому на
// кириллице они не срабатывают: линтер молча пропускал бы весь
// русский текст, ради которого и написан.
const L = '\\p{L}\\p{N}';
const B = (body) => new RegExp(`(?<![${L}])(?:${body})(?![${L}])`, 'giu');
const W = `[${L}]*`;

const RULES = [
  {
    id: 'hype',
    note: 'хайп без содержания',
    re: B(`революц${W}|прорывн${W}|мощн${W}|невероятн${W}|потряса${W}|уникальн${W}|game[- ]changer`),
  },
  {
    id: 'filler',
    note: 'вводный оборот, который ничего не добавляет',
    re: B(`стоит отметить|важно понимать|нельзя не сказать|как известно|в современном мире|в эпоху ${W}|не секрет,? что`),
  },
  {
    id: 'crowd',
    note: 'обращение к аудитории скопом',
    re: B('друзья|ребята|коллеги|дорогие подписчики'),
  },
  {
    id: 'not-x-but-y',
    note: 'конструкция «не X, а Y»',
    re: new RegExp(`(?<![${L}])не\\s+(?:просто\\s+)?[«"']?[${L}]+[»"']?\\s*,\\s*а\\s+[${L}]`, 'giu'),
  },
  {
    id: 'vague-authority',
    note: 'обобщение без субъекта',
    re: B('многие (?:считают|думают|уверены)|эксперты (?:говорят|сходятся)|все знают|принято считать'),
  },
  {
    id: 'emoji',
    note: 'эмодзи',
    re: /[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}\u{FE0F}]/gu,
  },
  {
    id: 'exclaim',
    note: 'восклицательный знак',
    re: /!/g,
  },
];

// Тире в предложении — сильный приём, который перестаёт работать при
// повторе. Считаем на весь текст, а не по одному вхождению.
const DASH_LIMIT_PER_100_WORDS = 1.5;

function check(text) {
  const lines = text.split('\n');
  const hits = [];

  for (const rule of RULES) {
    lines.forEach((line, i) => {
      // Пропускаем блоки кода и цитаты промптов.
      if (/^\s{4}|^```|^>/.test(line)) return;
      for (const m of line.matchAll(rule.re)) {
        hits.push({ line: i + 1, id: rule.id, note: rule.note, text: m[0].trim() });
      }
    });
  }

  const words = text.split(/\s+/).filter(Boolean).length;
  const dashes = (text.match(/[—–]/g) || []).length;
  const per100 = words ? (dashes / words) * 100 : 0;
  if (per100 > DASH_LIMIT_PER_100_WORDS) {
    hits.push({
      line: 0,
      id: 'dashes',
      note: `тире ${dashes} на ${words} слов (${per100.toFixed(1)} на 100, порог ${DASH_LIMIT_PER_100_WORDS})`,
      text: '',
    });
  }

  return hits;
}

const file = argv[2];
if (!file) {
  console.error('Использование: node posts/lint.mjs drafts/post.md');
  exit(2);
}

const text = await readFile(file, 'utf8').catch(() => {
  console.error(`Не читается файл: ${file}`);
  exit(2);
});

const hits = check(text);

if (!hits.length) {
  console.log(`${file}: механических нарушений нет.`);
  console.log('Дальше — содержательная редактура, промпт 3 в posts/prompts.md.');
  exit(0);
}

console.log(`${file}: найдено ${hits.length}\n`);
for (const h of hits) {
  const where = h.line ? `строка ${h.line}` : 'весь текст';
  console.log(`  ${where}: ${h.note}${h.text ? ` — «${h.text}»` : ''}`);
}
console.log('\nЭто механическая проверка. Она не судит о смысле:');
console.log('пост без нарушений всё ещё может быть пустым.');
exit(1);
