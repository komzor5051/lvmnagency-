#!/usr/bin/env node
// analyze: PARTIAL step. What's real vs stubbed (see README "What's real vs stub"):
//
//   REAL   — keyframe extraction from every video via ffmpeg, plus a contact-sheet
//            image tiling those keyframes and photo thumbnails together.
//   REAL   — beats.json (music BPM/beat grid). Energy-based onset detection done
//            in plain JS (no librosa/essentia/madmom/PyTorch) — see detectBeats()
//            below and the README's "beats.json" row for method + limits.
//   STUB   — transcript.json (speech-to-text). NOT implemented with an ML model
//            here. We write a file with the correct shape (so downstream code /
//            Codex can already consume it) but the content is a placeholder,
//            clearly marked as such.
//
// Why transcript is stubbed: shipping openai-whisper or whisper.cpp as a hard
// dependency turns a "starter you install in five minutes" into a multi-GB ML
// install (PyTorch/CUDA or a compiled C++ binary + model weights). That's a
// deliberate scope cut for a v0 reference package — see the guide, section 27/31.
// The talking-head (speech) path stays out of scope for this pass; the
// studio-clean (photos-to-music, no speech) path does NOT need it, which is why
// beats.json got the real implementation instead.
//
// Bonus, best-effort only: if a whisper CLI (`whisper` from openai-whisper, or
// `whisper-cli`/`main` from whisper.cpp) is found on PATH, we shell out to it for
// a real transcript. Absence of any of these is NOT an error — we degrade to the
// stub silently (with a log line saying so).
//
// Usage: node scripts/analyze.js <job-dir>

import fs from "node:fs";
import path from "node:path";
import {
  VIDEO_EXT,
  PHOTO_EXT,
  AUDIO_EXT,
  fail,
  log,
  run,
  which,
  ffprobeJson,
  ffmpegDecodePcm,
  listMediaFiles,
  ensureDir,
  writeJson,
  requireJobDir,
} from "./lib.js";

// --- Beat/onset detection tuning constants ---
// Sample rate we decode audio down to for analysis. Way below CD quality —
// beat/onset detection only needs the amplitude envelope, not fine spectral
// detail, so a low rate keeps this fast and dependency-free.
const BEAT_SAMPLE_RATE = 22050;
const BEAT_FRAME_SIZE = 1024; // ~46ms window at 22050Hz
const BEAT_HOP_SIZE = 512; // ~23ms hop (50% overlap)
const BEAT_MIN_INTERVAL_SEC = 0.25; // refuse peaks closer than this (caps at 240 BPM)
const BEAT_LOCAL_WINDOW_SEC = 1.0; // adaptive-threshold window radius
const BEAT_THRESHOLD_K = 1.5; // threshold = local mean + K * local stddev
const BEAT_BPM_MIN = 40;
const BEAT_BPM_MAX = 220;

const TARGET_KEYFRAMES_PER_VIDEO = 4;
const THUMB_WIDTH = 320;

async function videoDuration(filePath) {
  const data = await ffprobeJson(filePath);
  return Number(data.format?.duration) || 0;
}

async function extractKeyframes(videoPath, outDir, baseName) {
  const duration = await videoDuration(videoPath);
  if (!duration) {
    log(`skip keyframes for ${baseName}: ffprobe reported no duration`);
    return [];
  }
  // fps = frames we want spread evenly across the clip's duration.
  const fps = Math.min(2, Math.max(1 / duration, TARGET_KEYFRAMES_PER_VIDEO / duration));
  const pattern = path.join(outDir, `${baseName}_%02d.jpg`);
  await run("ffmpeg", [
    "-y",
    "-i", videoPath,
    "-vf", `fps=${fps},scale=${THUMB_WIDTH}:-1`,
    "-frames:v", String(TARGET_KEYFRAMES_PER_VIDEO),
    "-q:v", "3",
    pattern,
  ]);
  return fs
    .readdirSync(outDir)
    .filter((f) => f.startsWith(`${baseName}_`))
    .sort()
    .map((f) => path.join(outDir, f));
}

async function makeThumbnail(photoPath, outDir, baseName) {
  const outPath = path.join(outDir, `${baseName}.jpg`);
  await run("ffmpeg", ["-y", "-i", photoPath, "-vf", `scale=${THUMB_WIDTH}:-1`, "-q:v", "3", outPath]);
  return outPath;
}

async function buildContactSheet(imagePaths, outPath) {
  if (imagePaths.length === 0) {
    log("no images to build a contact sheet from — skipping");
    return null;
  }
  const cols = Math.ceil(Math.sqrt(imagePaths.length));
  const rows = Math.ceil(imagePaths.length / cols);
  const cellW = THUMB_WIDTH;
  const cellH = Math.round((THUMB_WIDTH * 16) / 9); // fits both portrait photos and 9:16 keyframes

  if (imagePaths.length === 1) {
    await run("ffmpeg", ["-y", "-i", imagePaths[0], "-vf", `scale=${cellW}:-1`, outPath]);
    return outPath;
  }

  // Force every tile to the exact same cell size (scale to fit + pad) so the
  // grid can use plain pixel offsets in xstack's layout instead of relying on
  // per-input w0/h0 layout variables (which some ffmpeg builds mis-resolve).
  const inputArgs = imagePaths.flatMap((p) => ["-i", p]);
  // Force every tile to exactly cellW x cellH (ignoring aspect ratio — this is
  // a debug contact sheet, not a deliverable image, so a little stretch is a
  // fine trade for a filtergraph that can't fail on aspect-ratio rounding).
  const cellFilters = imagePaths
    .map((_, i) => `[${i}:v]setsar=1,scale=${cellW}:${cellH}[s${i}]`)
    .join(";");
  const scaledLabels = imagePaths.map((_, i) => `[s${i}]`);

  const layout = imagePaths.map((_, i) => {
    const col = i % cols;
    const row = Math.floor(i / cols);
    return `${col * cellW}_${row * cellH}`;
  });

  const xstackFilter = `${cellFilters};${scaledLabels.join("")}xstack=inputs=${scaledLabels.length}:layout=${layout.join("|")}[out]`;

  await run("ffmpeg", ["-y", ...inputArgs, "-filter_complex", xstackFilter, "-map", "[out]", outPath]);
  return outPath;
}

function stubTranscript(musicOrSpeechFiles) {
  return {
    schema: "content-os-starter/transcript.v0",
    stub: true,
    note:
      "STUB — no speech-to-text model ran. Wire in whisper.cpp or openai-whisper here " +
      "(see README 'What's real vs stub'). Shape matches what the guide's edit_plan " +
      "captions/CTA logic expects: word-level segments with start/end timecodes.",
    sourceFiles: musicOrSpeechFiles,
    segments: [],
  };
}

async function tryWhisperCli(videoFiles) {
  const candidates = ["whisper-cli", "whisper", "main"];
  for (const bin of candidates) {
    if (await which(bin)) return bin;
  }
  return null;
}

// --- REAL: energy-based onset/beat detection ---
//
// Method (deliberately simple DSP, no ML/DSP libraries):
//   1. Decode the track to mono PCM at BEAT_SAMPLE_RATE via ffmpeg.
//   2. Compute a short-time RMS (root-mean-square amplitude) envelope over
//      overlapping frames — this is the "loudness over time" curve.
//   3. Onset strength = half-wave-rectified frame-to-frame RMS increase
//      (a crude, energy-only stand-in for spectral flux). Percussive hits
//      show up as sharp spikes in this signal.
//   4. Smooth the onset curve (3-frame moving average) to suppress jitter.
//   5. Peak-pick with a *local* adaptive threshold (mean + K*stddev over a
//      ~1s sliding window, so it adapts to quiet/loud sections) and a
//      minimum-distance constraint between accepted peaks.
//   6. Estimate tempo from the median inter-onset interval (IOI) between
//      accepted peaks — median is robust to the occasional missed/extra hit.
//   7. Generate a regular beat grid at that estimated period, anchored on
//      the first detected onset, spanning the track's duration. This grid
//      (not the raw, possibly-uneven onset list) is what `beats` in the
//      output is for — it's what render.js's --auto-cut-to-beats mode cuts
//      photos to.
//
// Limits (see also README "What's real vs stub"): this is tuned for tracks
// with clear percussive hits (drums, clicks, claps, kick-forward EDM/hip-hop).
// It has NOT been validated on ambient, classical, or other tracks without
// sharp attacks — on those, expect fewer/noisier peaks and a less reliable
// BPM estimate. There is no beat-phase/downbeat detection (no notion of
// "beat 1 of the bar") and no tempo-doubling/halving correction — if the
// detector locks onto every other beat (or every half-beat), you'll see it
// as a BPM that's roughly 2x or 0.5x what you expect.

function rmsEnvelope(samples) {
  const numFrames = Math.max(0, Math.floor((samples.length - BEAT_FRAME_SIZE) / BEAT_HOP_SIZE));
  const rms = new Float64Array(numFrames);
  for (let i = 0; i < numFrames; i++) {
    const start = i * BEAT_HOP_SIZE;
    let sum = 0;
    for (let j = 0; j < BEAT_FRAME_SIZE; j++) {
      const s = samples[start + j] / 32768;
      sum += s * s;
    }
    rms[i] = Math.sqrt(sum / BEAT_FRAME_SIZE);
  }
  return rms;
}

function onsetStrength(rms) {
  const numFrames = rms.length;
  const flux = new Float64Array(numFrames);
  for (let i = 1; i < numFrames; i++) {
    const d = rms[i] - rms[i - 1];
    flux[i] = d > 0 ? d : 0;
  }
  // 3-frame moving average smoothing.
  const smooth = new Float64Array(numFrames);
  for (let i = 0; i < numFrames; i++) {
    const a = flux[Math.max(0, i - 1)];
    const b = flux[i];
    const c = flux[Math.min(numFrames - 1, i + 1)];
    smooth[i] = (a + b + c) / 3;
  }
  return smooth;
}

function pickPeaks(onset, sampleRate) {
  const numFrames = onset.length;
  const winFrames = Math.max(1, Math.round((BEAT_LOCAL_WINDOW_SEC * sampleRate) / BEAT_HOP_SIZE));
  const minDistFrames = Math.max(1, Math.round((BEAT_MIN_INTERVAL_SEC * sampleRate) / BEAT_HOP_SIZE));

  const peaks = [];
  let lastPeak = -Infinity;
  for (let i = 0; i < numFrames; i++) {
    const wStart = Math.max(0, i - winFrames);
    const wEnd = Math.min(numFrames, i + winFrames);
    let sum = 0;
    let sumSq = 0;
    let n = 0;
    for (let j = wStart; j < wEnd; j++) {
      sum += onset[j];
      sumSq += onset[j] * onset[j];
      n++;
    }
    const mean = sum / n;
    const variance = Math.max(0, sumSq / n - mean * mean);
    const std = Math.sqrt(variance);
    const threshold = mean + BEAT_THRESHOLD_K * std;

    if (onset[i] > threshold && onset[i] > 0) {
      const isLocalMax = onset[i] >= onset[Math.max(0, i - 1)] && onset[i] >= onset[Math.min(numFrames - 1, i + 1)];
      if (isLocalMax && i - lastPeak >= minDistFrames) {
        peaks.push(i);
        lastPeak = i;
      }
    }
  }
  return peaks.map((i) => (i * BEAT_HOP_SIZE) / sampleRate);
}

function medianOf(values) {
  if (values.length === 0) return null;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid];
}

function buildBeatGrid(firstOnsetSec, periodSec, durationSec) {
  if (firstOnsetSec == null || !periodSec || periodSec <= 0) return [];
  const grid = [];
  for (let t = firstOnsetSec; t <= durationSec + 1e-6; t += periodSec) {
    grid.push(Math.round(t * 1000) / 1000);
  }
  return grid;
}

async function analyzeTrackBeats(filePath) {
  const probed = await ffprobeJson(filePath);
  const durationSec = probed.format?.duration ? Number(probed.format.duration) : null;
  const samples = await ffmpegDecodePcm(filePath, BEAT_SAMPLE_RATE);
  const rms = rmsEnvelope(samples);
  const onset = onsetStrength(rms);
  const onsetTimes = pickPeaks(onset, BEAT_SAMPLE_RATE);

  const iois = [];
  for (let i = 1; i < onsetTimes.length; i++) iois.push(onsetTimes[i] - onsetTimes[i - 1]);
  const medianIoi = medianOf(iois);

  let bpm = medianIoi ? Math.round((60 / medianIoi) * 100) / 100 : null;
  let bpmNote = null;
  if (bpm !== null && (bpm < BEAT_BPM_MIN || bpm > BEAT_BPM_MAX)) {
    bpmNote = `raw estimate ${bpm} BPM fell outside the ${BEAT_BPM_MIN}-${BEAT_BPM_MAX} sane range — kept as-is, but treat with suspicion (likely an octave error: try x2 or /2).`;
  }

  const audioDuration = durationSec || (samples.length / BEAT_SAMPLE_RATE);
  const beats = medianIoi ? buildBeatGrid(onsetTimes[0], medianIoi, audioDuration) : [];

  return {
    file: null, // filled in by caller (relative path)
    durationSec: Math.round(audioDuration * 1000) / 1000,
    bpm,
    bpmNote,
    onsetsDetected: onsetTimes.length,
    onsets: onsetTimes.map((t) => Math.round(t * 1000) / 1000),
    beats,
  };
}

async function analyzeBeats(jobDir, musicFiles) {
  if (musicFiles.length === 0) {
    return {
      schema: "content-os-starter/beats.v0",
      stub: false,
      method: "energy-based onset detection (RMS envelope + adaptive-threshold peak-picking + median-IOI tempo estimate)",
      note: "No music files found in music/ — nothing to analyze. Not a stub: this method is real, there was just no input.",
      sourceFiles: [],
      bpm: null,
      beats: [],
      tracks: [],
    };
  }

  const tracks = [];
  for (const filePath of musicFiles) {
    const rel = path.relative(jobDir, filePath);
    log(`detecting beats: ${rel}`);
    try {
      const result = await analyzeTrackBeats(filePath);
      result.file = rel;
      tracks.push(result);
      log(
        `  -> ${result.onsetsDetected} onset(s), bpm=${result.bpm ?? "n/a"}, ` +
          `${result.beats.length} beat(s) on the generated grid`
      );
    } catch (err) {
      log(`FAIL beat detection for ${rel}: ${err.message || err}`);
      tracks.push({ file: rel, error: String(err.message || err), bpm: null, beats: [], onsets: [], onsetsDetected: 0 });
    }
  }

  // "Primary" track (what edit_plan.json's music.startSec/beat-cuts and
  // render.js's --auto-cut-to-beats default to) is the first music file, to
  // match how ingest/render already treat music/ as a single-track folder.
  const primary = tracks[0];

  return {
    schema: "content-os-starter/beats.v0",
    stub: false,
    method: "energy-based onset detection (RMS envelope + adaptive-threshold peak-picking + median-IOI tempo estimate)",
    note:
      "REAL, no ML/DSP library dependency. Good for tracks with clear percussive hits " +
      "(drums, clicks, claps, kick-forward EDM/hip-hop). Not validated on ambient or " +
      "classical music — expect a noisier/less reliable BPM estimate there. No " +
      "downbeat/bar detection, no automatic tempo-doubling correction. See " +
      "scripts/analyze.js's detectBeats block for the full method.",
    sourceFiles: musicFiles.map((f) => path.relative(jobDir, f)),
    bpm: primary?.bpm ?? null,
    beats: primary?.beats ?? [],
    tracks,
  };
}

async function main() {
  const jobDir = requireJobDir(0, "usage: node scripts/analyze.js <job-dir>");

  const hasFfmpeg = await which("ffmpeg");
  if (!hasFfmpeg) {
    fail("ffmpeg not found on PATH. Install ffmpeg (brew install ffmpeg / apt install ffmpeg).");
  }

  const videoFiles = listMediaFiles(path.join(jobDir, "video"), VIDEO_EXT);
  const photoFiles = listMediaFiles(path.join(jobDir, "photo"), PHOTO_EXT);
  const musicFiles = listMediaFiles(path.join(jobDir, "music"), AUDIO_EXT);

  const analyzeDir = path.join(jobDir, "analyze");
  const framesDir = path.join(analyzeDir, "frames");
  ensureDir(framesDir);

  // --- REAL: keyframe extraction ---
  const keyframesByVideo = {};
  const poolImages = [];

  for (const videoPath of videoFiles) {
    const base = path.basename(videoPath, path.extname(videoPath));
    log(`extracting keyframes: ${base}`);
    try {
      const frames = await extractKeyframes(videoPath, framesDir, base);
      keyframesByVideo[path.relative(jobDir, videoPath)] = frames.map((f) => path.relative(jobDir, f));
      poolImages.push(...frames);
    } catch (err) {
      log(`FAIL keyframes for ${base}: ${err.message || err}`);
    }
  }

  // --- REAL: photo thumbnails feed into the same contact sheet ---
  for (const photoPath of photoFiles) {
    const base = path.basename(photoPath, path.extname(photoPath));
    try {
      const thumb = await makeThumbnail(photoPath, framesDir, `photo_${base}`);
      poolImages.push(thumb);
    } catch (err) {
      log(`FAIL thumbnail for ${base}: ${err.message || err}`);
    }
  }

  // --- REAL: contact sheet ---
  const contactSheetPath = path.join(analyzeDir, "contact-sheet.jpg");
  let contactSheetResult = null;
  if (poolImages.length > 0) {
    try {
      contactSheetResult = await buildContactSheet(poolImages, contactSheetPath);
      log(`wrote ${contactSheetPath} (${poolImages.length} tiles)`);
    } catch (err) {
      log(`FAIL contact sheet: ${err.message || err}`);
    }
  } else {
    log("no video or photo sources found — skipping contact sheet");
  }

  // --- STUB: transcript (speech-to-text) ---
  const whisperBin = await tryWhisperCli(videoFiles);
  let transcript;
  if (whisperBin && videoFiles.length > 0) {
    log(`found '${whisperBin}' on PATH — bonus path not auto-invoked in this starter; ` +
      `see README for how to wire it into scripts/analyze.js`);
  } else {
    log("no whisper CLI on PATH — writing transcript.json as a stub");
  }
  transcript = stubTranscript(videoFiles.map((f) => path.relative(jobDir, f)));
  writeJson(path.join(jobDir, "transcript.json"), transcript);

  // --- REAL: beats.json (music BPM/beat detection) ---
  const beats = await analyzeBeats(jobDir, musicFiles);
  writeJson(path.join(jobDir, "beats.json"), beats);

  log(`wrote ${path.join(jobDir, "transcript.json")} (stub)`);
  log(`wrote ${path.join(jobDir, "beats.json")} (bpm=${beats.bpm ?? "n/a"}, ${beats.beats.length} beats)`);
  log(
    `summary: ${Object.keys(keyframesByVideo).length}/${videoFiles.length} video(s) keyframed, ` +
      `${photoFiles.length} photo thumbnail(s), contact sheet ${contactSheetResult ? "OK" : "skipped"}`
  );
}

main().catch((err) => fail(err.stack || String(err)));
