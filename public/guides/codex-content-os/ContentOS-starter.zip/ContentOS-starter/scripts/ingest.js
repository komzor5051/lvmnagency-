#!/usr/bin/env node
// ingest: scan a job folder (video/, photo/, music/), probe every media
// file with ffprobe, hash it, flag duplicates, and write manifest.json.
//
// Usage: node scripts/ingest.js <job-dir>

import path from "node:path";
import {
  MEDIA_DIRS,
  VIDEO_EXT,
  PHOTO_EXT,
  AUDIO_EXT,
  fail,
  log,
  which,
  ffprobeJson,
  sha256File,
  listMediaFiles,
  writeJson,
  requireJobDir,
} from "./lib.js";

function parseFrameRate(rate) {
  if (!rate || rate === "0/0") return null;
  const [num, den] = rate.split("/").map(Number);
  if (!den) return num || null;
  return Math.round((num / den) * 100) / 100;
}

function orientationOf(width, height) {
  if (!width || !height) return "unknown";
  if (width === height) return "square";
  return width > height ? "horizontal" : "vertical";
}

async function probeOne(filePath, kind) {
  const data = await ffprobeJson(filePath);
  const format = data.format || {};
  const videoStream = (data.streams || []).find((s) => s.codec_type === "video");
  const audioStream = (data.streams || []).find((s) => s.codec_type === "audio");

  const width = videoStream?.width ?? null;
  const height = videoStream?.height ?? null;

  return {
    path: path.relative(process.cwd(), filePath),
    kind,
    sizeBytes: Number(format.size) || null,
    durationSec: format.duration ? Math.round(Number(format.duration) * 1000) / 1000 : null,
    width,
    height,
    orientation: kind === "photo" || kind === "video" ? orientationOf(width, height) : null,
    fps: videoStream ? parseFrameRate(videoStream.r_frame_rate) : null,
    videoCodec: videoStream?.codec_name ?? null,
    audioCodec: audioStream?.codec_name ?? null,
    hasAudio: Boolean(audioStream),
    sha256: sha256File(filePath),
  };
}

async function main() {
  const jobDir = requireJobDir(0, "usage: node scripts/ingest.js <job-dir>");

  const hasFfprobe = await which("ffprobe");
  if (!hasFfprobe) {
    fail("ffprobe not found on PATH. Install ffmpeg (brew install ffmpeg / apt install ffmpeg).");
  }

  for (const dir of MEDIA_DIRS) {
    // Not fatal if a subfolder is missing — a job can be photo-only, etc.
    const full = path.join(jobDir, dir);
    log(`scanning ${dir}/ ...`);
    void full;
  }

  const videoFiles = listMediaFiles(path.join(jobDir, "video"), VIDEO_EXT);
  const photoFiles = listMediaFiles(path.join(jobDir, "photo"), PHOTO_EXT);
  const musicFiles = listMediaFiles(path.join(jobDir, "music"), AUDIO_EXT);

  const allFiles = [
    ...videoFiles.map((f) => [f, "video"]),
    ...photoFiles.map((f) => [f, "photo"]),
    ...musicFiles.map((f) => [f, "music"]),
  ];

  if (allFiles.length === 0) {
    fail(`no media found in ${jobDir} (expected video/, photo/, and/or music/ subfolders)`);
  }

  const files = [];
  const errors = [];
  for (const [filePath, kind] of allFiles) {
    try {
      const probed = await probeOne(filePath, kind);
      files.push(probed);
      log(`ok   ${probed.path} (${probed.durationSec ?? "?"}s, ${probed.width ?? "?"}x${probed.height ?? "?"})`);
    } catch (err) {
      errors.push({ path: path.relative(process.cwd(), filePath), error: String(err.message || err) });
      log(`FAIL ${filePath}: ${err.message || err}`);
    }
  }

  // Duplicate detection by content hash.
  const byHash = new Map();
  for (const f of files) {
    if (!byHash.has(f.sha256)) byHash.set(f.sha256, []);
    byHash.get(f.sha256).push(f.path);
  }
  const duplicateGroups = [...byHash.values()].filter((group) => group.length > 1);

  const manifest = {
    schema: "content-os-starter/manifest.v0",
    generatedAt: new Date().toISOString(),
    jobDir: path.relative(process.cwd(), jobDir),
    counts: {
      video: videoFiles.length,
      photo: photoFiles.length,
      music: musicFiles.length,
      errors: errors.length,
    },
    files,
    duplicates: duplicateGroups,
    errors,
  };

  const outPath = path.join(jobDir, "manifest.json");
  writeJson(outPath, manifest);

  log(`wrote ${outPath}`);
  log(
    `summary: ${videoFiles.length} video, ${photoFiles.length} photo, ${musicFiles.length} music, ` +
      `${duplicateGroups.length} duplicate group(s), ${errors.length} error(s)`
  );

  if (errors.length > 0) {
    process.exitCode = 1;
  }
}

main().catch((err) => fail(err.stack || String(err)));
