// Shared helpers for the ContentOS starter scripts.
// No npm dependencies on purpose — everything here is either Node core
// (fs, path, crypto, child_process) or a shell-out to ffmpeg/ffprobe.

import { spawn } from "node:child_process";
import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";

export const MEDIA_DIRS = ["video", "photo", "music"];

export const VIDEO_EXT = new Set([".mp4", ".mov", ".m4v", ".webm", ".avi", ".mkv"]);
export const PHOTO_EXT = new Set([".jpg", ".jpeg", ".png", ".webp", ".heic"]);
export const AUDIO_EXT = new Set([".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg"]);

export function fail(message) {
  console.error(`[ContentOS] ERROR: ${message}`);
  process.exit(1);
}

export function log(message) {
  console.log(`[ContentOS] ${message}`);
}

/** Run a CLI command and collect stdout. Rejects with stderr on non-zero exit. */
export function run(cmd, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args, { stdio: ["ignore", "pipe", "pipe"], ...options });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (d) => (stdout += d.toString()));
    child.stderr.on("data", (d) => (stderr += d.toString()));
    child.on("error", (err) => {
      if (err.code === "ENOENT") {
        reject(new Error(`command not found: ${cmd}`));
      } else {
        reject(err);
      }
    });
    child.on("close", (code) => {
      if (code === 0) {
        resolve({ stdout, stderr });
      } else {
        reject(new Error(`${cmd} ${args.join(" ")} exited with code ${code}\n${stderr}`));
      }
    });
  });
}

/** Check whether a CLI tool exists on PATH. */
export async function which(cmd) {
  try {
    await run(process.platform === "win32" ? "where" : "which", [cmd]);
    return true;
  } catch {
    return false;
  }
}

export async function ffprobeJson(filePath) {
  const { stdout } = await run("ffprobe", [
    "-v", "quiet",
    "-print_format", "json",
    "-show_format",
    "-show_streams",
    filePath,
  ]);
  return JSON.parse(stdout);
}

/**
 * Decode an audio file to mono 16-bit PCM at the given sample rate and return
 * it as an Int16Array. Used for lightweight signal-processing (beat/onset
 * detection) that doesn't want string-mangled stdout — `run()` above collects
 * stdout as text, which corrupts binary audio data, so this shells out to
 * ffmpeg directly and collects Buffer chunks instead.
 */
export function ffmpegDecodePcm(filePath, sampleRate) {
  return new Promise((resolve, reject) => {
    const args = [
      "-v", "quiet",
      "-i", filePath,
      "-ac", "1",
      "-ar", String(sampleRate),
      "-f", "s16le",
      "pipe:1",
    ];
    const child = spawn("ffmpeg", args, { stdio: ["ignore", "pipe", "pipe"] });
    const chunks = [];
    let stderr = "";
    child.stdout.on("data", (d) => chunks.push(d));
    child.stderr.on("data", (d) => (stderr += d.toString()));
    child.on("error", (err) => {
      if (err.code === "ENOENT") reject(new Error("command not found: ffmpeg"));
      else reject(err);
    });
    child.on("close", (code) => {
      if (code !== 0) {
        reject(new Error(`ffmpeg (pcm decode) ${filePath} exited with code ${code}\n${stderr}`));
        return;
      }
      const buf = Buffer.concat(chunks);
      // Buffer's backing ArrayBuffer may be a shared pool slice — copy to a
      // tight buffer before viewing as Int16Array so byteOffset/length line up.
      const aligned = Buffer.alloc(buf.length);
      buf.copy(aligned);
      resolve(new Int16Array(aligned.buffer, 0, Math.floor(aligned.length / 2)));
    });
  });
}

export function sha256File(filePath) {
  const hash = createHash("sha256");
  hash.update(fs.readFileSync(filePath));
  return hash.digest("hex");
}

export function listMediaFiles(dir, extSet) {
  if (!fs.existsSync(dir)) return [];
  return fs
    .readdirSync(dir)
    .filter((name) => !name.startsWith("."))
    .filter((name) => extSet.has(path.extname(name).toLowerCase()))
    .sort()
    .map((name) => path.join(dir, name));
}

export function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

export function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

export function writeJson(filePath, data) {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2) + "\n", "utf8");
}

export function requireJobDir(argIndex, usage) {
  const jobDir = process.argv[2 + argIndex];
  if (!jobDir) {
    fail(usage);
  }
  const resolved = path.resolve(jobDir);
  if (!fs.existsSync(resolved) || !fs.statSync(resolved).isDirectory()) {
    fail(`job folder not found: ${resolved}`);
  }
  return resolved;
}
