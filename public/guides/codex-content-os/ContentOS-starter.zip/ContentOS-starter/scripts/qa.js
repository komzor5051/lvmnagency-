#!/usr/bin/env node
// qa: REAL. Runs ffprobe on a rendered mp4 and checks it against the
// edit_plan.json spec (resolution, fps, audio stream present, duration within
// tolerance). Writes qa.md with a pass/fail line per check and exits non-zero
// on any failure (so it's CI-friendly).
//
// Usage: node scripts/qa.js <output.mp4> [edit_plan.json]
//   If edit_plan.json is omitted, qa.js looks for a render.json written by
//   render.js next to <output.mp4> and reads the plan path from there.

import fs from "node:fs";
import path from "node:path";
import { fail, log, ffprobeJson, readJson, which, requireJobDir as _unused } from "./lib.js";

const DURATION_TOLERANCE_SEC = 0.75;
const FPS_TOLERANCE = 0.5;

function findPlanPath(outputPath, explicitPlanPath) {
  if (explicitPlanPath) return path.resolve(explicitPlanPath);
  const renderJsonPath = path.join(path.dirname(outputPath), "render.json");
  if (fs.existsSync(renderJsonPath)) {
    const renderInfo = readJson(renderJsonPath);
    if (renderInfo.plan) {
      const candidate = path.resolve(path.dirname(renderJsonPath), "..", renderInfo.plan);
      if (fs.existsSync(candidate)) return candidate;
      // render.json stores a path relative to CWD at render time; try that directly too.
      const fromCwd = path.resolve(renderInfo.plan);
      if (fs.existsSync(fromCwd)) return fromCwd;
    }
  }
  return null;
}

async function main() {
  const outputArg = process.argv[2];
  const planArg = process.argv[3];
  if (!outputArg) {
    fail("usage: node scripts/qa.js <output.mp4> [edit_plan.json]");
  }
  const outputPath = path.resolve(outputArg);
  if (!fs.existsSync(outputPath)) {
    fail(`output file not found: ${outputPath}`);
  }

  const hasFfprobe = await which("ffprobe");
  if (!hasFfprobe) {
    fail("ffprobe not found on PATH. Install ffmpeg (brew install ffmpeg / apt install ffmpeg).");
  }

  const planPath = findPlanPath(outputPath, planArg);
  let plan = null;
  if (planPath && fs.existsSync(planPath)) {
    plan = readJson(planPath);
    log(`checking against plan: ${planPath}`);
  } else {
    log("no edit_plan.json found — running format-only checks (no expected values to compare against)");
  }

  const data = await ffprobeJson(outputPath);
  const format = data.format || {};
  const videoStream = (data.streams || []).find((s) => s.codec_type === "video");
  const audioStream = (data.streams || []).find((s) => s.codec_type === "audio");

  const actualDuration = Number(format.duration) || 0;
  const actualWidth = videoStream?.width ?? null;
  const actualHeight = videoStream?.height ?? null;
  const actualFps = videoStream?.r_frame_rate
    ? (() => {
        const [n, d] = videoStream.r_frame_rate.split("/").map(Number);
        return d ? n / d : n;
      })()
    : null;

  const checks = [];

  function check(name, passed, detail) {
    checks.push({ name, passed, detail });
    log(`${passed ? "PASS" : "FAIL"} — ${name}: ${detail}`);
  }

  check("file opens and has a video stream", Boolean(videoStream), videoStream ? `codec=${videoStream.codec_name}` : "no video stream found");
  check("has an audio stream", Boolean(audioStream), audioStream ? `codec=${audioStream.codec_name}` : "no audio stream found");

  if (plan?.format?.width && plan?.format?.height) {
    check(
      "resolution matches edit_plan.format",
      actualWidth === plan.format.width && actualHeight === plan.format.height,
      `expected ${plan.format.width}x${plan.format.height}, got ${actualWidth}x${actualHeight}`
    );
  } else {
    check("resolution looks vertical (9:16-ish)", Boolean(actualWidth && actualHeight && actualHeight > actualWidth), `${actualWidth}x${actualHeight}`);
  }

  if (plan?.format?.fps) {
    check(
      "fps roughly matches edit_plan.format",
      actualFps !== null && Math.abs(actualFps - plan.format.fps) <= FPS_TOLERANCE,
      `expected ~${plan.format.fps}fps, got ${actualFps?.toFixed(2)}fps`
    );
  } else {
    check("fps is present", actualFps !== null, `${actualFps?.toFixed(2)}fps`);
  }

  if (typeof plan?.durationSec === "number") {
    check(
      `duration within ${DURATION_TOLERANCE_SEC}s of edit_plan.durationSec`,
      Math.abs(actualDuration - plan.durationSec) <= DURATION_TOLERANCE_SEC,
      `expected ~${plan.durationSec}s, got ${actualDuration.toFixed(2)}s`
    );
  } else {
    check("duration is non-zero", actualDuration > 0, `${actualDuration.toFixed(2)}s`);
  }

  const passCount = checks.filter((c) => c.passed).length;
  const allPass = passCount === checks.length;

  const md = [
    "# QA report",
    "",
    `- file: \`${path.relative(process.cwd(), outputPath)}\``,
    `- generated: ${new Date().toISOString()}`,
    `- plan: ${planPath ? "`" + path.relative(process.cwd(), planPath) + "`" : "(none found — format-only checks)"}`,
    `- result: **${allPass ? "PASS" : "FAIL"}** (${passCount}/${checks.length} checks passed)`,
    "",
    "## Checks",
    "",
    ...checks.map((c) => `- [${c.passed ? "x" : " "}] ${c.passed ? "PASS" : "FAIL"} — ${c.name}: ${c.detail}`),
    "",
    "## Raw ffprobe summary",
    "",
    "```",
    `format: ${format.format_name}`,
    `duration: ${actualDuration.toFixed(3)}s`,
    `size: ${format.size} bytes`,
    `video: ${videoStream ? `${videoStream.codec_name} ${actualWidth}x${actualHeight} @ ${actualFps?.toFixed(2)}fps` : "none"}`,
    `audio: ${audioStream ? `${audioStream.codec_name} ${audioStream.sample_rate}Hz ${audioStream.channels}ch` : "none"}`,
    "```",
    "",
  ].join("\n");

  const qaPath = path.join(path.dirname(outputPath), "qa.md");
  fs.writeFileSync(qaPath, md, "utf8");
  log(`wrote ${qaPath}`);
  log(`RESULT: ${allPass ? "PASS" : "FAIL"} (${passCount}/${checks.length})`);

  if (!allPass) process.exitCode = 1;
}

main().catch((err) => fail(err.stack || String(err)));
