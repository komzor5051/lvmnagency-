#!/usr/bin/env node
// render: REAL. Reads edit_plan.json and renders a vertical mp4 with plain
// FFmpeg (no Remotion, no headless browser — see README for why).
//
// edit_plan.json schema (schemas/edit_plan.schema.json):
//   format: {width, height, fps}
//   brand: string
//   durationSec: number
//   hook: string
//   music: {file, startSec}
//   timeline: [{from, to, source, effect?, text?, sourceIn?}]
//
// Pipeline:
//   1. Each timeline entry is rendered to its own silent clip:
//      - image sources get a Ken Burns slow-zoom via zoompan
//      - video sources get trimmed (sourceIn) and scaled/cropped to fill the
//        target frame (scale + crop, never stretch)
//      - text overlays via drawtext, if `text` is set
//   2. Clips are concatenated in timeline order.
//   3. Background music is mixed in starting at music.startSec, trimmed to
//      the total render duration.
//
// Usage:
//   node scripts/render.js <edit_plan.json> <output.mp4>
//
// Beat-synced photo montage (the "studio-clean" preset path — see README
// "beats.json"/"studio-clean" for why this exists and how it's wired):
//   node scripts/render.js --auto-cut-to-beats <job-dir> <output.mp4> [beatsPerCut]
//
// This mode does NOT read an edit_plan.json you wrote by hand — it GENERATES
// one from a real beats.json (written by `analyze.js`, REAL beat detection)
// plus every photo in <job-dir>/photo/, cutting to the nearest beat every
// `beatsPerCut` beats (default 2) and cycling through photos round-robin. The
// generated plan is written to <job-dir>/auto_edit_plan.json so you can see
// exactly what was decided, then rendered through the same clip pipeline as
// the manual path above. Why this design over a `syncToBeats` flag on a
// hand-written edit_plan.json: it's the simpler, more honest thing to
// demonstrate end-to-end for a "no stubs" claim — it proves beats.json's
// numbers are actually driving cut points, with no manual timeline authoring
// required, which is exactly what the studio-clean promise is (photos synced
// to music, zero manual timing work).

import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import {
  fail,
  log,
  run,
  which,
  ensureDir,
  readJson,
  writeJson,
} from "./lib.js";

function escapeDrawtext(text) {
  // ffmpeg drawtext needs several characters escaped inside the filter string.
  return String(text)
    .replace(/\\/g, "\\\\\\\\")
    .replace(/:/g, "\\:")
    .replace(/'/g, "\u2019") // swap in a typographic apostrophe, simplest safe fix
    .replace(/%/g, "\\%")
    .replace(/,/g, "\\,")
    .replace(/\[/g, "\\[")
    .replace(/\]/g, "\\]");
}

function drawtextFilter(text, height) {
  const safe = escapeDrawtext(text);
  const y = Math.round(height * 0.82);
  return (
    `drawtext=text='${safe}':fontcolor=white:fontsize=54:` +
    `box=1:boxcolor=black@0.45:boxborderw=24:` +
    `x=(w-text_w)/2:y=${y}:line_spacing=8`
  );
}

async function renderImageClip({ srcPath, durationSec, fps, width, height, text, outPath }) {
  const frames = Math.max(2, Math.round(durationSec * fps));
  const filters = [
    `scale=${width}:${height}:force_original_aspect_ratio=increase`,
    `crop=${width}:${height}`,
    `zoompan=z='min(zoom+0.0015,1.3)':d=${frames}:s=${width}x${height}:fps=${fps}`,
    "format=yuv420p",
  ];
  if (text) filters.push(drawtextFilter(text, height));

  await run("ffmpeg", [
    "-y",
    "-loop", "1",
    "-i", srcPath,
    "-t", String(durationSec),
    "-vf", filters.join(","),
    "-r", String(fps),
    "-an",
    "-c:v", "libx264",
    "-pix_fmt", "yuv420p",
    outPath,
  ]);
}

async function renderVideoClip({ srcPath, sourceIn, durationSec, fps, width, height, text, outPath }) {
  const filters = [
    `scale=${width}:${height}:force_original_aspect_ratio=increase`,
    `crop=${width}:${height}`,
    `fps=${fps}`,
    "format=yuv420p",
  ];
  if (text) filters.push(drawtextFilter(text, height));

  const args = ["-y"];
  if (sourceIn) args.push("-ss", String(sourceIn));
  args.push("-i", srcPath, "-t", String(durationSec), "-vf", filters.join(","));
  args.push("-r", String(fps), "-an", "-c:v", "libx264", "-pix_fmt", "yuv420p", outPath);

  await run("ffmpeg", args);
}

async function concatClips(clipPaths, listPath, outPath) {
  const listContent = clipPaths.map((p) => `file '${p.replace(/'/g, "'\\''")}'`).join("\n") + "\n";
  fs.writeFileSync(listPath, listContent, "utf8");
  await run("ffmpeg", [
    "-y",
    "-f", "concat",
    "-safe", "0",
    "-i", listPath,
    "-c:v", "libx264",
    "-pix_fmt", "yuv420p",
    "-an",
    outPath,
  ]);
}

async function muxMusic({ videoPath, musicPath, startSec, durationSec, outPath }) {
  await run("ffmpeg", [
    "-y",
    "-i", videoPath,
    "-ss", String(startSec || 0),
    "-i", musicPath,
    "-filter_complex",
    `[1:a]atrim=0:${durationSec},asetpts=PTS-STARTPTS,afade=t=in:st=0:d=0.5,` +
      `afade=t=out:st=${Math.max(0, durationSec - 0.5)}:d=0.5[aout]`,
    "-map", "0:v",
    "-map", "[aout]",
    "-shortest",
    "-c:v", "copy",
    "-c:a", "aac",
    "-b:a", "192k",
    outPath,
  ]);
}

async function muxSilent({ videoPath, outPath, durationSec }) {
  // No music file supplied — still guarantee an audio stream so downstream
  // QA (and Instagram/TikTok uploaders) don't choke on a video-only file.
  await run("ffmpeg", [
    "-y",
    "-i", videoPath,
    "-f", "lavfi",
    "-t", String(durationSec),
    "-i", "anullsrc=channel_layout=stereo:sample_rate=44100",
    "-map", "0:v",
    "-map", "1:a",
    "-shortest",
    "-c:v", "copy",
    "-c:a", "aac",
    outPath,
  ]);
}

/**
 * Render a fully-resolved edit_plan.json object to <outPath>. Shared by both
 * the manual `<edit_plan.json> <output.mp4>` path and the generated plan
 * from --auto-cut-to-beats — both end up calling this with a plain object.
 *
 * `planPathForLog` is only used to populate render.json's `plan` field; for
 * the auto-cut path it points at the generated auto_edit_plan.json so the
 * provenance is visible in the render manifest.
 */
async function renderPlan(plan, jobDir, outPath, planPathForLog) {
  if (!plan.format || !plan.format.width || !plan.format.height || !plan.format.fps) {
    fail("edit_plan missing format.{width,height,fps}");
  }
  if (!Array.isArray(plan.timeline) || plan.timeline.length === 0) {
    fail("edit_plan has no timeline entries");
  }

  const { width, height, fps } = plan.format;
  ensureDir(path.dirname(outPath));

  const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "content-os-render-"));
  log(`working dir: ${tmpDir}`);

  const clipPaths = [];
  let index = 0;
  for (const entry of plan.timeline) {
    index += 1;
    const { from, to, source, text } = entry;
    if (typeof from !== "number" || typeof to !== "number" || to <= from) {
      fail(`timeline entry #${index} has an invalid from/to range`);
    }
    const durationSec = to - from;
    const srcPath = path.resolve(jobDir, source);
    if (!fs.existsSync(srcPath)) {
      fail(`timeline entry #${index}: source not found: ${srcPath}`);
    }
    const ext = path.extname(srcPath).toLowerCase();
    const isImage = [".jpg", ".jpeg", ".png", ".webp"].includes(ext);
    const clipOut = path.join(tmpDir, `clip_${String(index).padStart(3, "0")}.mp4`);

    log(`clip ${index}: ${path.basename(srcPath)} [${from}s -> ${to}s] (${isImage ? "image/ken-burns" : "video"})`);

    if (isImage) {
      await renderImageClip({ srcPath, durationSec, fps, width, height, text, outPath: clipOut });
    } else {
      await renderVideoClip({
        srcPath,
        sourceIn: entry.sourceIn || 0,
        durationSec,
        fps,
        width,
        height,
        text,
        outPath: clipOut,
      });
    }
    clipPaths.push(clipOut);
  }

  const concatOut = path.join(tmpDir, "concat.mp4");
  const listPath = path.join(tmpDir, "concat_list.txt");
  log(`concatenating ${clipPaths.length} clip(s)...`);
  await concatClips(clipPaths, listPath, concatOut);

  const totalDuration = plan.timeline[plan.timeline.length - 1].to;

  if (plan.music && plan.music.file) {
    const musicPath = path.resolve(jobDir, plan.music.file);
    if (!fs.existsSync(musicPath)) {
      fail(`music file not found: ${musicPath}`);
    }
    log(`mixing music: ${plan.music.file} starting at ${plan.music.startSec || 0}s`);
    await muxMusic({
      videoPath: concatOut,
      musicPath,
      startSec: plan.music.startSec || 0,
      durationSec: totalDuration,
      outPath,
    });
  } else {
    log("no music specified in edit_plan — writing a silent audio track");
    await muxSilent({ videoPath: concatOut, outPath, durationSec: totalDuration });
  }

  fs.rmSync(tmpDir, { recursive: true, force: true });

  log(`wrote ${outPath}`);

  // Small render-manifest alongside the render, useful for QA/debugging.
  const renderLogPath = path.join(path.dirname(outPath), "render.json");
  writeJson(renderLogPath, {
    schema: "content-os-starter/render.v0",
    generatedAt: new Date().toISOString(),
    plan: planPathForLog ? path.relative(process.cwd(), planPathForLog) : null,
    output: path.relative(process.cwd(), outPath),
    clips: plan.timeline.length,
    totalDurationSec: totalDuration,
  });
  log(`wrote ${renderLogPath}`);
}

const IMAGE_EXT = new Set([".jpg", ".jpeg", ".png", ".webp"]);
const AUDIO_EXT = new Set([".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg"]);

/**
 * Build an edit_plan.json-shaped object from a REAL beats.json (see
 * analyze.js) and every photo in <jobDir>/photo/, cutting on the beat grid
 * every `beatsPerCut` beats. Photos are assigned round-robin, looping if
 * there are more segments than photos. This is what makes the
 * "studio-clean" (photos-to-music, no speech) path demonstrably real: cut
 * points come straight from beats.json's detected `beats` array, not from a
 * human typing timecodes.
 */
function buildAutoCutPlan(jobDir, beatsPerCut) {
  const beatsPath = path.join(jobDir, "beats.json");
  if (!fs.existsSync(beatsPath)) {
    fail(`beats.json not found in ${jobDir} — run 'node scripts/analyze.js ${jobDir}' first`);
  }
  const beatsData = readJson(beatsPath);
  if (beatsData.stub) {
    fail(`beats.json in ${jobDir} is a stub (no beat detection ran) — --auto-cut-to-beats needs real beats`);
  }
  if (!Array.isArray(beatsData.beats) || beatsData.beats.length < 2) {
    fail(
      `beats.json has fewer than 2 detected beats — can't build a beat-synced timeline. ` +
        `Re-run analyze.js on a track with a clearer beat, or check its "note"/"bpmNote" fields.`
    );
  }

  const photoDir = path.join(jobDir, "photo");
  if (!fs.existsSync(photoDir)) {
    fail(`no photo/ folder in ${jobDir} — --auto-cut-to-beats needs at least one photo`);
  }
  const photos = fs
    .readdirSync(photoDir)
    .filter((f) => !f.startsWith(".") && IMAGE_EXT.has(path.extname(f).toLowerCase()))
    .sort()
    .map((f) => path.join("photo", f));
  if (photos.length === 0) {
    fail(`no photos found in ${photoDir} — --auto-cut-to-beats needs at least one photo`);
  }

  const musicDir = path.join(jobDir, "music");
  const musicFiles = fs.existsSync(musicDir)
    ? fs
        .readdirSync(musicDir)
        .filter((f) => !f.startsWith(".") && AUDIO_EXT.has(path.extname(f).toLowerCase()))
        .sort()
    : [];
  const primaryTrackRel = beatsData.tracks?.[0]?.file || (musicFiles.length ? path.join("music", musicFiles[0]) : null);
  if (!primaryTrackRel) {
    fail(`no music file found — --auto-cut-to-beats needs the track beats.json was analyzed from`);
  }

  // Cut points = every Nth beat (beatsPerCut), starting at the first beat.
  const beats = beatsData.beats;
  const cutBeats = beats.filter((_, i) => i % beatsPerCut === 0);
  if (cutBeats[cutBeats.length - 1] !== beats[beats.length - 1]) {
    cutBeats.push(beats[beats.length - 1]); // always end on the last detected beat
  }

  const startSec = cutBeats[0];
  const timeline = [];
  for (let i = 0; i < cutBeats.length - 1; i++) {
    const from = Math.round((cutBeats[i] - startSec) * 1000) / 1000;
    const to = Math.round((cutBeats[i + 1] - startSec) * 1000) / 1000;
    if (to <= from) continue; // guards against two beats rounding to the same instant
    const photo = photos[i % photos.length];
    timeline.push({
      from,
      to,
      source: photo,
      effect: "slow-zoom",
      text: null,
      transition: "beat-cut",
    });
  }
  if (timeline.length === 0) {
    fail("auto-cut produced zero usable timeline segments — track may be too short or beatsPerCut too large");
  }

  const durationSec = timeline[timeline.length - 1].to;

  return {
    format: { width: 1080, height: 1920, fps: 30 },
    brand: "studio-clean",
    durationSec,
    hook: "auto-generated: photos cut to the beat via analyze.js's real beats.json",
    music: { file: primaryTrackRel, startSec },
    timeline,
    captions: { enabled: false, preset: "studio-clean" },
    generatedBy: {
      mode: "--auto-cut-to-beats",
      beatsPerCut,
      sourceBeatsFile: "beats.json",
      bpm: beatsData.bpm,
      cutCount: timeline.length,
      photosUsed: photos.length,
    },
  };
}

function printUsage() {
  fail(
    "usage:\n" +
      "  node scripts/render.js <edit_plan.json> <output.mp4>\n" +
      "  node scripts/render.js --auto-cut-to-beats <job-dir> <output.mp4> [beatsPerCut]"
  );
}

async function main() {
  const hasFfmpeg = await which("ffmpeg");
  if (!hasFfmpeg) {
    fail("ffmpeg not found on PATH. Install ffmpeg (brew install ffmpeg / apt install ffmpeg).");
  }

  if (process.argv[2] === "--auto-cut-to-beats") {
    const jobDirArg = process.argv[3];
    const outArg = process.argv[4];
    const beatsPerCut = process.argv[5] ? Number(process.argv[5]) : 2;
    if (!jobDirArg || !outArg) printUsage();
    if (!Number.isInteger(beatsPerCut) || beatsPerCut < 1) {
      fail(`beatsPerCut must be a positive integer, got: ${process.argv[5]}`);
    }

    const jobDir = path.resolve(jobDirArg);
    if (!fs.existsSync(jobDir)) fail(`job folder not found: ${jobDir}`);

    log(`--auto-cut-to-beats: building timeline from beats.json (every ${beatsPerCut} beat(s))`);
    const plan = buildAutoCutPlan(jobDir, beatsPerCut);

    const autoPlanPath = path.join(jobDir, "auto_edit_plan.json");
    writeJson(autoPlanPath, plan);
    log(`wrote ${autoPlanPath} (${plan.timeline.length} cuts, bpm=${plan.generatedBy.bpm ?? "n/a"})`);

    const outPath = path.resolve(outArg);
    await renderPlan(plan, jobDir, outPath, autoPlanPath);
    return;
  }

  const planPath = process.argv[2];
  const outArg = process.argv[3];
  if (!planPath || !outArg) printUsage();
  const resolvedPlanPath = path.resolve(planPath);
  if (!fs.existsSync(resolvedPlanPath)) {
    fail(`edit_plan.json not found: ${resolvedPlanPath}`);
  }

  const plan = readJson(resolvedPlanPath);
  const jobDir = path.dirname(resolvedPlanPath);
  const outPath = path.resolve(outArg);

  await renderPlan(plan, jobDir, outPath, resolvedPlanPath);
}

main().catch((err) => fail(err.stack || String(err)));
