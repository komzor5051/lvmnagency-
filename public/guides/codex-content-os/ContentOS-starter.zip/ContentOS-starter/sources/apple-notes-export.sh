#!/usr/bin/env bash
#
# apple-notes-export.sh
#
# Выгружает заметки из Apple Notes в markdown-файлы.
# Зависимости: osascript (встроен в macOS), pandoc (brew install pandoc).
#
# Notes.app отдаёт тело заметки как HTML (свойство "body"), поэтому конвертация
# в markdown идёт через pandoc -f html -t markdown, а не напрямую через osascript.

set -euo pipefail

SCRIPT_NAME="$(basename "$0")"

usage() {
  cat <<EOF
Использование:
  $SCRIPT_NAME --list
  $SCRIPT_NAME --folder "Идеи" --out inbox/notes
  $SCRIPT_NAME --search "карусель" --out inbox/notes

Опции:
  --list            показать список папок Apple Notes и число заметок в каждой
  --folder ИМЯ      выгрузить все заметки из папки ИМЯ
  --search СТРОКА   выгрузить заметки, в теле которых встречается СТРОКА
  --out ПУТЬ        папка назначения для .md файлов (обязателен при --folder/--search)
  -h, --help        показать эту справку

Заметки экспортируются как markdown с frontmatter (заголовок, дата изменения,
папка-источник). Каждая заметка -- отдельный файл.
EOF
}

MODE=""
FOLDER=""
SEARCH=""
OUT_DIR=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --list)
      MODE="list"
      shift
      ;;
    --folder)
      MODE="folder"
      FOLDER="${2:-}"
      shift 2
      ;;
    --search)
      MODE="search"
      SEARCH="${2:-}"
      shift 2
      ;;
    --out)
      OUT_DIR="${2:-}"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Неизвестный аргумент: $1" >&2
      usage >&2
      exit 1
      ;;
  esac
done

if [[ -z "$MODE" ]]; then
  echo "Нужно указать --list, --folder или --search." >&2
  usage >&2
  exit 1
fi

if [[ "$MODE" != "list" && -z "$OUT_DIR" ]]; then
  echo "Для --folder/--search нужен --out ПУТЬ." >&2
  exit 1
fi

check_pandoc() {
  if ! command -v pandoc >/dev/null 2>&1; then
    echo "Не найден pandoc. Установите его: brew install pandoc" >&2
    exit 1
  fi
}

# osascript возвращает ненулевой код и сообщение об ошибке -1743 / -1744,
# если приложению не разрешена автоматизация -- перехватываем это отдельно,
# чтобы дать понятную инструкцию вместо сырого стектрейса AppleScript.
check_automation_access() {
  local probe_err
  if ! probe_err=$(osascript -e 'tell application "Notes" to get name of every folder' 2>&1 >/dev/null); then
    echo "Нет доступа к Apple Notes через автоматизацию (AppleScript)." >&2
    echo "Причина: $probe_err" >&2
    echo "Включите доступ в System Settings -> Privacy & Security -> Automation -> найдите Terminal (или ваше приложение) и разрешите управление приложением Notes." >&2
    exit 1
  fi
}

# Безопасное имя файла: убираем слеши и двоеточия (запрещены в путях macOS/HFS+),
# кириллицу и пробелы оставляем как есть -- так просил заказчик.
sanitize_filename() {
  local name="$1"
  name="${name//\//_}"
  name="${name//:/_}"
  # заголовок заметки может быть пустым (первая строка тела пустая) -- подстрахуемся
  if [[ -z "$name" ]]; then
    name="untitled"
  fi
  printf '%s' "$name"
}

do_list() {
  check_automation_access
  echo "Папки Apple Notes:"
  osascript <<'APPLESCRIPT'
tell application "Notes"
  set out to ""
  repeat with f in every folder
    set fname to name of f
    set fcount to count of notes of f
    set out to out & fname & "\t" & fcount & "\n"
  end repeat
  return out
end tell
APPLESCRIPT
  echo
  echo "Если у папки 0 заметок, но в самом Notes.app вы видите содержимое --"
  echo "возможно, заметки лежат во вложенной подпапке. AppleScript-обращение"
  echo "к папке по имени видит только заметки НАПРЯМУЮ в ней, не в подпапках."
  echo "Проверьте вложенные папки в Notes.app вручную."
}

# Достаём список заметок (id + name + modification date) через AppleScript
# и построчно отдаём их в bash. Разделитель полей -- табуляция, разделитель
# записей -- перевод строки; заголовок заметки не может содержать перевод строки
# (Notes берёт его из первой строки тела), поэтому это безопасно.
fetch_notes_folder() {
  local folder_name="$1"
  osascript <<APPLESCRIPT
tell application "Notes"
  set targetFolder to missing value
  repeat with f in every folder
    if name of f is "$folder_name" then
      set targetFolder to f
      exit repeat
    end if
  end repeat
  if targetFolder is missing value then
    error "Папка не найдена: $folder_name"
  end if
  set out to ""
  set noteList to every note of targetFolder
  repeat with n in noteList
    set nid to id of n as string
    set nname to name of n
    set out to out & nid & "\t" & nname & "\n"
  end repeat
  return out
end tell
APPLESCRIPT
}

fetch_notes_search() {
  local query="$1"
  osascript <<APPLESCRIPT
tell application "Notes"
  set out to ""
  set noteList to (every note whose body contains "$query")
  repeat with n in noteList
    set nid to id of n as string
    set nname to name of n
    set out to out & nid & "\t" & nname & "\n"
  end repeat
  return out
end tell
APPLESCRIPT
}

# Тело + дата изменения + папка-источник одной заметки по её id.
fetch_note_detail() {
  local note_id="$1"
  osascript <<APPLESCRIPT
tell application "Notes"
  set n to note id "$note_id"
  set nbody to body of n
  set nmod to (modification date of n) as string
  -- "name of container of n" в одну команду падает с ошибкой -1728 в Notes на
  -- Sequoia; получаем контейнер отдельной переменной и берём name у неё.
  set nfolderRef to container of n
  set nfolder to name of nfolderRef
  return nbody & "§§§FIELD§§§" & nmod & "§§§FIELD§§§" & nfolder
end tell
APPLESCRIPT
}

export_notes() {
  local -a entries=("$@")
  mkdir -p "$OUT_DIR"

  local total=${#entries[@]}
  if [[ $total -eq 0 ]]; then
    echo "Заметок не найдено."
    return
  fi

  echo "Найдено заметок: $total. Экспортирую в $OUT_DIR ..."

  # macOS поставляет bash 3.2 (лицензионные причины Apple), в котором нет
  # ни ассоциативных массивов, ни mapfile -- поэтому коллизии имён файлов
  # отслеживаем обычным списком строк, а не declare -A.
  local used_names=""
  local count=0

  for entry in "${entries[@]}"; do
    local note_id="${entry%%$'\t'*}"
    local note_title="${entry#*$'\t'}"

    local detail
    if ! detail=$(fetch_note_detail "$note_id"); then
      echo "Пропуск: не удалось прочитать заметку id=$note_id" >&2
      continue
    fi

    local html_body="${detail%%§§§FIELD§§§*}"
    local rest="${detail#*§§§FIELD§§§}"
    local mod_date="${rest%%§§§FIELD§§§*}"
    local source_folder="${rest#*§§§FIELD§§§}"

    local safe_title
    safe_title=$(sanitize_filename "$note_title")

    local filename="$safe_title"
    local idx=1
    while printf '%s\n' "$used_names" | grep -qxF "$filename"; do
      idx=$((idx + 1))
      filename="${safe_title}-${idx}"
    done
    used_names="${used_names}
${filename}"

    local out_path="$OUT_DIR/${filename}.md"

    # Notes оборачивает каждую строку тела в голый <div> без class/id.
    # pandoc честно рендерит такие div как fenced-div блоки (::: {} ... :::),
    # что засоряет markdown. Notes использует <div> ровно как параграф, поэтому
    # безопасно заменить div на p и убрать пустые <div><br></div> перед конвертацией.
    local markdown_body
    markdown_body=$(printf '%s' "$html_body" \
      | sed -e 's/<div><br *\/*><\/div>//g' -e 's/<div>/<p>/g' -e 's/<\/div>/<\/p>/g' \
      | pandoc -f html -t markdown)

    {
      echo "---"
      echo "title: \"$(printf '%s' "$note_title" | sed 's/"/\\"/g')\""
      echo "modified: \"$mod_date\""
      echo "source_folder: \"$source_folder\""
      echo "---"
      echo
      printf '%s\n' "$markdown_body"
    } > "$out_path"

    count=$((count + 1))
    echo "  [$count/$total] $out_path"
  done

  echo "Готово: экспортировано $count из $total заметок."
}

check_automation_access
check_pandoc

case "$MODE" in
  list)
    do_list
    ;;
  folder)
    if [[ -z "$FOLDER" ]]; then
      echo "Не указано имя папки для --folder." >&2
      exit 1
    fi
    raw=$(fetch_notes_folder "$FOLDER") || {
      echo "Ошибка при обращении к папке \"$FOLDER\". Проверьте имя через --list." >&2
      exit 1
    }
    if [[ -z "$raw" ]]; then
      echo "В папке \"$FOLDER\" не найдено заметок напрямую."
      echo "Если папка не пустая в Notes.app -- содержимое, скорее всего, лежит"
      echo "во вложенной подпапке, которую AppleScript не обходит рекурсивно."
      echo "Проверьте вложенные папки вручную в Notes.app."
      exit 0
    fi
    # bash 3.2 (штатный на macOS) не умеет mapfile -- читаем построчно вручную
    filtered=()
    while IFS= read -r e; do
      [[ -n "$e" ]] && filtered+=("$e")
    done <<< "$raw"
    export_notes "${filtered[@]}"
    ;;
  search)
    if [[ -z "$SEARCH" ]]; then
      echo "Не указана строка поиска для --search." >&2
      exit 1
    fi
    raw=$(fetch_notes_search "$SEARCH") || {
      echo "Ошибка при поиске по строке \"$SEARCH\"." >&2
      exit 1
    }
    if [[ -z "$raw" ]]; then
      echo "По запросу \"$SEARCH\" ничего не найдено."
      exit 0
    fi
    filtered=()
    while IFS= read -r e; do
      [[ -n "$e" ]] && filtered+=("$e")
    done <<< "$raw"
    export_notes "${filtered[@]}"
    ;;
esac
