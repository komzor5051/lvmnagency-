#!/usr/bin/env bash
#
# apple-photos-export.sh
#
# Обёртка вокруг osxphotos для выгрузки видео/фото из Apple Photos в папку
# рабочего задания. НЕ использует AppleScript для Photos -- на macOS Sequoia
# AppleScript-обращения к Photos сломаны (фильтр по дате даёт ошибку -1700,
# по типу медиа -2741, поиск альбома по имени возвращает 0 результатов).
# osxphotos обходит это, читая базу Photos напрямую.

set -euo pipefail

SCRIPT_NAME="$(basename "$0")"

usage() {
  cat <<EOF
Использование:
  $SCRIPT_NAME --check
  $SCRIPT_NAME --videos --days 30 --limit 20 --out inbox/job/video
  $SCRIPT_NAME --album "reels" --out inbox/job/photo

Опции:
  --check           диагностика: версия osxphotos, число фото/видео, сколько missing
  --videos          выгрузить только видео (--only-movies)
  --photos          выгрузить только фото (--only-photos)
  --days N          выгрузить только за последние N дней (переводится в --from-date)
  --limit N         ограничить число выгружаемых файлов
  --album ИМЯ       выгрузить только из альбома ИМЯ
  --out ПУТЬ        папка назначения (обязательна для экспорта)
  -h, --help        показать эту справку

Требования: osxphotos (Python 3.10+). Установка:
  uv tool install osxphotos --python 3.11

ВАЖНО про iCloud: у многих ассетов в библиотеке оригиналы не скачаны на этот
Mac (iCloud "Оптимизация хранилища"). osxphotos молча пропускает такие файлы
при экспорте. Скрипт всегда печатает сводку найдено/выгружено/пропущено как
missing после экспорта -- проверяйте её, не полагайтесь на "команда завершилась
без ошибок" как признак успеха.
EOF
}

OSXPHOTOS_BIN=""
find_osxphotos() {
  if command -v osxphotos >/dev/null 2>&1; then
    OSXPHOTOS_BIN="$(command -v osxphotos)"
    return 0
  fi
  if [[ -x "$HOME/.local/bin/osxphotos" ]]; then
    OSXPHOTOS_BIN="$HOME/.local/bin/osxphotos"
    return 0
  fi
  return 1
}

check_osxphotos() {
  if ! find_osxphotos; then
    echo "Не найден osxphotos." >&2
    echo "Нужен Python 3.10+. Установка:" >&2
    echo "  uv tool install osxphotos --python 3.11" >&2
    echo "Внимание: если ставить osxphotos под системный python3 (обычно 3.9)," >&2
    echo "инструмент падает с TypeError на синтаксисе аннотаций 'X | None'." >&2
    echo "Явно укажите --python 3.11 (или новее) при установке через uv." >&2
    exit 1
  fi
}

MODE=""
ONLY_MOVIES=false
ONLY_PHOTOS=false
DAYS=""
LIMIT=""
ALBUM=""
OUT_DIR=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --check)
      MODE="check"
      shift
      ;;
    --videos)
      ONLY_MOVIES=true
      shift
      ;;
    --photos)
      ONLY_PHOTOS=true
      shift
      ;;
    --days)
      DAYS="${2:-}"
      shift 2
      ;;
    --limit)
      LIMIT="${2:-}"
      shift 2
      ;;
    --album)
      ALBUM="${2:-}"
      shift 2
      ;;
    --out)
      OUT_DIR="${2:-}"
      shift 2
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Неизвестный аргумент: $1" >&2
      usage >&2
      exit 1
      ;;
  esac
done

check_osxphotos

if [[ "$MODE" == "check" ]]; then
  echo "osxphotos: $OSXPHOTOS_BIN"
  "$OSXPHOTOS_BIN" --version
  echo
  "$OSXPHOTOS_BIN" info
  exit 0
fi

if [[ -z "$OUT_DIR" ]]; then
  echo "Нужен --out ПУТЬ (или используйте --check для диагностики)." >&2
  usage >&2
  exit 1
fi

if [[ "$ONLY_MOVIES" == true && "$ONLY_PHOTOS" == true ]]; then
  echo "Нельзя одновременно указать --videos и --photos." >&2
  exit 1
fi

mkdir -p "$OUT_DIR"

ARGS=("$OUT_DIR" --update)

if [[ "$ONLY_MOVIES" == true ]]; then
  ARGS+=(--only-movies)
fi
if [[ "$ONLY_PHOTOS" == true ]]; then
  ARGS+=(--only-photos)
fi

if [[ -n "$DAYS" ]]; then
  # date -v-Nd работает на macOS (BSD date); на Linux потребовался бы -d "-N days"
  FROM_DATE=$(date -v-"${DAYS}"d +%Y-%m-%d)
  ARGS+=(--from-date "$FROM_DATE")
  echo "Фильтр по дате: от $FROM_DATE (последние $DAYS дн.)"
fi

if [[ -n "$LIMIT" ]]; then
  ARGS+=(--limit "$LIMIT")
fi

if [[ -n "$ALBUM" ]]; then
  ARGS+=(--album "$ALBUM")
fi

REPORT_FILE="${OUT_DIR%/}/.osxphotos-report.csv"
ARGS+=(--report "$REPORT_FILE")

echo "Запускаю: $OSXPHOTOS_BIN export ${ARGS[*]}"
echo

# osxphotos печатает в stdout сводную строку вида:
# "Processed: N photos, exported: E, updated: U, skipped: S, ... missing: M, error: X"
# Сохраняем весь вывод, чтобы и показать его пользователю, и распарсить сводку.
OUTPUT_LOG=$(mktemp)
set +e
"$OSXPHOTOS_BIN" export "${ARGS[@]}" 2>&1 | tee "$OUTPUT_LOG"
EXPORT_STATUS=${PIPESTATUS[0]}
set -e

echo
echo "===== Сводка экспорта ====="

SUMMARY_LINE=$(grep -E "^Processed:" "$OUTPUT_LOG" | tail -1 || true)

if [[ -n "$SUMMARY_LINE" ]]; then
  echo "$SUMMARY_LINE"

  PROCESSED=$(printf '%s' "$SUMMARY_LINE" | grep -oE "Processed: [0-9]+" | grep -oE "[0-9]+" || echo "0")
  EXPORTED=$(printf '%s' "$SUMMARY_LINE" | grep -oE "exported: [0-9]+" | grep -oE "[0-9]+" || echo "0")
  MISSING=$(printf '%s' "$SUMMARY_LINE" | grep -oE "missing: [0-9]+" | grep -oE "[0-9]+" || echo "0")

  echo
  echo "Найдено по фильтру: $PROCESSED"
  echo "Выгружено файлов:   $EXPORTED"
  echo "Пропущено (missing): $MISSING"

  if [[ "$MISSING" != "0" ]]; then
    echo
    echo "ВНИМАНИЕ: $MISSING файлов не выгружено, потому что их оригиналы не"
    echo "скачаны из iCloud на этот Mac (в Photos это выглядит как облачная"
    echo "иконка вместо превью). Это НЕ ошибка команды -- osxphotos просто"
    echo "не может прочитать то, чего физически нет на диске."
    echo "Чтобы исправить: откройте Photos.app -> Settings -> iCloud -> и"
    echo "включите 'Download Originals to this Mac', дождитесь докачки, затем"
    echo "запустите эту команду повторно (--update пропустит уже выгруженное)."
  fi
else
  echo "Не удалось найти сводную строку в выводе osxphotos -- смотрите лог выше."
fi

echo
echo "CSV-отчёт по каждому файлу: $REPORT_FILE"

rm -f "$OUTPUT_LOG"

exit "$EXPORT_STATUS"
